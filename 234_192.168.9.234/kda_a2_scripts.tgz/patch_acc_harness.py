"""给 acc_ab.py 补两处变长用例支持（json 里 cu_seqlens/chunk_indices 是"框架生成"）：

1) 参考（FP64 标杆）路径也必须用规范化后的 cu_seqlens/chunk_indices，
   否则 CPU 标杆会拿到字符串/0 直接报 ValueError；
2) chunk_indices 要按 cu_seqlens + chunk_size 自己造一份一致映射。

用法: python3 patch_acc_harness.py acc_ab.py
"""

from __future__ import annotations
import pathlib
import sys

ANCHOR_CS = '        values["cu_seqlens"] = [0, tokens // 2, tokens]\n'
ADD_CI = '''    # chunk_indices 在 json 里同样是"框架生成"（0 / "null"）：按上面的
    # cu_seqlens 与 chunk_size 造一份一致映射（每个 chunk 属于哪条序列）。
    if values.get("cu_seqlens") is not None and not isinstance(
            values.get("chunk_indices"), (list, tuple)):
        csize = int(case.get("chunk_size") or 64)
        cs = values["cu_seqlens"]
        idx = []
        for seg in range(len(cs) - 1):
            span = int(cs[seg + 1]) - int(cs[seg])
            idx.extend([seg] * ((span + csize - 1) // csize))
        values["chunk_indices"] = idx
'''
ANCHOR_REF = "    ref_inputs = ex._direct_inputs(blob, high_precision=True)\n"
NEW_REF = '''    ref_blob = dict(blob)
    for _name in ("cu_seqlens", "chunk_indices"):
        if _name in values:
            ref_blob[_name] = values[_name]
    ref_inputs = ex._direct_inputs(ref_blob, high_precision=True)
'''


def main() -> int:
    path = sys.argv[1]
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8")
    changed = 0
    if ANCHOR_CS in src and "chunk_indices 在 json 里同样是" not in src:
        src = src.replace(ANCHOR_CS, ANCHOR_CS + ADD_CI, 1)
        changed += 1
    if ANCHOR_REF in src:
        src = src.replace(ANCHOR_REF, NEW_REF, 1)
        changed += 1
    if changed == 0:
        raise SystemExit("[patch_acc_harness] nothing to do")
    p.write_text(src, encoding="utf-8", newline="\n")
    print(f"[patch_acc_harness] applied {changed} edit(s)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
