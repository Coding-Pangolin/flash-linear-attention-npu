"""E2：把指定 Stage 的调用点从 Process 里屏蔽掉（保留 Process 里的核间 flag 回合）。

设计要点（2026-10-08 修正）：
  上一版是在 Stage 函数体首行插 `return;`，这会连带跳过函数内部的
  WaitFlag/SetFlag（ioFree_/sharedFree_/mToMte1_/tReady_/fixToMte1_ ...），
  令牌链断裂 ⇒ 内核挂死（实测：整核 100% 卡死，无输出）。
  本版只在 Process 的**调用点**上做手术：
    * 被屏蔽的 Stage 内部的 wait/set 成对消失 ⇒ 不破坏令牌链；
    * Process 里的 CrossCoreWait/Set 一律保留 ⇒ 核间回合数不变；
    * 唯一例外是「上游 stage 的 set 被下游 stage 消费」的跨 stage 令牌，
      屏蔽时要在调用点补一句等价的 SetFlag。

用法：
  python e2_apply.py <vec.h|cube.h> comment StageV0 StageV1
  python e2_apply.py <cube.h> replace-c7 StageC7
  python e2_apply.py <file> list
"""

from __future__ import annotations

import re
import sys


def call_span(src: str, name: str) -> tuple[int, int]:
    """返回 src 中 `name(...)` **调用点**（最后出现的、后跟 `;` 的那处）的 [start, end)。"""
    spans = []
    for m in re.finditer(r"(?m)^([ \t]*)" + re.escape(name) + r"\(", src):
        if "inline void" in src[max(0, m.start() - 60):m.start()]:
            continue
        i = m.start() + len(m.group(1))  # 丢掉行首缩进
        depth = 0
        while i < len(src):
            if src[i] == "(":
                depth += 1
            elif src[i] == ")":
                depth -= 1
                if depth == 0:
                    j = i + 1
                    while j < len(src) and src[j] in " \t":
                        j += 1
                    if j < len(src) and src[j] == ";":
                        spans.append((m.start(), j + 1))
                    break
            i += 1
    if not spans:
        raise SystemExit(f"[e2_apply] call not found: {name}")
    return spans[-1]


def comment_out(src: str, name: str) -> str:
    a, b = call_span(src, name)
    return src[:a] + "/*E2B*/ if (false) { " + src[a:b] + " }" + src[b:]


def replace_c7(src: str, name: str) -> str:
    """C7 的 free 许可是在函数体内发的，屏蔽调用时要补一句等价的核间 set。"""
    a, b = call_span(src, name)
    indent = re.match(r"[ \t]*", src[a:]).group(0)
    patched = (
        "/*E2B*/ if (false) { " + src[a:b] + " }\n"
        + indent
        + "AscendC::CrossCoreSetFlag<0x2, PIPE_MTE2>(kFreeFlagId[pair]);"
    )
    return src[:a] + patched + src[b:]


def main() -> int:
    path, mode = sys.argv[1], sys.argv[2]
    src = open(path, encoding="utf-8").read()
    if mode == "list":
        for m in re.finditer(r"(?m)^[ \t]*(\w+)\(chunk", src):
            print(m.group(1))
        return 0
    names = sys.argv[3:]
    for name in names:
        if mode == "replace-c7" or (mode == "mixed" and name == "StageC7"):
            src = replace_c7(src, name)
        else:
            src = comment_out(src, name)
        print(f"[e2_apply] {mode}: {name}")
    open(path, "w", encoding="utf-8").write(src)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
