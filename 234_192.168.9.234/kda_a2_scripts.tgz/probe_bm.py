"""列出本机 ATK2678 注册的精度 BM 名（用于替换 json 里的 mixed_tolerance_bm）。"""

import atk.tasks.task_plugins_register as t

for name in ("AccuracyFactory", "CompareFactory", "BenchmarkFactory"):
    obj = getattr(t, name, None)
    if obj is None:
        continue
    for meth in ("get_register_keys", "get_registered_names"):
        fn = getattr(obj, meth, None)
        if callable(fn):
            try:
                print(name, meth, fn())
            except Exception as exc:  # noqa: BLE001
                print(name, meth, "ERR", repr(exc))
