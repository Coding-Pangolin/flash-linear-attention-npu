"""把 patch_inv16.py 里"是否已插入 kFixpipeRow 定义"的判据收紧。"""

import pathlib

p = pathlib.Path(__file__).resolve().parent / "patch_inv16.py"
t = p.read_text(encoding="utf-8")
t = t.replace('if "kFixpipeRow" not in ctext:', 'if "kFixpipeRow = {" not in ctext:')
p.write_text(t, encoding="utf-8", newline="\n")
print("guard fixed:", '"kFixpipeRow = {" not in ctext' in t)
