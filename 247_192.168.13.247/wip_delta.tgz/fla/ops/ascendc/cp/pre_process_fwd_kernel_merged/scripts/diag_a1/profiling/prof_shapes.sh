#!/bin/bash
# 241 上板 msopprof 多 shape 采集驱动
#   SHAPES="64:1 256:2 1024:8 4096:8" OUTROOT=/tmp/ppfm241/out_tile1 bash prof_shapes.sh
set -u
PY=${PY:-$HOME/BartonFang/envs/fzy/bin/python}
W=${W:-/tmp/ppfm241/prof}
SHAPES=${SHAPES:-"64:1 256:2 1024:8 4096:8"}
OUTROOT=${OUTROOT:-/tmp/ppfm241/out_prof}
PREFIX=${PREFIX:-}
DEV=${DEV:-6}
source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=$DEV PYTHONWARNINGS=ignore
mkdir -p "$OUTROOT"
for s in $SHAPES; do
  T=${s%%:*}; HV=${s##*:}
  OUT=$OUTROOT/T${T}_HV${HV}
  rm -rf "$OUT"
  echo "=== collect ${PREFIX}T=$T HV=$HV ==="
  PPFM_SIM_T=$T PPFM_SIM_HV=$HV timeout 1800 msprof op \
    --application="$PY $W/sim_ppfm.py" --output="$OUT" \
    --kernel-name=PreProcessFwdKernelMerged --launch-count=1 --warm-up=1 \
    --aic-metrics=Default > "$W/msop_${PREFIX}T${T}_HV${HV}.log" 2>&1
  echo "  rc=$? $(find "$OUT" -maxdepth 2 -name OpBasicInfo.csv | head -1)"
done
echo PROF_DONE
