#!/bin/bash
# 子 Stage 屏蔽差分：从"已优化版"源码出发，把某个函数的所有调用点包进 if(false)，
# 重编重装后再测 case 63。用来把 E2 的归因再往下切一层。
#   TAG=S_leafinv FUNCS="SolveLeafRightLooking" bash e2_sub.sh
set +u
MY=${MY:-/home/admin123/kda_a2}
REPO=$MY/repo
OP=$REPO/fla/ops/ascendc/kda/chunk_kda_fwd_prepare/op_kernel/arch22
VEC=$OP/chunk_kda_fwd_prepare_vec.h
BASE_SRC=$MY/vec_normblk4.h
PKG=$MY/python-a2c/fla_npu
VLNK=$PKG/opp/vendors/fla_npu_transformer
JSON=$REPO/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
CID=${CID:-63}
CACHE=${CACHE:-$MY/cache/case$CID.pt}
TAG=${TAG:?usage: TAG=S_xxx FUNCS="F1 F2" bash e2_sub.sh}
FUNCS=${FUNCS:?set FUNCS}

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
BASE_OPP=${ASCEND_CUSTOM_OPP_PATH:-}

cp -f "$BASE_SRC" "$VEC"
"$PY" "$MY/e2_sub.py" "$VEC" comment $FUNCS || exit 1

bash $REPO/build.sh --pkg --soc=ascend910b --vendor_name=fla_npu \
    --ops=chunk_kda_fwd_prepare > "$MY/build_$TAG.log" 2>&1 \
  || { echo "[$TAG] BUILD FAIL"; grep -a -m3 "error:" "$MY/build_$TAG.log"; cp -f "$VEC.e2sub" "$VEC"; exit 1; }
run=$(ls -t $REPO/build_out/*.run | head -1)
exp=$PKG/opp_vendors/$TAG
rm -rf "$exp"; mkdir -p "$exp"
"$run" --quiet --install-path="$exp" > "$MY/install_$TAG.log" 2>&1 || { echo "[$TAG] INSTALL FAIL"; exit 1; }
mkdir -p "$exp/vendors"; echo "load_priority=fla_npu_transformer" > "$exp/vendors/config.ini"
rm -rf "$VLNK"; ln -sT "$exp/vendors/fla_npu_transformer" "$VLNK"
V=$exp/vendors/fla_npu_transformer
export ASCEND_CUSTOM_OPP_PATH=${BASE_OPP:+$BASE_OPP:}$V:$V/op_api/lib

timeout 900 "$PY" "$MY/kda_a2_bench.py" "$JSON" "$CID" 2 10 "$CACHE" \
    > "$MY/bench_$TAG.log" 2>&1
line=$(grep -a "event=" "$MY/bench_$TAG.log" | tail -1)
if [ -n "$line" ]; then echo "[$TAG] $line"; else echo "[$TAG] MEASURE FAIL"; tail -5 "$MY/bench_$TAG.log"; fi

cp -f "$VEC.e2sub" "$VEC"
echo "[$TAG] done"
