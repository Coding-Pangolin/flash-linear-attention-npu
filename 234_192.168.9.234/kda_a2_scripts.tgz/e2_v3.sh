#!/bin/bash
# E2 v3：在"已优化版"（块状 V0 norm）之上重跑分 Stage 屏蔽差分，看新的瓶颈分布。
# 与 e2_v2.sh 的区别：base 源码 = vec_normblk4.h（已优化），tag 前缀 e2v3_*，
# 不覆盖 v2 留下的包；变体集合按当前最需要归因的 4 个 Stage。
#   bash e2_v3.sh            # 全量（base + 4 个变体）
#   ONLY=B_V3 bash e2_v3.sh  # 只跑一个变体
set +u
MY=${MY:-/home/admin123/kda_a2}
REPO=$MY/repo
OP=$REPO/fla/ops/ascendc/kda/chunk_kda_fwd_prepare/op_kernel/arch22
VEC=$OP/chunk_kda_fwd_prepare_vec.h
CUBE=$OP/chunk_kda_fwd_prepare_cube.h
BASE_SRC=$MY/vec_normblk4.h
PKG=$MY/python-a2c/fla_npu
VLNK=$PKG/opp/vendors/fla_npu_transformer
JSON=$REPO/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
CID=${CID:-63}
CACHE=${CACHE:-$MY/cache/case$CID.pt}
TAGP=${TAGP:-e2v3}

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
BASE_OPP=${ASCEND_CUSTOM_OPP_PATH:-}
mkdir -p "$(dirname "$CACHE")"

# 以"已优化版"为新的基线源码
cp -f "$BASE_SRC" "$VEC"
cp -f "$VEC" "$VEC.p0"; cp -f "$CUBE" "$CUBE.p0"
if grep -q "E2B" "$VEC" "$CUBE"; then echo "!! 源码里有 E2B 残留"; exit 1; fi
grep -q L2NormRowsBlock "$VEC" || { echo "!! base 源码不是已优化版"; exit 1; }

point_link() { # $1 tag
  local exp=$PKG/opp_vendors/$1
  [ -d "$exp/vendors/fla_npu_transformer" ] || { echo "  (no pkg $1)"; return 1; }
  rm -rf "$VLNK"; ln -sT "$exp/vendors/fla_npu_transformer" "$VLNK"
  local v=$exp/vendors/fla_npu_transformer
  export ASCEND_CUSTOM_OPP_PATH=${BASE_OPP:+$BASE_OPP:}$v:$v/op_api/lib
}

build_tag() { # $1 tag
  bash $REPO/build.sh --pkg --soc=ascend910b --vendor_name=fla_npu \
      --ops=chunk_kda_fwd_prepare > "$MY/build_$1.log" 2>&1 \
    || { echo "[$1] BUILD FAIL"; tail -12 "$MY/build_$1.log"; return 1; }
  local run exp
  run=$(ls -t $REPO/build_out/*.run | head -1)
  exp=$PKG/opp_vendors/$1
  rm -rf "$exp"; mkdir -p "$exp"
  "$run" --quiet --install-path="$exp" > "$MY/install_$1.log" 2>&1 \
    || { echo "[$1] INSTALL FAIL"; return 1; }
  mkdir -p "$exp/vendors"; echo "load_priority=fla_npu_transformer" > "$exp/vendors/config.ini"
}

measure() { # $1 tag
  local log=$MY/bench_$1.log
  timeout 900 "$PY" "$MY/kda_a2_bench.py" "$JSON" "$CID" 2 10 "$CACHE" \
      > "$log" 2>&1
  local line
  line=$(grep -a "event=" "$log" | tail -1)
  if [ -n "$line" ]; then echo "[$1] $line"; else
    echo "[$1] MEASURE FAIL"; tail -5 "$log" | sed 's/^/        /'
  fi
}

variant() { # $1 tag  $2 file  $3 mode  $4.. names
  local tag=$1 file=$2 mode=$3; shift 3
  if [ -n "$ONLY" ] && [ "$ONLY" != "$tag" ]; then return 0; fi
  cp -f "$file.p0" "$file"
  "$PY" "$MY/e2_apply.py" "$file" "$mode" "$@" || { echo "[$tag] PATCH FAIL"; return 1; }
  echo "=== $tag ==="
  build_tag "${TAGP}_$tag" || return 0
  point_link "${TAGP}_$tag" || return 0
  measure "${TAGP}_$tag"
}

if [ -z "$ONLY" ]; then
  echo "=== 新基线（块状 V0 norm） ==="
  cp -f "$VEC.p0" "$VEC"; cp -f "$CUBE.p0" "$CUBE"
  build_tag "${TAGP}_base" || exit 1
  point_link "${TAGP}_base" && measure "${TAGP}_base"
fi

variant B_V01   "$VEC"  comment    StageV0 StageV1
variant B_V3    "$VEC"  comment    StageV3
variant B_V6    "$VEC"  comment    StageV6
variant B_C2    "$CUBE" comment    StageC2
variant B_C45C7 "$CUBE" mixed      StageC4 StageC5 StageC7

echo "=== 恢复源码（已优化版） ==="
cp -f "$VEC.p0" "$VEC"; cp -f "$CUBE.p0" "$CUBE"
echo done
