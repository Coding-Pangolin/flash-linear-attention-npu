"""子 Stage 屏蔽：把某个 **函数调用**（不一定是 Stage 入口）用 if(false) 包起来。

用于把 E2 的归因粒度再往下切一层，例如把 V3 里的两次叶子逆
（SolveLeafRightLooking）单独屏蔽，看它占 V3 的多少。

用法: python e2_sub.py <file.h> comment <FuncName> [<FuncName2> ...]
      python e2_sub.py <file.h> block "<起始行文本>"     # 花括号配对后整块包进 if(false)
      python e2_sub.py <file.h> revert
"""

from __future__ import annotations

import pathlib
import re
import sys


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def wrap_calls(src: str, name: str) -> tuple[str, int]:
    """把所有 `name(` 调用点（非定义行，以 `;` 结束）包进 if(false)。"""
    out = []
    count = 0
    for m in re.finditer(r"(?m)^([ \t]*)" + re.escape(name) + r"\(", src):
        line_start = m.start()
        if "inline void" in src[max(0, line_start - 80):line_start]:
            continue
        i = m.start() + len(m.group(1))
        depth = 0
        while i < len(src):
            if src[i] == "(":
                depth += 1
            elif src[i] == ")":
                depth -= 1
                if depth == 0:
                    j = i + 1
                    while j < len(src) and src[j] in " \t":
                        j += 1
                    if j < len(src) and src[j] == ";":
                        out.append((line_start, j + 1))
                    break
            i += 1
    if not out:
        raise SystemExit(f"[e2_sub] no call found: {name}")
    for start, end in reversed(out):
        src = src[:start] + "/*E2S*/ if (false) { " + src[start:end] + " }" + src[end:]
        count += 1
    return src, count


def wrap_block(src: str, marker: str) -> str:
    """把 marker 开始、花括号配对的整块（含 for/if 头）包进 if(false)。"""
    if marker not in src:
        raise SystemExit(f"[e2_sub] block marker not found: {marker!r}")
    spans = []
    pos = 0
    while True:
        start = src.find(marker, pos)
        if start < 0:
            break
        brace = src.index("{", start)
        depth = 0
        i = brace
        while i < len(src):
            if src[i] == "{":
                depth += 1
            elif src[i] == "}":
                depth -= 1
                if depth == 0:
                    break
            i += 1
        spans.append((start, i + 1))
        pos = i + 1
    for start, end in reversed(spans):
        src = src[:start] + "/*E2S*/ if (false) " + src[start:end] + src[end:]
    print(f"[e2_sub] block wrapped {len(spans)}x")
    return src


def main() -> int:
    path = sys.argv[1]
    if sys.argv[2] == "revert":
        backup = pathlib.Path(path + ".e2sub")
        if not backup.exists():
            raise SystemExit(f"[e2_sub] no backup {backup}")
        write_lf(path, backup.read_text(encoding="utf-8"))
        print("[e2_sub] reverted")
        return 0
    src = pathlib.Path(path).read_text(encoding="utf-8")
    if "E2S" in src:
        raise SystemExit("[e2_sub] already patched")
    write_lf(path + ".e2sub", src)
    total = 0
    if sys.argv[2] == "block":
        src = wrap_block(src, sys.argv[3])
        write_lf(path, src)
        return 0
    for name in sys.argv[3:]:
        src, n = wrap_calls(src, name)
        total += n
        print(f"[e2_sub] wrapped {n}x {name}")
    write_lf(path, src)
    print(f"[e2_sub] total {total} call sites wrapped")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
