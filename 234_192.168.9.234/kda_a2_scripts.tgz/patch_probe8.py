"""probe8：给 V6 的"kg 族"（E(g[last]-g[row]) 的 sub+clamp+muls+Exp+cast+mul+cast）定价。

只做屏蔽（不追求正确），用来判断"V6 两个 exp 族里哪一族值得动"：
  * 屏蔽 kg 族以后，kg 输出保持为 k_hat（有限值，不会把时间搅乱）；
  * V6 的 qg/qBeta 族与 qgScaled 族原样保留。

用法: python3 patch_probe8.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

BLOCK = """            // E'(G)=exp(clamp(g[last]-g[row]))
            SubRowMinusTile(factor, g[last], g[offset], rows);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Maxs(factor, factor, directMin, elems);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Mins(factor, factor, directMax, elems);
            AscendC::PipeBarrier<PIPE_V>();
            if constexpr (Domain::useExp2) {
                AscendC::Muls(factor, factor, Domain::expInputScale, elems);
                AscendC::PipeBarrier<PIPE_V>();
            }
            AscendC::Exp(factor, factor, elems);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Cast(stage, kg[offset], AscendC::RoundMode::CAST_NONE,
                          elems);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Mul(stage, stage, factor, elems);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Cast(kg[offset], stage, AscendC::RoundMode::CAST_RINT,
                          elems);
            AscendC::PipeBarrier<PIPE_V>();
"""

MARK = "            // probe8: kg 族已屏蔽\n"


def main() -> int:
    path = sys.argv[1]
    revert = len(sys.argv) > 2 and sys.argv[2] == "--revert"
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8")
    if revert:
        if MARK not in src:
            raise SystemExit("[patch_probe8] not patched")
        src = src.replace(MARK, BLOCK, 1)
        p.write_text(src, encoding="utf-8", newline="\n")
        print("[patch_probe8] reverted")
        return 0
    if src.count(BLOCK) != 1:
        raise SystemExit(f"[patch_probe8] anchor x{src.count(BLOCK)}")
    src = src.replace(BLOCK, MARK, 1)
    p.write_text(src, encoding="utf-8", newline="\n")
    print("[patch_probe8] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
