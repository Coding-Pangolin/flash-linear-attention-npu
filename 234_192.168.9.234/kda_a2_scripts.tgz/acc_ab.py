"""精度 A/B：对同一批输入跑 NPU 出参 + executor 自带的 FP64 CPU 标杆做对比。

ATK 的 accuracy 通道在本容器里跑不通（baseline 也一样失败：
`KeyError: 'mixed_tolerance_bm'` / 输出 bytes 为 None），所以这里直接复用
`executor_chunk_kda_fwd_prepare.py` 里的 `run_npu` / `run_cpu`（同一个标杆文件），
自己算 max_abs / RMS / 匹配率，并把 NPU 出参落盘，便于 baseline 与改动版 A/B。

用法:
  python acc_ab.py <case_json> <case_id> <cache.pt> <out_prefix> [atol rtol]
第 3 个参数给的 .pt 不存在时会先按用例声明生成输入并缓存。
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time

import torch
import torch_npu  # noqa: F401

EXEC = "/home/admin123/kda_a2/repo/tests/atk/chunk_kda_fwd_prepare/executor_chunk_kda_fwd_prepare.py"
DT = {
    "bf16": torch.bfloat16,
    "fp16": torch.float16,
    "fp32": torch.float32,
    "int32": torch.int32,
    "int64": torch.int64,
}


def load_exec():
    spec = importlib.util.spec_from_file_location("kda_exec", EXEC)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["kda_exec"] = mod
    spec.loader.exec_module(mod)
    return mod


def make_inputs(items, dev):
    values = {}
    for raw in items:
        item = raw[0] if isinstance(raw, list) else raw
        name, dtype, shape = item["name"], item["dtype"], item.get("shape")
        rng = item.get("range_values")
        null = isinstance(rng, str) and rng.strip().lower() in ("null", "")
        if shape is None:
            if dtype == "float":
                values[name] = float(rng)
            elif dtype == "int":
                values[name] = int(rng)
            elif dtype in ("attr_bool", "bool"):
                values[name] = bool(rng)
            elif dtype == "string":
                # backward_mode 的合法值里有 'none'，不能把它当 null。
                values[name] = None if null else str(rng)
            else:
                # 'attrs'（cu_seqlens/chunk_indices）：null -> None，
                # 其余原样交给 executor 的 _normalize_int_list。
                values[name] = None if null else rng
            continue
        if null:
            # a_log / dt_bias 可以写成字符串 "null"（不传这个可选张量）。
            values[name] = None
            continue
        gen = torch.Generator().manual_seed(int(item.get("default_seed") or 0))
        if isinstance(rng, dict):
            mean, std = float(rng["mean"][0]), float(rng["std"][0])
            t = torch.randn(shape, generator=gen, dtype=torch.float32) * std + mean
        elif isinstance(rng, list) and len(rng) == 2:
            lo, hi = float(rng[0]), float(rng[1])
            t = torch.rand(shape, generator=gen, dtype=torch.float32) * (hi - lo) + lo
        else:
            t = torch.zeros(shape, dtype=torch.float32)
        values[name] = t.to(DT.get(dtype, torch.float32)).to(dev)
    return values


def to_dev(blob, dev):
    return {k: (v.to(dev) if torch.is_tensor(v) else v) for k, v in blob.items()}


def call_op(spec, inputs):
    """直调稳定入口：参数名必须是 A_log（executor 里写的 a_log 与 ABI 不符）。"""
    from fla_npu.ops.ascendc import chunk_kda_fwd_prepare as op

    return op(
        inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, float(spec["scale"]),
        layout=str(spec["layout"]), chunk_size=int(spec["chunk_size"]),
        epsilon=float(spec["epsilon"]),
        use_qk_l2norm_in_kernel=bool(spec["use_qk_l2norm_in_kernel"]),
        use_gate_in_kernel=bool(spec["use_gate_in_kernel"]),
        use_beta_sigmoid_in_kernel=bool(spec["use_beta_sigmoid_in_kernel"]),
        allow_neg_eigval=bool(spec["allow_neg_eigval"]),
        safe_gate=bool(spec["safe_gate"]), lower_bound=float(spec["lower_bound"]),
        use_exp2=bool(spec["use_exp2"]),
        A_log=inputs.a_log, dt_bias=inputs.dt_bias,
        cu_seqlens=inputs.cu_seqlens, chunk_indices=inputs.chunk_indices,
        backward_mode=str(spec.get("backward_mode", "save")),
    )


def main() -> int:
    case_json, cid, cache, prefix = sys.argv[1], int(sys.argv[2]), sys.argv[3], sys.argv[4]
    atol = float(sys.argv[5]) if len(sys.argv) > 5 else 1e-2
    rtol = float(sys.argv[6]) if len(sys.argv) > 6 else 2e-3
    ex = load_exec()
    case = next(c for c in json.load(open(case_json, encoding="utf-8")) if c["id"] == cid)

    dev = "npu:0"
    if os.path.exists(cache):
        blob = torch.load(cache, map_location="cpu")
    else:
        t0 = time.time()
        on_dev = make_inputs(case["inputs"], dev)
        blob = {k: (v.detach().cpu() if torch.is_tensor(v) else v)
                for k, v in on_dev.items()}
        torch.save(blob, cache)
        print(f"[acc] inputs generated in {time.time() - t0:.1f}s", flush=True)
    values = to_dev(blob, dev)
    # 变长用例在 ATK 里由框架自动生成 cu_seqlens（json 里只写 0 或 "null"），
    # 直调时自己造一个合法窗口：NPU 与 CPU 标杆用同一份，比较仍然成立。
    if values.get("cu_seqlens") is not None and not isinstance(
            values["cu_seqlens"], (list, tuple)):
        tokens = int(values["q"].shape[-2])
        values["cu_seqlens"] = [0, tokens // 2, tokens]
    # chunk_indices 在 json 里同样是"框架生成"（0 / "null"）：按上面的
    # cu_seqlens 与 chunk_size 造一份一致映射（每个 chunk 属于哪条序列）。
    if values.get("cu_seqlens") is not None and not isinstance(
            values.get("chunk_indices"), (list, tuple)):
        csize = int(case.get("chunk_size") or 64)
        cs = values["cu_seqlens"]
        idx = []
        for seg in range(len(cs) - 1):
            span = int(cs[seg + 1]) - int(cs[seg])
            idx.extend([seg] * ((span + csize - 1) // csize))
        values["chunk_indices"] = idx
    spec = ex._derive_spec(values, cid)
    # _derive_spec 会把 None 的 backward_mode 交给下游，这里统一按 none 处理。
    spec["backward_mode"] = str(spec.get("backward_mode") or "none")
    inputs = ex._direct_inputs(values, high_precision=False)
    ref_blob = dict(blob)
    for _name in ("cu_seqlens", "chunk_indices"):
        if _name in values:
            ref_blob[_name] = values[_name]
    ref_inputs = ex._direct_inputs(ref_blob, high_precision=True)
    print(f"[acc] case {cid} {case['name']}", flush=True)
    print(f"[acc] B={spec['B']} HK={spec['HK']} HV={spec['HV']} T={spec['T']} "
          f"layout={spec['layout']} l2norm={spec['use_qk_l2norm_in_kernel']} "
          f"gate={spec['use_gate_in_kernel']}", flush=True)

    outs = call_op(spec, inputs)
    ref = ex.run_cpu(spec, ref_inputs)
    torch.save({"npu": outs, "cpu": ref}, prefix + ".pt")

    worst = 0.0
    matched_all = True
    for i, (got, want) in enumerate(zip(outs, ref)):
        if got is None or want is None:
            continue
        g = got.float().cpu()
        w = want.float()
        if g.shape != w.shape:
            print(f"  [out {i}] SHAPE MISMATCH npu={tuple(g.shape)} "
                  f"cpu={tuple(w.shape)}")
            matched_all = False
            continue
        diff = (g - w).abs()
        denom = w.abs().clamp_min(1e-6)
        max_abs = diff.max().item()
        rms = (g - w).pow(2).mean().sqrt().item()
        matched = ((diff <= atol + rtol * w.abs()).float().mean().item())
        worst = max(worst, max_abs)
        matched_all = matched_all and matched >= 0.999
        print(f"  [out {i}] {tuple(g.shape)} nmax={w.abs().max().item():.4g} "
              f"max_abs={max_abs:.3e} rms={rms:.3e} matched={matched:.6f}")
    print(f"[acc] worst max_abs={worst:.3e}  all_ok={matched_all}")
    print("[acc] PASS" if matched_all else "[acc] FAIL")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
