/**
 * Copyright (c) 2026 Tianjin University, Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * the BSD 3-Clause License (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 */

/*!
 * \file chunk_delta_h_bwd_preprocess_tiling.h
 * \brief Compatibility include for chunk_delta_h_bwd_preprocess tiling data.
 */

#pragma once

#include "../../op_kernel/chunk_delta_h_bwd_preprocess_struct.h"

namespace optiling {

using CP::ChunkDeltaHBwdPreprocessTilingData;

struct ChunkDeltaHBwdPreprocessCompileInfo {};

} // namespace optiling
