import sys, torch
b = torch.load(sys.argv[1], map_location="cpu")
npu, cpu = b["npu"], b["cpu"]
for i in (6, 7, 8, 9, 1, 3):
    x = npu[i]
    if x is None: continue
    xf = x.float()
    nan = torch.isnan(xf)
    print(f"out{i} shape={tuple(xf.shape)} nan={int(nan.sum())}/{xf.numel()}")
    if nan.any():
        # (B,HV,T,K) -> 按 token 统计
        m = nan.reshape(-1, xf.shape[-2], xf.shape[-1]).any(-1).any(0)
        rows = torch.nonzero(m).flatten()
        print("   token rows with NaN:", rows[:12].tolist(), "... total", int(m.sum()))
