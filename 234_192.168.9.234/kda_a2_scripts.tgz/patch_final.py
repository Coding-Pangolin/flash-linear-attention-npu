"""A4′ 诊断（可信通道版）：一次 build 同时 dump
   aqk[0:64]   = V3 生成的 tile 前 64 个 fp32
   aqk[64:128] = cube 装载后的回声（relay 里的 kAugTile）
   aqk[128:192]= cube 的 X²（relay + kAugProbeOut）
三段都取自 **同一个 head-chunk**（globalChunk==0 且 valueHead==0），
每段之间加 V→MTE3 / MTE2→V 同步。

基：vec_aug2.h + patch_tileoff；cube/policy 用 cube_r2.h / policy_r2.h。

用法: python patch_final.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
B3 = (HERE / "final_body_v3.txt").read_text(encoding="utf-8")
B6 = (HERE / "final_body_v6.txt").read_text(encoding="utf-8")

ANCHOR3 = ("            AscendC::DataCopy(\n"
           "                augRelay[Workspace::kAugTileInRelay / sizeof(float)],\n"
           "                augTile, 1024);\n")
ANCHOR6 = "        AscendC::DataCopy(vBetaRelay, vBeta, rhsRows * Shape::kValueDim);\n"


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "outAqk" in text:
        raise SystemExit("[patch_final] already patched")
    if text.count(ANCHOR3) != 1 or text.count(ANCHOR6) != 1:
        raise SystemExit(f"[patch_final] anchors {text.count(ANCHOR3)}"
                         f"/{text.count(ANCHOR6)}")
    text = text.replace(ANCHOR3, ANCHOR3 + B3, 1)
    text = text.replace(ANCHOR6, ANCHOR6 + B6, 1)
    write_lf(path, text)
    print("[patch_final] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
