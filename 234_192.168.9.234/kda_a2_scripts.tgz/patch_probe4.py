"""A4' 探针（第 4 轮）：把叶子逆的"对角线 16x16 块"整条链路铺满。

基：仓库当前状态 = inv2（A1 块状 norm + leafpair + A4' 前置 + cube 16x16 逆，无哨兵）。

本补丁三件事（都只在 validRows == 64 的全 chunk 上生效，非侵入）：
  1) AIV StageV3：1 个 tile -> 4 个 16x16 块级增广 tile（A0/D0/A1/D1），
     落在 relay + 0x1000*(t+1)；
  2) AIC StageC4Inv16：对 4 个 tile 各做 4 次平方，结果就地覆盖同一 slot；
  3) AIV StageV6：单次哨兵，把 cube 的 4 个 16x16 逆与本 AIV 的 X0/X1 对角块比对，
     差异过大就把 aqk[0] 写 1.0（aqk = 输出索引 1，通道已验证）。

判据：精度用例不受影响；case 63 的时长增量 = 4 个 tile 的搬运 + cube 侧 16 次 MMAD
的代价，这就是 A4' 相对 AIV 侧叶逆（2,362 us）的"额外开销"。

用法: python3 patch_probe4.py <cube.h> <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
CUBE_START = "    // A4′：16×16 块级增广求逆（4 次平方）"
CUBE_END = "    __aicore__ inline void StageC4(const ChunkRange &chunk,"
VEC_START = "        // A4′ 数据契约：为 L00 的"
VEC_END = "    __aicore__ inline void StageV6(const ChunkRange &chunk,"
VEC_SENT_ANCHOR = (
    "        AscendC::DataCopy(vBetaRelay, vBeta, rhsRows * Shape::kValueDim);\n")
INIT_OLD = "        pipe_->InitBuffer(l1Buf_, L1::kPeak + 0x2000);"
INIT_NEW = "        pipe_->InitBuffer(l1Buf_, L1::kPeak + 0x8000);"


def main() -> int:
    cube, vec = sys.argv[1], sys.argv[2]
    ctext = pathlib.Path(cube).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    if "A4′-probe" in ctext or "A4′-probe" in vtext:
        raise SystemExit("[patch_probe4] already patched")
    for tag, text, needle in (("cube", ctext, CUBE_START), ("cube", ctext, CUBE_END),
                              ("vec", vtext, VEC_START), ("vec", vtext, VEC_END),
                              ("vec", vtext, VEC_SENT_ANCHOR),
                              ("cube", ctext, INIT_OLD)):
        if text.count(needle) != 1:
            raise SystemExit(
                f"[patch_probe4] {tag} anchor x{text.count(needle)}: {needle!r}")

    cube_new = (HERE / "probe4_cube.txt").read_text(encoding="utf-8")
    vec_new = (HERE / "probe4b_tiles.txt").read_text(encoding="utf-8")
    sent = (HERE / "probe4_sent.txt").read_text(encoding="utf-8")

    c0, c1 = ctext.index(CUBE_START), ctext.index(CUBE_END)
    ctext = ctext[:c0] + cube_new + ctext[c1:]
    ctext = ctext.replace(INIT_OLD, INIT_NEW, 1)

    v0, v1 = vtext.index(VEC_START), vtext.index(VEC_END)
    vtext = vtext[:v0] + vec_new + vtext[v1:]
    vtext = vtext.replace(VEC_SENT_ANCHOR, VEC_SENT_ANCHOR + sent, 1)

    pathlib.Path(cube).write_text(ctext, encoding="utf-8", newline="\n")
    pathlib.Path(vec).write_text(vtext, encoding="utf-8", newline="\n")
    print("[patch_probe4] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
