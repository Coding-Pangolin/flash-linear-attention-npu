#!/bin/bash
# 属性消融计时（不重编）：用 make_ablate_json.py 生成的 63001..63006 用例，
# 每个用例单独缓存输入（属性标量也在缓存里，不能共用）。
set +u
MY=${MY:-/home/admin123/kda_a2}
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
JSON=${JSON:-$MY/repo/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_ablate.json}
W=${W:-1}; R=${R:-3}
source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}

V=$MY/python-a2c/fla_npu/opp/vendors/fla_npu_transformer
if [ -n "${TAG:-}" ]; then
  VDIR=$MY/python-a2c/fla_npu/opp_vendors/$TAG/vendors/fla_npu_transformer
  [ -d "$VDIR" ] || { echo "[ablate] no vendor $TAG"; exit 1; }
  # 只设 ASCEND_CUSTOM_OPP_PATH 不够：op store 还会跟着软链走。
  rm -rf "$V"; ln -sT "$VDIR" "$V"
else
  VDIR=$(readlink -f "$V")
fi
export ASCEND_CUSTOM_OPP_PATH=${BASE_OPP:+$BASE_OPP:}$VDIR:$VDIR/op_api/lib
echo "[ablate] vendor=$VDIR"

for spec in "$@"; do
  cid=${spec%%:*}; label=${spec##*:}
  log=$MY/bench_ablate_$cid.log
  timeout 900 "$PY" "$MY/kda_a2_bench.py" "$JSON" "$cid" "$W" "$R" \
      "$MY/cache/case$cid.pt" > "$log" 2>&1
  line=$(grep -a "event=" "$log" | tail -1)
  if [ -n "$line" ]; then echo "[$label] $line"; else
    echo "[$label] MEASURE FAIL"; tail -4 "$log" | sed 's/^/        /'
  fi
done
