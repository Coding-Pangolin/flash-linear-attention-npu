# chunk_kda_fwd_prepare — Stage 划分（v3 · 前两个 Vector stage 已合并）

> **v3 = v2（按单工作项关键路径排序）＋ 把原来的 Stage 0 与 Stage 1 合成一个 Vector stage**，其余 stage 顺次前移（7 段 → 6 段）。
> 合并依据：两者都在 AIV 上、**之间没有核间标记**（属于同一个 handshake 回合），合并只减少 stage 数量，
> 不改变任何一次搬运 / 同步 / 计算；合并后的 UB live set 取两者较大者（原 Stage 1 的 **111 KiB**）⇒ 预算不涨。
> 本文只列每个 Stage 的数学公式与执行单元归属；UB/L1 地址、搬运路径、同步与 flag 细节不在此文（见 `design.md`）。
> 与 v2 的逐条差异见 §7；v2 原位保留供对照。

硬件预算：L1 512 KiB，L0C 128 KiB，每个 AIV 的 UB 192 KiB。

命名约定（继承 v1/v2，参考 `A2/A3 Finalize Stage 划分` 的写法，并去掉 Triton 的 `b_` 前缀）：

- 去掉 `b_`：那是 Triton block pointer 的约定，AscendC 里没有对应物；
- **未掩码 / 预处理量加 `_raw` 后缀**（Finalize 文档的写法：`dAqk_raw`、`dk_state_raw`、`left_raw`）；
- **因子不单独命名**，直接给"乘完指数的操作数"起语义名（Finalize 文档的 `kNeg / qPos / bkPos` 就是这一类）；
- 每个 stage 只列该执行单元的运算：Cube 只出现 `@`，Vector 只出现逐元素 / 归约 / 前缀和 / 掩码。

变量名与公式对标 fla v0.5.2：`fla/ops/kda/chunk.py`（l2norm、beta、g_input→g_cumsum）、
`fla/ops/kda/gate.py`（gate 激活 `b_yg` + chunk 内 cumsum，`scale=RCP_LN2`）、
`fla/ops/kda/chunk_intra.py`（`b_gn/b_gm/b_gq/b_gk/b_Aqk/b_Akk`、逆矩阵 `A`）、
`fla/ops/kda/wy_fast.py`（`b_qg/b_kg/b_kb/b_vb/b_w/b_u`）。
`g_cumsum` 在内核里叫 `gk`。下文左侧是我们文档用的名字，括号里给出 fla 的对应名。

我们的融合：① gate 激活 + chunk 内 cumsum + intra 打分/求逆 + w,u 合成一个算子；
② q/k 的 L2norm 可选进 kernel（对标在 layer 层做）；③ 逆矩阵按两个 32×32 叶块 + 跨叶一次乘
（对标是 16 行前代 + inter-solve）；④ 额外产出反向所需的中间量与 `qg_scaled`；
⑤ **前两个 Vector stage 合并**（v3）。

BT = 64，BC = 16，M 为本 chunk 的有效行数；非 exp2 模式下 exp2 换成 exp（`g_cumsum` 存自然对数域）。

## 0. 排序判据

两个 AIV 子核各跑一个工作项（同一段代码、不同的 head/chunk），因此**单工作项内**：

- Vector 是一条**串行**链；
- Cube 是两个子核共享的单台机器，实测本体只有 **1.4% busy**（case 63：Cube 本体 264 µs / 总 12,184.7 µs）。

⇒ 排序只遵守一条规则：**让 Vector 只在"必须等 Cube"的时刻停**。

数一遍 Vector 对 Cube 的依赖，只有一处：拿到 `Aqk_raw / Akk_raw` 才能做掩码与求逆。此后：

- `X1`、`qg / kg / k_beta / v_beta` 都不依赖 Cube 的任何输出；
- `A_low`、`w`、`u` 只让 **Cube 等 Vector**，反过来不成立。

⇒ 单工作项关键路径 = **ΣV（本工作项全部 Vector 工作量）+ Stage 1（Cube）一次等待**。
合并前两个 Vector stage 后，stage 数从 7 变 6，但 ΣV 与关键路径不变（合并只去掉一个"同回合内的"向量边界）。

## 1. 依赖关系

跨单元的边（右侧是消费者）：

```text
{q, k, g_cumsum}                      → qPos / kPos / kNeg        (V)
{qPos, kPos, kNeg}                    → Aqk_raw / Akk_raw         (V→C)
{Akk_raw, beta}                       → X0                        (C→V)
{Akk_raw, beta}                       → Rs                        (C→V)
{Akk_raw, beta}                       → X1                        (C→V)
{Rs, X0}                              → T                         (V→C)
{X1, T}                               → A_low                     (V→C)
{q, k, g_cumsum, beta, v}             → k_beta / v_beta           (V)
{X0, X1, A_low, k_beta, v_beta}       → w / u                     (V→C)
```

**关键点**：`X1`、`k_beta`、`v_beta` 与 `T` 之间**没有边** —— 这是把 `X1` 从关键路径上摘掉的依据。

## Stage 0：Vector（归一化 + gate + cumsum + 子带因子）

> v2 的 Stage 0 与 Stage 1 合并而来；两段之间原本就没有核间标记，合并不改变任何搬运与同步。

```text
# q/k L2norm（对标 l2norm_fwd）
q_rstd = rsqrt(Σd q ⊙ q + ε)
k_rstd = rsqrt(Σd k ⊙ k + ε)
q = q ⊙ q_rstd
k = k ⊙ k_rstd

# gate 激活（对标 kda_gate_fwd_kernel 的 yg）
A       = A_log
g_input = g + dt_bias
yg = −exp(A) ⊙ softplus(g_input)                      # 默认
   = lower_bound ⊙ sigmoid(exp(A) ⊙ g_input)          # 开了 lower_bound
   = g                                                # 不启用 gate

g_cumsum = cumsum(yg) ⊙ (1/ln2)                       # chunk 内累积（内核参数名 gk）

# beta（对标 chunk.py：beta_raw → beta）
beta = beta_raw
     = sigmoid(beta_raw)                              # use_beta_sigmoid_in_kernel
     = 2 ⊙ sigmoid(beta_raw)                          # 且 allow_neg_eigval

# 子带因子（16 行子带；center = g_cumsum[i_ti + min(BC//2, T − i_ti − 1)]，对标 b_gn）
qPos = q ⊙ 2^(g_cumsum − center)                      # 子带各行（对标 b_q ⊙ b_gq）
kPos = k ⊙ 2^(g_cumsum − center)                      # 子带各行（对标 b_k ⊙ b_gq）
kNeg = k ⊙ 2^(center − g_cumsum)                      # 前缀 16/32/48/64 行（对标 b_k ⊙ b_gk）
```

出参：`gk = g_cumsum`、`q_hat = q`、`k_hat = k`、`q_rstd`、`k_rstd`、`beta_eff = beta`、
`qPos / kPos`（原地覆盖 q/k）、`kNeg`。

本 stage 只有逐元素 / 归约 / 前缀和，不出现 `@`；`qPos / kPos / kNeg` 经 GM→L1 供 Stage 1 装载。
UB live set（单 head）：`q`16 + `k`16 + fp32 暂存块 32（先当 L2norm staging，norm 完改当 `g_cumsum`）
+ `kNeg`40 + 因子 scratch 7 = **111 KiB**（取合并前两段的较大者，预算不涨）。

## Stage 1：Cube

```text
Aqk_raw = qPos @ kNegᵀ                                # 对标 b_Aqk
Akk_raw = kPos @ kNegᵀ                                # 对标 b_Akk
```

`ᵀ` 由 L1 的 NZ 布局（`Nd2Nz` 搬运时的分形重排）直接得到，不是额外运算。
分块顺序建议：**先出 `Akk_raw[0:32, 0:32]`**（= 前两个 16 行子带的列，正是 Stage 2 算 `X0` 要用的那块），
`X0` 就能在 Stage 1 还没跑完时开工。结果写 GM 供 Stage 2。

## Stage 2：Vector（最小前置集）

```text
# 最小前置集：只做 Akk_raw 的左上块与左下块（右下块留给 Stage 4，两块互不重复）
Akk[0:32, 0:32] = tril(Akk_raw[0:32, 0:32] ⊙ beta[0:32], −1)   # 左上叶块（i > j）
Rs              = Akk_raw[32:M, 0:32] ⊙ beta[32:M]               # 左下块：j ≤ 31 < i ⇒ tril 恒等

    X0 = (I + Akk[0:32, 0:32])⁻¹                      # 叶逆，先出先发（对标 fla 的 16 行前代）
```

出参：`X0`、`Rs`。

本 stage 刻意只放这两样：`X1` 与 `Aqk` 的收尾都与 `T` 无关，全部推到 Stage 4。

## Stage 3：Cube

```text
T = Rs @ X0                                           # 仅 M > 32
```

出参：`T`（cube→cube 边，供 Stage 5；不经过 Vector）

## Stage 4：Vector（收容段）

```text
# 掩码收尾（只影响出参 aqk / akk 的打包，与关键路径无关）
Aqk = tril(Aqk_raw ⊙ scale, 0)                        # m_Aqk：i ≥ j（含对角）；全矩阵只做这一次
Akk[32:M, 32:M] = tril(Akk_raw[32:M, 32:M] ⊙ beta[32:M], −1)   # 只补右下叶块

# 第二个叶逆（左上/左下块已在 Stage 2 产出，左下角的 A_low 由 Stage 5 写）
X1 = (I + Akk[32:M, 32:M])⁻¹

# 与 Cube 无依赖的产出（对标 wy_fast 的 b_qg/b_kg/b_kb/b_vb）
gk_last = g_cumsum[最后一行]                           # 对标 b_gn
qg     = q ⊙ 2^g_cumsum                               # 对标 b_qg
kg     = k ⊙ 2^(gk_last − g_cumsum)                    # 对标 b_kg
k_beta = (k ⊙ beta) ⊙ 2^g_cumsum                      # 对标 b_kb
v_beta = v ⊙ beta                                     # 对标 b_vb
```

出参：`aqk = Aqk`、`X1`、`k_beta`、`v_beta`、`qg`、`kg`、`qg_scaled = qg ⊙ scale`。

本段是"收容段"：所有不与 Cube 有依赖的向量活都放这里，正好覆盖 Stage 3 / Stage 5 两段 Cube 的等待。

## Stage 5：Cube

```text
A_low = −X1 @ T                                       # 仅 M > 32；A 的左下块

w = A @ k_beta                                        # A = [[X0, 0], [A_low, X1]]
u = A @ v_beta
```

**不装配 `A`** 时等价地按块展开（每个操作数只有一个生产者，避免三个生产者写同一块 NZ tile）：

```text
w_top = X0    @ k_beta[0:32]
w_bot = A_low @ k_beta[0:32] + X1 @ k_beta[32:M]

u_top = X0    @ v_beta[0:32]
u_bot = A_low @ v_beta[0:32] + X1 @ v_beta[32:M]
```

出参：`akk` 的左下块（= `A_low`）、`w`、`u`。

## 6. 出参 `akk = A` 的组装方式

`A = [[X0, 0], [A_low, X1]]` 由**三块**拼成，来源分散在三个 Stage：

> Akk 的掩码是**按块互斥**做完的：左上块与左下块在 Stage 2 出，右下块在 Stage 4 出，
> 三块的 `tril` / `⊙ beta` 都只算一次（不重复计算同一块）。

| 块 | 内容 | 产出位置 |
|---|---|---|
| `A[0:32, 0:32]` | `X0` | Stage 2（Vector） |
| `A[32:M, 32:M]` | `X1` | Stage 4（Vector） |
| `A[32:M, 0:32]` | `A_low` | Stage 5（Cube） |

三块各写自己的位置即可，**不需要额外的数学步骤**，也不需要"装配完 `A` 再算 `w/u`"。

## 7. 与 v2 的差异

| # | v2 | v3 | 依据 |
|---|---|---|---|
| 1 | 7 段：Stage 0(V) / Stage 1(V) / Stage 2(C) / Stage 3(V) / Stage 4(C) / Stage 5(V) / Stage 6(C) | **6 段**：Stage 0(V, 合并) / Stage 1(C) / Stage 2(V) / Stage 3(C) / Stage 4(V) / Stage 5(C) | 原 Stage 0 与 Stage 1 之间**没有核间标记**（同一 handshake 回合），合并只减 stage 数，不改搬运/同步/计算 |
| 2 | UB live set 分两段算（73 / 111） | 合并段取较大者 **111 KiB** | 合并后同一 stage 内顺序复用同一批 buffer ⇒ 预算不涨 |
| 3 | Stage 3 的 `Akk` 写成整矩阵 `tril(Akk_raw ⊙ beta, −1)`，Stage 5 又写一遍 | **按块互斥**：Stage 2 做左上 + 左下，Stage 4 只补右下 | 原写法会让人以为掩码算两遍；实际只应算一遍（这是 v2 的表述缺陷，v3 修正） |
| 4 | 关键路径 = ΣV + Stage 2(C) 一次等待 | 关键路径不变，写成 ΣV + **Stage 1(C)** 一次等待 | 只有编号变化 |
| 5 | — | 新增：合并段的两件事必须在**同一 stage 内**都做完，因此逐 stage 验证的粒度变粗（`q_hat/k_hat/g_cumsum` 与 `qPos/kPos/kNeg` 一起验证） | 培训约束 19（stage 尽可能少，但不牺牲其它条款）与 §7.2 的逐 stage 验证口径 |

## 8. v1 → v2 的差异（沿用 v2 原文，供追溯）

| v1 | v2 | 依据 |
|---|---|---|
| Stage 0 / 1 / 2 | Stage 0 / 1 / 2 | 不变（Stage 2 仅加一句分块顺序建议） |
| Stage 3：掩码 + 两叶逆 + `A` | Stage 3：掩码最小集 + `X0` + `Rs` | `T` 只依赖 `X0`、`Rs`；`X1` 与 `Aqk` 收尾都不在关键路径上 |
| Stage 4：Cube `T` | Stage 4：Cube `T` | 不变 |
| Stage 5：Cube `A_low` | Stage 6：Cube `A_low` + `w` + `u` | `A_low` 只被 `w/u` 消费，不必单独成段 |
| Stage 6：Vector `qg/kg/k_beta/v_beta` | Stage 5：Vector 收容段 | 与 Cube 无依赖 ⇒ 前移到 `T` 之后、与 Cube 并行 |
| Stage 7：Cube `w/u` | Stage 6：Cube | 同上 |
| 8 段 | 7 段 | 合并一对 Cube 段 + 把 Vector 的活收进一个收容段 |

## 附 A：收益与天花板（case 63 归因）

> 表里的 `V0/V1/V3/V6/C2/C4/5/7` 是**实测归因沿用的旧 8 段编号**；
> 对应关系：`V0+V1` = v3 的 Stage 0，`V3` = v3 的 Stage 2 + Stage 4，`V6` = v3 的 Stage 4，
> `C2` = v3 的 Stage 1，`C4/5/7` = v3 的 Stage 3 + Stage 5。

```text
V0+V1  4,892  40.1%      ← v3 合并后的 Stage 0（一条链）
V3     3,075  25.2%   ← 其中两个叶逆 2,362 = 19.4%
V6     2,002  16.4%
C2     1,988  16.3%
C4/5/7 2,246  18.4%   ← Cube 本体只有 264 µs = 1.4% busy

ΣV = V0+V1 + V3 + V6 = 9,969 µs = 81.8%
```

| 做法 | 等效总时长 | 倍数 |
|---|---|---|
| 现状（8 段回合制） | 12,184.7 µs | 1.00× |
| 只按本版调序（Cube 段藏进 Vector 空隙） | ≈ 9,969 µs | 1.22× |
| 再叠加"叶逆外迁 Cube" | ≈ 8,098 µs | 1.50× |

四条注意：

1. `ΣV` 是聚合等效量、**含等待**（`V3` 里可能含一段"等 C2"）；1.22× 是量级估计，精确值要重采。
2. 单工作项下界不只看聚合量，还要看**单次链长**：把叶逆搬走后 Cube 链相对 Vector 链仍要短（实测比例约 20% 量级，成立）。
3. `Gather` 优化与"叶逆外迁"都打在同一个 2,362 µs 上，**二者不能相加**。
4. 最大的池子在 `V0+V1` 的 4,892 µs（40.1%）——不属于 stage 划分能解决的范围；v3 把它并成一个 stage 也不改变这条。

## 附 B：待定项

1. **同步**：本版只定顺序。要拿到 1.22× 必须把"逐回合 ready→free"换成 per-item flag
   （`X0_ready` / `Rs_ready`），允许 Cube 在 Vector 的 Stage 2 中途起跑。**只改顺序不改握手 = 0 收益。**
2. **"叶逆外迁 Cube"要重算**：当时实测净亏，两条根因是 (a) `L0C→GM→Nd2Nz→L1` 往返 2,025 µs、
   (b) 逐回合 lockstep。(b) 被"同步后补"消掉，(a) 落在 1.4% busy 的 Cube 上 ⇒ 在新前提下由净亏转净赚。
   32 级方案还要多做跨块项与装配，需要重新估。
3. **A5 同名同序**：v1 要求两平台 Stage 函数同名同序（便于逐 Stage 对照）。本版是 A2/A3 视角的顺序；
   A5 侧有 regbase"一次 VF 一个 stage"的约束。**v3 的合并段在 A5 上可能对应两次 VF** ⇒
   要么 A5 侧也合并（若一次 VF 装得下），要么放弃该一致性要求。
4. **Stage 1 的拆分粒度**：`Akk_raw[0:32,0:32]` 先出可让 `X0` 早开工，粒度取多少要与流水一起定。
5. **精度**：本版与 v1/v2 数学等价，理论上位级一致；但 `w/u` 若从"1 次 64×64 MMAD"改成
   "按块 3 次 32×32 累加"，K 方向的累加顺序改变 ⇒ 需重跑精度用例确认。
   `aqk` 的出参时刻后移到 Stage 4（只影响交接时刻，不影响数值）。
6. **合并段的验证粒度（v3 新增）**：`q_hat/k_hat/q_rstd/k_rstd/beta_eff/g_cumsum` 与
   `qPos/kPos/kNeg` 现在同属一个 stage ⇒ 中间量 dump / 逐 stage 对照的最小用例要按合并后的粒度重写。
