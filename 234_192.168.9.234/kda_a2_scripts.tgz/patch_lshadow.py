"""A4′ 前置步骤：让 V3（AIV）把 L 的两个 32x32 对角块落到 payload 尾部空闲区。

依据：`Workspace::kPayload` 现布局用到 0xF800（kVBeta 结束），而 payload 到
0x12000 结束 ⇒ 0xF800~0x11800 有 8 KiB 未被任何 stage 使用；L10 已经以 `B`
(k B = 0x3000) 的形式落在 payload 里，所以只差 L00/L11 两个对角块。

本步骤**只做加法**：不改变任何被现有 stage 消费的数据，用于
  1) 验证 payload 尾部放置不会与其它 stage 冲突（性能/精度必须与改动前一致）；
  2) 给下一步 "cube 侧求逆" 准备好输入（L00/L10/L11 全在 GM 上）。

用法: python patch_lshadow.py <policy.h> <vec.h> [--revert]
"""

from __future__ import annotations

import pathlib
import sys

POLICY_ANCHOR = "constexpr uint32_t kVBeta = 0xB800;\n"
POLICY_NEW = """constexpr uint32_t kVBeta = 0xB800;

// A4′：V3 额外落地的两个 32x32 对角块（L 的 L00/L11），供 cube 侧求逆使用。
// 位于 payload 尾部现未被使用的 8 KiB（0xF800~0x11800，payload 到 0x12000）。
constexpr uint32_t kL00Shadow = 0xF800;
constexpr uint32_t kL11Shadow = 0x10800;
"""

VEC_ANCHOR = """            AscendC::DataCopy(payload[Workspace::kB / sizeof(float)], b, 1024);
        }
"""

VEC_NEW = """            AscendC::DataCopy(payload[Workspace::kB / sizeof(float)], b, 1024);
        }
        // A4′ 前置：把 L 的两个 32x32 对角块落到 payload 尾部空闲区（只做加法，
        // 现有消费方读的位置与语义都不变）。L10 已经以 B 的形式在 payload 里。
        {
            AscendC::GlobalTensor<float> payloadL;
            payloadL.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(
                args_.workspace + slot + Workspace::kPayload));
            // 用块单位的 DataCopyParams（32B/block），避免 UB 侧 stride 单位歧义：
            // lkk 行距 64 元素 = 256 B = 8 block，每行取前 32 元素 = 128 B = 4 block，
            // 所以 srcStride = 8 - 4 = 4；目标连续写。
            AscendC::DataCopyParams lBlock{32, 4, 4, 0};
            AscendC::DataCopy(payloadL[Workspace::kL00Shadow / sizeof(float)],
                              lkk, lBlock);
            AscendC::DataCopy(payloadL[Workspace::kL11Shadow / sizeof(float)],
                              lkk[32 * Shape::kChunkRows + 32], lBlock);
        }
"""


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    policy, vec = sys.argv[1], sys.argv[2]
    revert = "--revert" in sys.argv[3:]
    ptext = pathlib.Path(policy).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    if revert:
        for p, a, b in ((policy, POLICY_NEW, POLICY_ANCHOR),
                        (vec, VEC_NEW, VEC_ANCHOR)):
            text = pathlib.Path(p).read_text(encoding="utf-8")
            if a not in text:
                raise SystemExit(f"[patch_lshadow] revert anchor missing in {p}")
            write_lf(p, text.replace(a, b, 1))
        print("[patch_lshadow] reverted")
        return 0
    if "kL00Shadow" in ptext or "kL00Shadow" in vtext:
        raise SystemExit("[patch_lshadow] already patched")
    if ptext.count(POLICY_ANCHOR) != 1 or vtext.count(VEC_ANCHOR) != 1:
        raise SystemExit(f"[patch_lshadow] anchors: policy="
                         f"{ptext.count(POLICY_ANCHOR)} vec={vtext.count(VEC_ANCHOR)}")
    write_lf(policy, ptext.replace(POLICY_ANCHOR, POLICY_NEW, 1))
    write_lf(vec, vtext.replace(VEC_ANCHOR, VEC_NEW, 1))
    print("[patch_lshadow] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
