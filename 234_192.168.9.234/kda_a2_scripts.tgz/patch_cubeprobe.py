"""A4′ 第三步：在 AIC(C4) 里用 MMAD 连做 X²,X⁴,X⁸，验证 cube 侧增广矩阵求逆的流水。

插入内容来自 cubeprobe_def.txt（probe 函数体）。本补丁只做加法：
  * AIC 在 StageC4 末尾多算一段（3 连乘），结果写 relay 空闲区；
  * 前两步 NZ 落 GM 再搬回 L1（继续平方），最后一步 ROW_MAJOR（供 AIV 直接读）；
  * 对现有精度/性能应当无影响 —— "值是否正确"留到切换消费方那一步，
    届时现有精度标杆天然成为 oracle。

用法: python patch_cubeprobe.py <policy.h> <cube.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
PROBE_DEF = (HERE / "cubeprobe_def.txt").read_text(encoding="utf-8")

POLICY_ANCHOR = "constexpr uint32_t kAugTile = 0x11800;\n"
POLICY_NEW = (
    "constexpr uint32_t kAugTile = 0x11800;\n"
    "\n"
    "// A4′ probe：增广 tile 在 relay 内的偏移，以及 X^8 输出偏移（relay 共 0x5000）。\n"
    "constexpr uint32_t kAugTileInRelay = 0x4000;\n"
    "constexpr uint32_t kAugProbeOut = 0x1000;\n"
)

ROW_ANCHOR = "constexpr AscendC::FixpipeConfig kFixpipeNz = {"
ROW_NEW = ("constexpr AscendC::FixpipeConfig kFixpipeRow = {\n"
           "    AscendC::CO2Layout::ROW_MAJOR, false};\n"
           "constexpr AscendC::FixpipeConfig kFixpipeNz = {")

CALL_ANCHOR = "        StageC4(chunk, localHead);\n"
CALL_NEW = "        StageC4(chunk, localHead);\n"

PROBE_CALL = "        StageC4Probe(chunk, localHead);\n"
DEF_ANCHOR = "    __aicore__ inline void StageC4(const ChunkRange &chunk,"
TAGGED_END = ("        AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>"
              "(tReady_[localHead]);\n")


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    policy, cube = sys.argv[1], sys.argv[2]
    if "--revert" in sys.argv[3:]:
        raise SystemExit("[patch_cubeprobe] revert: 请从备份恢复")
    ptext = pathlib.Path(policy).read_text(encoding="utf-8")
    ctext = pathlib.Path(cube).read_text(encoding="utf-8")
    if "kAugTileInRelay" in ptext or "StageC4Probe" in ctext:
        raise SystemExit("[patch_cubeprobe] already patched")
    if ptext.count(POLICY_ANCHOR) != 1:
        raise SystemExit("[patch_cubeprobe] policy 需先有 kAugTile（patch_aug）")
    if ctext.count(ROW_ANCHOR) != 1 or ctext.count(DEF_ANCHOR) != 1:
        raise SystemExit("[patch_cubeprobe] cube anchors missing")
    if ctext.count(TAGGED_END) != 1:
        raise SystemExit(f"[patch_cubeprobe] tReady anchor count={ctext.count(TAGGED_END)}")

    write_lf(policy, ptext.replace(POLICY_ANCHOR, POLICY_NEW, 1))
    ctext = ctext.replace(ROW_ANCHOR, ROW_NEW, 1)
    # 在 StageC4 末尾（tReady 之后）加 probe 调用
    ctext = ctext.replace(TAGGED_END, TAGGED_END + PROBE_CALL, 1)
    # probe 定义插到 StageC4 定义之前
    idx = ctext.index(DEF_ANCHOR)
    ctext = ctext[:idx] + PROBE_DEF + ctext[idx:]
    write_lf(cube, ctext)
    print("[patch_cubeprobe] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
