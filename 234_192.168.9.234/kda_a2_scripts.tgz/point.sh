#!/bin/bash
# 把 opp/vendors/fla_npu_transformer 软链切到指定 tag（不重编）。
#   bash point.sh e2v2_base
set +u
MY=${MY:-/home/admin123/kda_a2}
PKG=$MY/python-a2c/fla_npu
V=$PKG/opp/vendors/fla_npu_transformer
tag=${1:?usage: point.sh <tag>}
exp=$PKG/opp_vendors/$tag
[ -d "$exp/vendors/fla_npu_transformer" ] || { echo "no pkg: $exp"; exit 1; }
rm -rf "$V"; ln -sT "$exp/vendors/fla_npu_transformer" "$V"
echo "-> $exp/vendors/fla_npu_transformer"
