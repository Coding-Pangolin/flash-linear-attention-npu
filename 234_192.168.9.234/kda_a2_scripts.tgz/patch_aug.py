"""A4′ 数据契约：V3 额外产出"增广矩阵"tile，供 cube 用 X^8 的右上块求 8x8 逆。

数学（§3.7）：对 8x8 严格下三角 N，令 X = [[-N, I],[0, I]]（16x16），
则 X^8 的右上 8x8 块 = Σ_{j=0..7} (-N)^j = (I+N)^{-1}，而且完全不需要显式
构造"加 I"——I 就在 tile 里。这样 cube 侧只要 3 次 MMAD（X²,X⁴,X⁸）就能出
一个 8x8 逆，且**没有 Gather、没有短向量逐行更新**。

tile 布局：32 宽 × 16 高 fp32（2 KiB，行距 4 block）——真正的 16x16 增广矩阵
在左边 16 列；右边 16 列是 stride padding。之所以取 32 宽：这样对角元素落在
"同一 lane、每 32 block 重复"的位置，可以用 mask+repStride 一次写完
（16 宽的行距是 2 block，对角元素字节偏移不是 32B 对齐，写不了）。

本补丁只做**加法**（新增一块 GM 写入，不改变任何被消费的数据），
用来验证 tile 生成不破坏现有行为；cube 侧消费在下一步。

用法: python patch_aug.py <policy.h> <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

POLICY_ANCHOR = "constexpr uint32_t kL11Shadow = 0x10800;\n"
POLICY_NEW = """constexpr uint32_t kL11Shadow = 0x10800;

// A4′：8x8 逆用的"增广矩阵" tile（32 宽 x 16 高 fp32 = 2 KiB），
// 位置在 payload 尾部剩余空间（0x11800 ~ 0x12000）。
constexpr uint32_t kAugTile = 0x11800;
"""

VEC_ANCHOR = """            AscendC::DataCopy(payloadL[Workspace::kL11Shadow / sizeof(float)],
                              lkk[32 * Shape::kChunkRows + 32], lBlock);
        }
"""

VEC_NEW = """            AscendC::DataCopy(payloadL[Workspace::kL11Shadow / sizeof(float)],
                              lkk[32 * Shape::kChunkRows + 32], lBlock);
        }
        // A4′ 数据契约：为 L00 的 (0,0) 8x8 子块生成增广矩阵
        //   X = [[-N, I],[0, I]]（32 宽 x 16 高，左边 16 列是真正的 16x16）。
        // 只用向量指令：先零，再用带 block 步长的 Sub 把 -N 写进左上 8x8，
        // 最后用 mask+repStride=32 block 写两个 I8。
        if (chunk.validRows >= 8) {
            auto augBase =
                ub[Arch22Ub::kSharedScratch].template ReinterpretCast<float>();
            auto augTile = augBase;
            auto augZero = augBase[512];   // 8 个零：给 Sub 当 src0（repStride=0）
            AscendC::Duplicate(augTile, 0.0F, 512);
            AscendC::Duplicate(augZero, 0.0F, 8);
            AscendC::PipeBarrier<PIPE_V>();
            // dst = 0 - lkk 的左上 8x8：src0 用 repStride=0 反复读独立零块
            // （不能读 augTile 自己，否则第一行写完就被后面几行读到），
            // src1 = lkk 行距 8 block、每行取 1 block。
            AscendC::Sub(augTile, augZero, lkk, 8, 8, {1, 1, 1, 4, 0, 8});
            AscendC::PipeBarrier<PIPE_V>();
            // 两个 I8 都用"行首对齐的基址 + mask 选中块内 lane"的写法（VEC 的 dst
            // 必须 32B 对齐）：元素 (i, 8+i) 在第 1 个 block 的 lane i 上，8 行
            // 之后 block 前进 33（8 行 = 32 block，另加 8 列 = 1 block）。
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[lane * 32], 1.0F, mask, 1, 1, 33);
            }
            // 右下 I8：(8+i, 8+i) → 基址取第 8+lane 行行首，同样 mask 选块 1 的 lane
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[(8 + lane) * 32], 1.0F, mask, 1, 1,
                                   33);
            }
            AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            AscendC::GlobalTensor<float> payloadT;
            payloadT.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(
                args_.workspace + slot + Workspace::kPayload));
            AscendC::DataCopy(payloadT[Workspace::kAugTile / sizeof(float)],
                              augTile, 512);
        }
"""


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    policy, vec = sys.argv[1], sys.argv[2]
    if "--revert" in sys.argv[3:]:
        for p, a, b in ((policy, POLICY_NEW, POLICY_ANCHOR),
                        (vec, VEC_NEW, VEC_ANCHOR)):
            text = pathlib.Path(p).read_text(encoding="utf-8")
            if a not in text:
                raise SystemExit(f"[patch_aug] revert anchor missing in {p}")
            write_lf(p, text.replace(a, b, 1))
        print("[patch_aug] reverted")
        return 0
    ptext = pathlib.Path(policy).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    if "kAugTile" in ptext or "augTile" in vtext:
        raise SystemExit("[patch_aug] already patched")
    if ("kL11Shadow" not in ptext) or ptext.count(POLICY_ANCHOR) != 1:
        raise SystemExit("[patch_aug] policy 缺 kL11Shadow（需先打 patch_lshadow）")
    if vtext.count(VEC_ANCHOR) != 1:
        raise SystemExit(f"[patch_aug] vec anchor count={vtext.count(VEC_ANCHOR)}")
    write_lf(policy, ptext.replace(POLICY_ANCHOR, POLICY_NEW, 1))
    write_lf(vec, vtext.replace(VEC_ANCHOR, VEC_NEW, 1))
    print("[patch_aug] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
