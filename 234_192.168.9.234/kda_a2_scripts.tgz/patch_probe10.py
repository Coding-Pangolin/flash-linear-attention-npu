"""probe10（P4）：norm 尾部的"逐行标量缩放"改成 Brcb + 行列重复展开 + 整块 Mul。

依据：P3-A 实测说明 norm 尾部的开销主要在**标量↔向量往返**
（去掉 128 次 GetValue/SetValue 省了 416 µs）。剩下那趟
`for row: scales[row]=rstdOut.GetValue(row)` + `for row: Muls(..., scales[row], 128)`
同样是 64 次标量读 + 64 条逐行指令；而本仓 V6 的 beta 路径已经有一套**验证过**的
等价写法：`Brcb` 把"每行一个标量"展开成"每行一个 32B block"，
`ReplicateRowScalarsToRepeat` 再复制成"每行 8 个 block（填满 64 lane repeat）"，
最后 `MulTileByRowScalars` 用两条整块 Mul 完成低/高半行。

数学不变（同一个 fp32 乘法、同一对操作数）⇒ 结果应与改动前**逐位一致**。
缓冲区：workspace = 共享 scratch（2048 fp32）；brcbScalars 用 [640,1152)、
repeatScalars 用 [1152,1600)，都在可用范围（<1984）内。

用法: python3 patch_probe10.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

OLD = """        float scales[Shape::kChunkRows];
        {
            AscendC::SetFlag<AscendC::HardEvent::V_S>(scalarRead_);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(scalarRead_);
            for (uint32_t row = 0; row < validRows; ++row) {
                scales[row] = rstdOut.GetValue(row);
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(scalarWrite_);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(scalarWrite_);
        }
        // 逐行缩放与回写：不同行落在互不重叠的 UB 区间，因此不需要逐行屏障。
        for (uint32_t row = 0; row < validRows; ++row) {
            AscendC::Muls(staging[row * Shape::kHeadDim],
                          staging[row * Shape::kHeadDim], scales[row],
                          Shape::kHeadDim);
        }
        for (uint32_t row = 0; row < validRows; ++row) {
            AscendC::Cast(src[row * Shape::kHeadDim],
                          staging[row * Shape::kHeadDim],
                          AscendC::RoundMode::CAST_RINT, Shape::kHeadDim);
        }
        AscendC::PipeBarrier<PIPE_V>();
    }
"""

NEW = """        // P4：逐行缩放改成 "Brcb + 行列重复展开 + 整块 Mul"（与 V6 beta 路径同款），
        // 去掉 64 次标量 GetValue 与 64 条逐行 Muls/Cast；数学不变（结果应逐位一致）。
        // 缓冲区：workspace 共 2048 fp32，这里用 [640,1152) 与 [1152,1600)。
        auto brcbScalars = workspace[640];       // 64 blocks = 512 fp32
        auto repeatScalars = workspace[1152];    // 7 行 x 8 block = 448 fp32
        AscendC::Brcb(brcbScalars, rstdOut,
                      static_cast<uint8_t>(Shape::kChunkRows / 8), {1, 8});
        AscendC::PipeBarrier<PIPE_V>();
        constexpr uint32_t kScaleRows = 7;
        for (uint32_t rowBegin = 0; rowBegin < validRows;
             rowBegin += kScaleRows) {
            const uint32_t rows = validRows - rowBegin < kScaleRows
                                      ? validRows - rowBegin
                                      : kScaleRows;
            ReplicateRowScalarsToRepeat(repeatScalars,
                                        brcbScalars[8 * rowBegin], rows);
            AscendC::PipeBarrier<PIPE_V>();
            MulTileByRowScalars(staging[rowBegin * Shape::kHeadDim],
                                staging[rowBegin * Shape::kHeadDim],
                                repeatScalars, rows);
            AscendC::PipeBarrier<PIPE_V>();
            AscendC::Cast(src[rowBegin * Shape::kHeadDim],
                          staging[rowBegin * Shape::kHeadDim],
                          AscendC::RoundMode::CAST_RINT,
                          rows * Shape::kHeadDim);
            AscendC::PipeBarrier<PIPE_V>();
        }
    }
"""


def main() -> int:
    path = sys.argv[1]
    revert = len(sys.argv) > 2 and sys.argv[2] == "--revert"
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8")
    if revert:
        if src.count(NEW) != 1:
            raise SystemExit("[patch_probe10] revert anchor missing")
        src = src.replace(NEW, OLD, 1)
        p.write_text(src, encoding="utf-8", newline="\n")
        print("[patch_probe10] reverted")
        return 0
    if src.count(OLD) != 1:
        raise SystemExit(f"[patch_probe10] anchor x{src.count(OLD)}")
    src = src.replace(OLD, NEW, 1)
    p.write_text(src, encoding="utf-8", newline="\n")
    print("[patch_probe10] applied (P4: Brcb row-scale in norm)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
