# -----------------------------------------------------------------------------------------------------------
# Copyright (c) 2026 Tianjin University, Ltd.
# This program is free software, you can redistribute it and/or modify it under the terms and conditions of
# CANN Open Software License Agreement Version 2.0 (the "License").
# Please refer to the License for details. You may not use this file except in compliance with the License.
# THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
# INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
# See LICENSE in the root of the software repository for the full text of the License.
# -----------------------------------------------------------------------------------------------------------

"""ctypes backed Python wrappers for FLA NPU Ascend C operators.

This file intentionally contains only concrete operator wrappers and their ABI
quirks.  Shared descriptor, workspace and stream handling lives in ``_runtime``
so a new operator developer only needs to mirror the matching ``aclnn_*.h``
signature here.
"""

from __future__ import annotations

import ctypes
import sys

from ._kda_policy import (
    kda_fwd_optional_output_mask,
    _select_kda_bwd_optimized,
    _prepare_kda_bwd_optimized,
)
from ._runtime import (
    ACL_FORMAT_NCDHW,
    ACL_FORMAT_NCHW,
    ACL_FORMAT_NCL,
    ACL_FORMAT_ND,
    acl_format as _acl_format,
    call_aclnn as _runtime_call_aclnn,
    chunk_num as _chunk_num,
    empty as _empty,
    empty_like as _empty_like,
    optional_bool as _optional_bool,
    optional_float as _optional_float,
    optional_int as _optional_int,
    shape as _shape,
    zeros as _zeros,
)

# Most aclnn functions only receive pointer-sized descriptors and scalar ctypes
# objects, so ctypes can call them without explicit argtypes.  Functions with C
# strings or otherwise ambiguous scalar conversion are listed here to prevent
# ctypes from narrowing or mis-converting arguments.
_GET_WORKSPACE_ARGTYPES = {
    "aclnnCausalConv1d": [
        ctypes.c_void_p,  # x
        ctypes.c_void_p,  # weight
        ctypes.c_void_p,  # biasOptional
        ctypes.c_void_p,  # convStatesOptional
        ctypes.c_void_p,  # queryStartLocOptional
        ctypes.c_void_p,  # cacheIndicesOptional
        ctypes.c_void_p,  # hasInitialStateOptional
        ctypes.c_void_p,  # numAcceptedTokensOptional
        ctypes.c_void_p,  # queryStartLocCpuOptional
        ctypes.c_void_p,  # cacheIndicesCpuOptional
        ctypes.c_void_p,  # hasInitialStateCpuOptional
        ctypes.c_void_p,  # numAcceptedTokensCpuOptional
        ctypes.c_char_p,  # activation
        ctypes.c_int64,  # padSlotId
        ctypes.c_int64,  # nullBlockId
        ctypes.c_int64,  # runMode
        ctypes.c_int64,  # headNum
        ctypes.c_int64,  # maxQueryLen
        ctypes.c_void_p,  # y
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkFwdO": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # h
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # chunkOffsetsOptional
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunkSize
        ctypes.c_bool,  # useExp2
        ctypes.c_bool,  # stateVFirst
        ctypes.c_char_p,  # outputLayout
        ctypes.c_void_p,  # oOut
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkKdaFwdFinalize": [
        *([ctypes.c_void_p] * 6),  # qgScaled, aqk, vNew, h, cuSeqlens, chunkIndices
        ctypes.c_char_p,  # outputLayout
        ctypes.c_bool,  # stateVFirst
        ctypes.c_void_p,  # attnOut
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkGatedDeltaRuleBwdFinalize": [
        *([ctypes.c_void_p] * 14),  # required and optional tensor descriptors
        ctypes.c_void_p,  # cu_seqlens optional
        ctypes.c_void_p,  # chunk_indices optional
        ctypes.c_double,
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_bool,
        *([ctypes.c_void_p] * 5),  # dq, dk, dv, dbeta, dg
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnPrepareWyReprBwd": [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int64,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnCausalConv1dBwd": [
        ctypes.c_void_p,  # x
        ctypes.c_void_p,  # yOptional
        ctypes.c_void_p,  # weight
        ctypes.c_void_p,  # dy
        ctypes.c_void_p,  # initialStateOptional
        ctypes.c_void_p,  # dhtOptional
        ctypes.c_void_p,  # queryStartLocOptional
        ctypes.c_int64,  # activation
        ctypes.c_char_p,  # inputLayoutOptional
        ctypes.c_void_p,  # dxOut
        ctypes.c_void_p,  # dwOutOptional
        ctypes.c_void_p,  # dbOutOptional
        ctypes.c_void_p,  # dh0OutOptional
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkGatedDeltaRuleFwd": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # aLogOptional
        ctypes.c_void_p,  # dtBiasOptional
        ctypes.c_void_p,  # initialStateOptional
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # chunkIndicesOptional
        ctypes.c_char_p,  # layout
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunkSize
        ctypes.c_bool,  # useExp2
        ctypes.c_bool,  # useQkL2norm
        ctypes.c_bool,  # allowNegEigval
        ctypes.c_bool,  # stateVFirst
        ctypes.c_void_p,  # oOut
        ctypes.c_void_p,  # finalStateOutOptional
        ctypes.c_void_p,  # qHatOutOptional
        ctypes.c_void_p,  # kHatOutOptional
        ctypes.c_void_p,  # qRstdOutOptional
        ctypes.c_void_p,  # kRstdOutOptional
        ctypes.c_void_p,  # betaEffOutOptional
        ctypes.c_void_p,  # gCumsumOutOptional
        ctypes.c_void_p,  # aOutOptional
        ctypes.c_void_p,  # hOutOptional
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkGatedDeltaRuleBwdDhu": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # w
        ctypes.c_void_p,  # dO
        ctypes.c_void_p,  # dv
        ctypes.c_void_p,  # gOptional
        ctypes.c_void_p,  # gkOptional
        ctypes.c_void_p,  # h0Optional
        ctypes.c_void_p,  # dhtOptional
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # chunkIndicesOptional
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunkSize
        ctypes.c_bool,  # useExp2
        ctypes.c_bool,  # stateVFirst
        ctypes.c_void_p,  # dhOut
        ctypes.c_void_p,  # dh0Out
        ctypes.c_void_p,  # dv2Out
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkGatedDeltaRuleBwd": [
        *([ctypes.c_void_p] * 14),  # tensors through dtBiasOptional
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # chunkIndicesOptional
        ctypes.c_char_p,  # layout
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunkSize
        ctypes.c_bool,  # useExp2
        ctypes.c_bool,  # useGateInKernel
        ctypes.c_bool,  # useQkL2normInKernel
        ctypes.c_bool,  # useBetaSigmoidInKernel
        ctypes.c_bool,  # stateVFirst
        *([ctypes.c_void_p] * 8),  # dq, dk, dv, dbeta, dg, dh0, dALog, dDtBias
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkGdnBwdIntra": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # A
        ctypes.c_void_p,  # dO
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # chunkIndicesOptional
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunkSize
        ctypes.c_bool,  # useExp2
        ctypes.c_void_p,  # wOut
        ctypes.c_void_p,  # uOut
        ctypes.c_void_p,  # dvLocalOut
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkGatedDeltaRuleFwdPrepare": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # aLogOptional
        ctypes.c_void_p,  # dtBiasOptional
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # chunkIndicesOptional
        ctypes.c_int64,  # chunkSize
        ctypes.c_bool,  # allowNegEigval
        ctypes.c_bool,  # useExp2
        ctypes.c_bool,  # outputA
        ctypes.c_void_p,  # gOut
        ctypes.c_void_p,  # wOut
        ctypes.c_void_p,  # uOut
        ctypes.c_void_p,  # aOut
        ctypes.c_void_p,  # qHatOptional
        ctypes.c_void_p,  # kHatOptional
        ctypes.c_void_p,  # qRstdOptional
        ctypes.c_void_p,  # kRstdOptional
        ctypes.c_void_p,  # betaEffOptional
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnSolveTri": [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnChunkKdaFwd": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # a_log（可选）
        ctypes.c_void_p,  # dt_bias（可选）
        ctypes.c_void_p,  # initial_state（可选）
        ctypes.c_void_p,  # cu_seqlens（可选，int array）
        ctypes.c_void_p,  # chunk_indices（可选，int array）
        ctypes.c_char_p,  # layout
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunk_size
        ctypes.c_bool,  # safe_gate
        ctypes.c_double,  # lower_bound
        ctypes.c_bool,  # use_gate_in_kernel
        ctypes.c_bool,  # state_v_first
        ctypes.c_void_p,  # attn_out（输出）
        ctypes.c_void_p,  # final_state（输出，可选）
        ctypes.c_void_p,  # gk（输出，可选）
        ctypes.c_void_p,  # Aqk（输出）
        ctypes.c_void_p,  # Akk（输出，可选）
        ctypes.c_void_p,  # w（输出，可选）
        ctypes.c_void_p,  # u（输出，可选）
        ctypes.c_void_p,  # qg（输出，可选）
        ctypes.c_void_p,  # kg（输出，可选）
        ctypes.c_void_p,  # v_new（输出，可选）
        ctypes.c_void_p,  # h（输出，可选）
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize（输出）
        ctypes.POINTER(ctypes.c_void_p),  # executor（输出）
    ],
    "aclnnChunkKdaFwdPrepare": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # a_log（可选）
        ctypes.c_void_p,  # dt_bias（可选）
        ctypes.c_void_p,  # cu_seqlens（可选，int array）
        ctypes.c_void_p,  # chunk_indices（可选，int array）
        ctypes.c_char_p,  # layout
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunk_size
        ctypes.c_double,  # epsilon
        ctypes.c_bool,  # use_qk_l2norm_in_kernel
        ctypes.c_bool,  # use_gate_in_kernel
        ctypes.c_bool,  # use_beta_sigmoid_in_kernel
        ctypes.c_bool,  # allow_neg_eigval
        ctypes.c_bool,  # safe_gate
        ctypes.c_double,  # lower_bound
        ctypes.c_bool,  # use_exp2
        ctypes.c_void_p,  # gk（输出，可选）
        ctypes.c_void_p,  # Aqk（输出，可选）
        ctypes.c_void_p,  # Akk（输出，可选）
        ctypes.c_void_p,  # w（输出，可选）
        ctypes.c_void_p,  # u（输出，可选）
        ctypes.c_void_p,  # qg（输出，可选）
        ctypes.c_void_p,  # kg（输出，可选）
        ctypes.c_void_p,  # qg_scaled（输出，可选，供 finalize 用）
        ctypes.c_void_p,  # q_hat（输出，可选）
        ctypes.c_void_p,  # k_hat（输出，可选）
        ctypes.c_void_p,  # q_rstd（输出，可选）
        ctypes.c_void_p,  # k_rstd（输出，可选）
        ctypes.c_void_p,  # beta_eff（输出，可选）
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize（输出）
        ctypes.POINTER(ctypes.c_void_p),  # executor（输出）
    ],
    "aclnnChunkKdaFwdV2": [
        ctypes.c_void_p,  # q
        ctypes.c_void_p,  # k
        ctypes.c_void_p,  # v
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # a_log（可选）
        ctypes.c_void_p,  # dt_bias（可选）
        ctypes.c_void_p,  # initial_state（可选）
        ctypes.c_void_p,  # cu_seqlens（可选，int array）
        ctypes.c_void_p,  # chunk_indices（可选，int array）
        ctypes.c_char_p,  # layout
        ctypes.c_double,  # scale
        ctypes.c_int64,  # chunk_size
        ctypes.c_bool,  # safe_gate
        ctypes.c_double,  # lower_bound
        ctypes.c_bool,  # use_gate_in_kernel
        ctypes.c_bool,  # state_v_first
        ctypes.c_double,  # epsilon
        ctypes.c_bool,  # use_qk_l2norm_in_kernel
        ctypes.c_bool,  # use_beta_sigmoid_in_kernel
        ctypes.c_bool,  # allow_neg_eigval
        ctypes.c_bool,  # use_exp2
        ctypes.c_void_p,  # attn_out（输出）
        ctypes.c_void_p,  # final_state（输出，可选）
        ctypes.c_void_p,  # gk（输出，可选）
        ctypes.c_void_p,  # Aqk（输出）
        ctypes.c_void_p,  # Akk（输出，可选）
        ctypes.c_void_p,  # w（输出，可选）
        ctypes.c_void_p,  # u（输出，可选）
        ctypes.c_void_p,  # qg（输出，可选）
        ctypes.c_void_p,  # kg（输出，可选）
        ctypes.c_void_p,  # v_new（输出，可选）
        ctypes.c_void_p,  # h（输出，可选）
        ctypes.c_void_p,  # q_hat（输出，可选，L2Norm 保存值）
        ctypes.c_void_p,  # k_hat（输出，可选，L2Norm 保存值）
        ctypes.c_void_p,  # q_rstd（输出，可选，L2Norm 保存值）
        ctypes.c_void_p,  # k_rstd（输出，可选，L2Norm 保存值）
        ctypes.c_void_p,  # beta_eff（输出，可选，sigmoid 后的 beta）
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize（输出）
        ctypes.POINTER(ctypes.c_void_p),  # executor（输出）
    ],
    "aclnnChunkKdaBwdIntra": [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnChunkKdaBwd": [
        *([ctypes.c_void_p] * 20),
        ctypes.c_double,
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_double,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_bool,
        *([ctypes.c_void_p] * 8),
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnChunkKdaBwdV2": [
        *([ctypes.c_void_p] * 20),
        ctypes.c_double, ctypes.c_int64, ctypes.c_bool, ctypes.c_bool,
        ctypes.c_double, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
        *([ctypes.c_void_p] * 10),  # rstd pair followed by eight public output slots
        ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnChunkKdaBwdRecompute": [
        *([ctypes.c_void_p] * 10),
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_double,
        *([ctypes.c_void_p] * 5),
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnKdaGateCumsum": [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_double,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnRecurrentKda": [
        ctypes.c_void_p,  # query
        ctypes.c_void_p,  # key
        ctypes.c_void_p,  # value
        ctypes.c_void_p,  # gate
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # initialStateRef
        ctypes.c_void_p,  # cuSeqlensOptional
        ctypes.c_void_p,  # ssmStateIndicesOptional
        ctypes.c_void_p,  # aLogOptional
        ctypes.c_void_p,  # dtBiasOptional
        ctypes.c_void_p,  # numAcceptedTokensOptional
        ctypes.c_char_p,
        ctypes.c_double,
        ctypes.c_bool,  # outputFinalState
        ctypes.c_bool,  # inplaceFinalState
        ctypes.c_bool,  # useQkL2normInKernel
        ctypes.c_bool,  # useGateInKernel
        ctypes.c_bool,  # useBetaSigmoidInKernel
        ctypes.c_bool,  # allowNegEigval
        ctypes.c_bool,  # safeGate
        ctypes.c_double,
        ctypes.c_bool,  # stateVFirst
        ctypes.c_void_p,  # attnOut
        ctypes.c_void_p,  # finalState
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnRecurrentGatedDeltaRule": [
        ctypes.c_void_p,  # query
        ctypes.c_void_p,  # key
        ctypes.c_void_p,  # value
        ctypes.c_void_p,  # beta
        ctypes.c_void_p,  # stateRef
        ctypes.c_void_p,  # actualSeqLengths
        ctypes.c_void_p,  # ssmStateIndices
        ctypes.c_void_p,  # g
        ctypes.c_void_p,  # gk
        ctypes.c_void_p,  # numAcceptedTokens
        ctypes.c_float,  # scaleValue
        ctypes.c_void_p,  # out
        ctypes.POINTER(ctypes.c_uint64),  # workspaceSize
        ctypes.POINTER(ctypes.c_void_p),  # executor
    ],
    "aclnnChunkLocalCumsum": [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_double,
        ctypes.c_bool,
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnChunkScaledDotKkt": [
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_int64,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
    "aclnnChunkFwdH": [
        *([ctypes.c_void_p] * 6),
        ctypes.c_bool,
        ctypes.c_int64,
        ctypes.c_bool,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.POINTER(ctypes.c_uint64),
        ctypes.POINTER(ctypes.c_void_p),
    ],
}


def _call_aclnn(
    name: str,
    build_args,
    outputs,
):
    return _runtime_call_aclnn(
        name,
        build_args,
        outputs,
        get_workspace_argtypes=_GET_WORKSPACE_ARGTYPES.get(name),
    )


def npu_fast_gelu_custom(self):
    out = _empty_like(self)
    return _call_aclnn(
        "aclnnFastGelu",
        lambda ctx: [ctx.tensor(self, "self"), ctx.tensor(out, "out")],
        out,
    )


def npu_fast_gelu_custom_backward(grad, self):
    out = _empty_like(grad)
    return _call_aclnn(
        "aclnnFastGeluBackward",
        lambda ctx: [ctx.tensor(grad, "grad"), ctx.tensor(self, "self"), ctx.tensor(out, "out")],
        out,
    )


def npu_prepare_wy_repr_bwd_full(
    k,
    v,
    beta,
    A,
    dA,
    dw,
    du,
    g,
    chunk_size,
    *,
    cu_seqlens=None,
    chunk_indices=None,
):
    dk = _empty_like(k)
    dv = _empty_like(v)
    dbeta = _empty_like(beta)
    dg = _empty_like(g)
    outputs = (dk, dv, dbeta, dg)
    return _call_aclnn(
        "aclnnPrepareWyReprBwdFull",
        lambda ctx: [
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(A, "A"),
            ctx.tensor(dA, "dA"),
            ctx.tensor(dw, "dw"),
            ctx.tensor(du, "du"),
            ctx.tensor(g, "g"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_int64(int(chunk_size)),
            ctx.tensor(dk, "dk"),
            ctx.tensor(dv, "dv"),
            ctx.tensor(dbeta, "dbeta"),
            ctx.tensor(dg, "dg"),
        ],
        outputs,
    )


def npu_prepare_wy_repr_bwd(
    k,
    v,
    beta,
    A,
    dw,
    du,
    g,
    chunk_size,
    *,
    cu_seqlens=None,
    chunk_indices=None,
):
    dk = _empty_like(k)
    dv = _empty_like(v)
    dbeta = _empty_like(beta)
    dg = _empty_like(g)
    outputs = (dk, dv, dbeta, dg)
    return _call_aclnn(
        "aclnnPrepareWyReprBwd",
        lambda ctx: [
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(A, "A"),
            ctx.tensor(dw, "dw"),
            ctx.tensor(du, "du"),
            ctx.tensor(g, "g"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_int64(int(chunk_size)),
            ctx.tensor(dk, "dk"),
            ctx.tensor(dv, "dv"),
            ctx.tensor(dbeta, "dbeta"),
            ctx.tensor(dg, "dg"),
        ],
        outputs,
    )


def npu_chunk_gated_delta_rule_bwd_dhu(
    q,
    k,
    w,
    d_o,
    dv,
    scale,
    chunk_size,
    *,
    g=None,
    gK=None,
    h0=None,
    dht=None,
    cu_seqlens=None,
    chunk_indices=None,
    use_exp2=False,
    transpose_state_layout=False,
):
    import torch

    q_shape = _shape(q)
    dv_shape = _shape(dv)
    B, _, T, K = q_shape
    Hv, V = dv_shape[1], dv_shape[3]
    if (g is None) == (gK is None):
        raise ValueError("Exactly one of g and gK must be provided.")
    if gK is not None and not _optional_bool(use_exp2, True):
        raise ValueError("use_exp2 must be true when gK is provided.")
    if any(tensor.dtype != q.dtype for tensor in (k, w, d_o, dv)):
        raise ValueError("q, k, w, d_o and dv must have the same dtype.")
    gate = g if g is not None else gK
    if gate.dtype not in (q.dtype, torch.float32):
        raise ValueError("g or gK must be float32 or have the same dtype as q and k.")
    if g is not None and _shape(g) != (B, Hv, T):
        raise ValueError(f"g must have shape {(B, Hv, T)}, got {_shape(g)}.")
    if gK is not None and _shape(gK) != (B, Hv, T, K):
        raise ValueError(f"gK must have shape {(B, Hv, T, K)}, got {_shape(gK)}.")
    NT = _chunk_num(T, int(chunk_size), chunk_indices)
    N = len(cu_seqlens) - 1 if cu_seqlens is not None else B
    state_v_first = _optional_bool(transpose_state_layout, False)
    state_tail = (V, K) if state_v_first else (K, V)
    dh = _empty((B, Hv, NT, K, V), q)
    dh0_shape = (N, Hv, *state_tail)
    dh0 = _empty(dh0_shape, q) if h0 is not None else None
    dv2 = _empty_like(dv)
    outputs = (dh, dh0, dv2)

    def logical_tensor(ctx, tensor, name):
        if tensor is None:
            return ctx.tensor(tensor, name)
        return ctx.tensor(tensor, name, storage_shape_override=_shape(tensor))

    return _call_aclnn(
        "aclnnChunkGatedDeltaRuleBwdDhu",
        lambda ctx: [
            logical_tensor(ctx, q, "q"),
            logical_tensor(ctx, k, "k"),
            logical_tensor(ctx, w, "w"),
            logical_tensor(ctx, d_o, "d_o"),
            logical_tensor(ctx, dv, "dv"),
            logical_tensor(ctx, g, "g"),
            logical_tensor(ctx, gK, "gK"),
            logical_tensor(ctx, h0, "h0"),
            logical_tensor(ctx, dht, "dht"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_double(float(scale)),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(_optional_bool(use_exp2, gK is not None)),
            ctypes.c_bool(_optional_bool(state_v_first, False)),
            logical_tensor(ctx, dh, "dh"),
            logical_tensor(ctx, dh0, "dh0"),
            logical_tensor(ctx, dv2, "dv2"),
        ],
        outputs,
    )


def npu_chunk_gated_delta_rule_bwd(
    q,
    k,
    v,
    g,
    beta,
    A,
    d_o,
    scale,
    *,
    chunk_size=64,
    cu_seqlens=None,
    chunk_indices=None,
    initial_state=None,
    dht=None,
    q_rstd=None,
    k_rstd=None,
    beta_raw=None,
    use_exp2=False,
    use_qk_l2norm_in_kernel=False,
    use_gate_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    allow_neg_eigval=False,
    return_intermediate_states=False,
    state_v_first=False,
    a_log=None,
    dt_bias=None,
    layout="BNSD",
):
    """Run the composite chunk gated delta rule backward graph."""
    import torch

    q_shape = _shape(q)
    k_shape = _shape(k)
    v_shape = _shape(v)
    layout = str(layout)
    if layout not in ("BNSD", "BSND", "NTD", "TND"):
        raise ValueError("layout must be BNSD, BSND, NTD or TND.")
    if len(q_shape) != 4 or len(k_shape) != 4 or len(v_shape) != 4:
        raise ValueError("q, k and v must be rank-4 tensors.")
    if q_shape != k_shape:
        raise ValueError("q and k must have identical shapes.")
    sequence_major = layout in ("BSND", "TND")
    if sequence_major:
        batch, tokens, key_heads, key_dim = q_shape
        value_batch, value_tokens, value_heads, value_dim = v_shape
    else:
        batch, key_heads, tokens, key_dim = q_shape
        value_batch, value_heads, value_tokens, value_dim = v_shape
    if value_batch != batch or value_tokens != tokens:
        raise ValueError("q/k and v must share B and T.")
    if key_dim != 128 or value_dim != 128 or int(chunk_size) != 64:
        raise ValueError("the composite currently requires K=V=128 and chunk_size=64.")
    if value_heads % key_heads != 0 or value_heads // key_heads not in (1, 2, 3, 4):
        raise ValueError("HV/HK must be an integer in [1, 4].")
    scalar_input_shape = (batch, tokens, value_heads)
    if _shape(g) != scalar_input_shape or _shape(beta) != scalar_input_shape:
        raise ValueError("g and beta must be BSN [B, T, HV].")
    if g.dtype not in (torch.bfloat16, torch.float32) or beta.dtype not in (
        torch.bfloat16,
        torch.float32,
    ):
        raise ValueError("g and beta must use bfloat16 or float32.")
    if _shape(d_o) != (batch, tokens, value_heads, value_dim):
        raise ValueError("d_o must be BSND [B, T, HV, V].")
    if _shape(A) != (batch, value_heads, tokens, int(chunk_size)):
        raise ValueError("A must have BNSD shape [B, HV, T, chunk_size].")
    if (cu_seqlens is None) != (chunk_indices is None):
        raise ValueError("cu_seqlens and chunk_indices must be provided together.")
    if cu_seqlens is not None and batch != 1:
        raise ValueError("varlen rank-4 input requires B=1.")

    use_exp2 = _optional_bool(use_exp2, True)
    use_gate_in_kernel = _optional_bool(use_gate_in_kernel, False)
    use_qk_l2norm_in_kernel = _optional_bool(use_qk_l2norm_in_kernel, False)
    use_beta_sigmoid_in_kernel = _optional_bool(use_beta_sigmoid_in_kernel, False)
    state_v_first = _optional_bool(state_v_first, False)
    # Reserved for ABI compatibility; intermediate tensors remain executor-private.
    _optional_bool(return_intermediate_states, False)
    if use_gate_in_kernel:
        raise ValueError("use_gate_in_kernel=True is not supported.")
    if use_qk_l2norm_in_kernel != (q_rstd is not None and k_rstd is not None):
        raise ValueError("q_rstd and k_rstd must be provided exactly when Q/K L2Norm backward is enabled.")
    if use_beta_sigmoid_in_kernel != (beta_raw is not None):
        raise ValueError("beta_raw must be provided exactly when beta sigmoid backward is enabled.")
    expected_norm_shape = (batch, key_heads, tokens)
    if q_rstd is not None:
        if _shape(q_rstd) != expected_norm_shape or _shape(k_rstd) != expected_norm_shape:
            raise ValueError(f"q_rstd and k_rstd must have shape {expected_norm_shape}.")
        if q_rstd.dtype != torch.float32 or k_rstd.dtype != torch.float32:
            raise ValueError("q_rstd and k_rstd must use float32.")
    if beta_raw is not None:
        if _shape(beta_raw) != (batch, tokens, value_heads):
            raise ValueError("beta_raw must be BSN [B, T, HV].")
        if beta_raw.dtype != beta.dtype:
            raise ValueError("beta_raw must use the same bfloat16 or float32 dtype as beta.")
    sequences = batch if cu_seqlens is None else len(tuple(cu_seqlens)) - 1
    state_shape = (sequences, value_heads, value_dim, key_dim) if state_v_first else (
        sequences, value_heads, key_dim, value_dim
    )
    if initial_state is not None:
        if _shape(initial_state) != state_shape:
            raise ValueError(f"initial_state must have shape {state_shape}.")
        if initial_state.dtype != q.dtype:
            raise ValueError("initial_state must use the main bfloat16 dtype.")
    if dht is not None:
        if _shape(dht) != state_shape:
            raise ValueError(f"dht must have shape {state_shape}.")
        if dht.dtype != q.dtype:
            raise ValueError("dht must use the main bfloat16 dtype.")

    dq = _empty_like(q)
    dk = _empty_like(k)
    dv = _empty_like(v)
    d_beta = _empty(scalar_input_shape, beta)
    d_g = _empty(scalar_input_shape, g)
    dh0 = _empty_like(initial_state) if initial_state is not None else None
    d_a_log = None
    d_dt_bias = None
    outputs = (dq, dk, dv, d_beta, d_g, dh0, d_a_log, d_dt_bias)
    layout_buffer = ctypes.create_string_buffer(layout.encode("utf-8"))

    def logical_tensor(ctx, tensor, name):
        return ctx.tensor(
            tensor,
            name,
            storage_shape_override=_shape(tensor) if tensor is not None else None,
        )

    return _call_aclnn(
        "aclnnChunkGatedDeltaRuleBwd",
        lambda ctx: [
            logical_tensor(ctx, q, "q"),
            logical_tensor(ctx, k, "k"),
            logical_tensor(ctx, v, "v"),
            logical_tensor(ctx, g, "g"),
            logical_tensor(ctx, beta, "beta"),
            logical_tensor(ctx, A, "A"),
            logical_tensor(ctx, d_o, "d_o"),
            logical_tensor(ctx, initial_state, "initial_state"),
            logical_tensor(ctx, dht, "dht"),
            logical_tensor(ctx, q_rstd, "q_rstd"),
            logical_tensor(ctx, k_rstd, "k_rstd"),
            logical_tensor(ctx, beta_raw, "beta_raw"),
            logical_tensor(ctx, a_log, "a_log"),
            logical_tensor(ctx, dt_bias, "dt_bias"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctypes.c_double(float(scale)),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(use_exp2),
            ctypes.c_bool(use_gate_in_kernel),
            ctypes.c_bool(use_qk_l2norm_in_kernel),
            ctypes.c_bool(use_beta_sigmoid_in_kernel),
            ctypes.c_bool(state_v_first),
            logical_tensor(ctx, dq, "dq"),
            logical_tensor(ctx, dk, "dk"),
            logical_tensor(ctx, dv, "dv"),
            logical_tensor(ctx, d_beta, "d_beta"),
            logical_tensor(ctx, d_g, "d_g"),
            logical_tensor(ctx, dh0, "dh0"),
            logical_tensor(ctx, d_a_log, "d_a_log"),
            logical_tensor(ctx, d_dt_bias, "d_dt_bias"),
        ],
        outputs,
    )


def _as_int_list(values):
    if values is None:
        return None
    if hasattr(values, "detach"):
        return [int(x) for x in values.detach().cpu().flatten().tolist()]
    return [int(x) for x in values]


def _chunk_indices_from_cu_seqlens(cu_seqlens, chunk_size):
    indices = []
    for seq_idx in range(len(cu_seqlens) - 1):
        seq_len = int(cu_seqlens[seq_idx + 1]) - int(cu_seqlens[seq_idx])
        chunk_num = (seq_len + chunk_size - 1) // chunk_size
        for chunk_idx in range(chunk_num):
            indices.append(seq_idx)
            indices.append(chunk_idx)
    return indices


def npu_chunk_gated_delta_rule_fwd_prepare(
    q,
    k,
    v,
    g,
    beta,
    chunk_size=64,
    *,
    use_qk_l2norm_in_kernel=False,
    use_gate_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    allow_neg_eigval=False,
    use_exp2=False,
    a_log=None,
    dt_bias=None,
    cu_seqlens=None,
    chunk_indices=None,
    output_a=True,
):
    import torch

    if int(chunk_size) != 64:
        raise ValueError("chunk_size currently only supports 64.")
    q_shape = _shape(q)
    k_shape = _shape(k)
    v_shape = _shape(v)
    if q_shape != k_shape:
        raise ValueError(f"k shape must match q {q_shape}, got {k_shape}.")
    if len(q_shape) != 4 or len(v_shape) != 4:
        raise ValueError("q/k/v must be BNSD 4D tensors.")
    B, HK, T, K = q_shape
    HV, V = v_shape[1], v_shape[3]
    if v_shape[0] != B or v_shape[2] != T:
        raise ValueError("v batch/seq must match q.")
    if K != 128:
        raise ValueError("K currently only supports 128.")
    if V not in (128, 256):
        raise ValueError("V must be 128 or 256.")
    if HK <= 0 or HV % HK != 0 or HV // HK not in (1, 2, 3, 4):
        raise ValueError("Hv must be divisible by Hk and Hv/Hk must be in {1,2,3,4}.")
    if any(tensor.dtype != q.dtype for tensor in (k, v)):
        raise ValueError("q, k and v must have the same dtype.")
    if q.dtype not in (torch.bfloat16,):
        raise ValueError("q/k/v currently only support bfloat16.")
    if _shape(g) != (B, HV, T) or _shape(beta) != (B, HV, T):
        raise ValueError(f"g and beta must have shape {(B, HV, T)}.")

    use_qk_l2norm_in_kernel = _optional_bool(use_qk_l2norm_in_kernel, False)
    use_gate_in_kernel = _optional_bool(use_gate_in_kernel, False)
    use_beta_sigmoid_in_kernel = _optional_bool(use_beta_sigmoid_in_kernel, False)
    allow_neg_eigval = _optional_bool(allow_neg_eigval, False)
    use_exp2 = _optional_bool(use_exp2, False)
    output_a = _optional_bool(output_a, True)

    if use_gate_in_kernel:
        raise ValueError("use_gate_in_kernel currently only supports False.")
    if allow_neg_eigval and not use_beta_sigmoid_in_kernel:
        raise ValueError("allow_neg_eigval=True requires use_beta_sigmoid_in_kernel=True.")
    if a_log is not None and _shape(a_log) != (HV,):
        raise ValueError(f"a_log must have shape {(HV,)}, got {_shape(a_log)}.")
    if dt_bias is not None and _shape(dt_bias) != (HV,):
        raise ValueError(f"dt_bias must have shape {(HV,)}, got {_shape(dt_bias)}.")

    cu_seqlens_list = _as_int_list(cu_seqlens)
    chunk_indices_list = _as_int_list(chunk_indices)
    if cu_seqlens_list is not None:
        if B != 1:
            raise ValueError("varlen requires B=1.")
        if chunk_indices_list is None:
            chunk_indices_list = _chunk_indices_from_cu_seqlens(cu_seqlens_list, int(chunk_size))

    g_cumsum = _empty((B, HV, T), q, dtype=torch.float32)
    w = _empty((B, HV, T, K), k)
    u = _empty_like(v)
    A = _empty((B, HV, T, int(chunk_size)), k)
    q_hat = _empty_like(q) if use_qk_l2norm_in_kernel else q
    k_hat = _empty_like(k) if use_qk_l2norm_in_kernel else k
    q_rstd = _empty((B, HK, T), q, dtype=torch.float32) if use_qk_l2norm_in_kernel else None
    k_rstd = _empty((B, HK, T), k, dtype=torch.float32) if use_qk_l2norm_in_kernel else None
    beta_out = _empty((B, HV, T), beta, dtype=torch.float32) if use_beta_sigmoid_in_kernel else None

    outputs = (q_hat, k_hat, q_rstd, k_rstd, beta_out, g_cumsum, w, u, A)

    def logical_tensor(ctx, tensor, name):
        if tensor is None:
            return ctx.tensor(tensor, name)
        return ctx.tensor(
            tensor,
            name,
            acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=_shape(tensor),
        )

    _call_aclnn(
        "aclnnChunkGatedDeltaRuleFwdPrepare",
        lambda ctx: [
            logical_tensor(ctx, q, "q"),
            logical_tensor(ctx, k, "k"),
            logical_tensor(ctx, v, "v"),
            logical_tensor(ctx, g, "g"),
            logical_tensor(ctx, beta, "beta"),
            logical_tensor(ctx, a_log if use_gate_in_kernel else None, "a_log"),
            logical_tensor(ctx, dt_bias if use_gate_in_kernel else None, "dt_bias"),
            ctx.int_array(cu_seqlens_list),
            ctx.int_array(chunk_indices_list),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(allow_neg_eigval),
            ctypes.c_bool(use_exp2),
            ctypes.c_bool(output_a),
            logical_tensor(ctx, g_cumsum, "g_cumsum"),
            logical_tensor(ctx, w, "w"),
            logical_tensor(ctx, u, "u"),
            logical_tensor(ctx, A, "A"),
            logical_tensor(ctx, q_hat if use_qk_l2norm_in_kernel else None, "q_hat"),
            logical_tensor(ctx, k_hat if use_qk_l2norm_in_kernel else None, "k_hat"),
            logical_tensor(ctx, q_rstd, "q_rstd"),
            logical_tensor(ctx, k_rstd, "k_rstd"),
            logical_tensor(ctx, beta_out, "beta_out"),
        ],
        outputs,
    )
    if beta_out is None:
        beta_out = beta.to(dtype=torch.float32)
    return q_hat, k_hat, q_rstd, k_rstd, beta_out, g_cumsum, w, u, A


def npu_chunk_gated_delta_rule_bwd_finalize(
    q,
    k,
    v,
    v_new,
    do,
    du,
    g,
    beta,
    h,
    dh,
    a,
    *,
    q_rstd=None,
    k_rstd=None,
    beta_raw=None,
    cu_seqlens=None,
    chunk_indices=None,
    scale=None,
    chunk_size=64,
    use_qk_l2_norm_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    use_gate_in_kernel=False,
    state_v_first=False,
    use_exp2=True,
):
    """Run the complete GDN backward finalize kernel.

    Returns ``dq, dk, dv, dbeta, dg``.
    """

    import torch

    npu = getattr(torch, "npu", None)
    if npu is None or not hasattr(npu, "get_device_name"):
        raise RuntimeError(
            "npu_chunk_gated_delta_rule_bwd_finalize requires an Ascend 950 NPU."
        )
    device_index = q.device.index
    if device_index is None:
        device_index = npu.current_device()
    device_name = npu.get_device_name(device_index)
    if not device_name.startswith("Ascend950"):
        raise RuntimeError(
            "npu_chunk_gated_delta_rule_bwd_finalize only supports Ascend 950, "
            f"got {device_name}."
        )

    if int(chunk_size) != 64:
        raise ValueError("chunk_size must be 64.")
    if scale is None:
        scale = 1.0 / (128.0 ** 0.5)
    if (cu_seqlens is None) != (chunk_indices is None):
        raise ValueError("cu_seqlens and chunk_indices must be both None or both provided.")
    if use_qk_l2_norm_in_kernel and (q_rstd is None or k_rstd is None):
        raise ValueError("q_rstd and k_rstd are required when Q/K L2Norm backward is enabled.")
    if use_beta_sigmoid_in_kernel and beta_raw is None:
        raise ValueError("beta_raw is required when beta sigmoid backward is enabled.")
    if bool(use_gate_in_kernel):
        raise ValueError("use_gate_in_kernel only supports False.")
    if g.dtype != beta.dtype:
        raise ValueError("g and beta must use the same dtype.")

    batch, _, total_tokens, key_dim = q.shape
    value_heads = v.shape[1]
    outputs = (
        _empty_like(q),
        _empty_like(k),
        _empty_like(v),
        _empty_like(beta),
        _empty_like(g),
    )
    def logical_tensor(ctx, tensor, name):
        # Ascend C tiling按逻辑 shape 校验输入；显式覆盖 storage shape，避免
        # NPU allocator 的物理 stride/padding 被误当成算子输入 shape。
        return ctx.tensor(tensor, name, storage_shape_override=tuple(tensor.shape)
                          if tensor is not None else None)

    result = _call_aclnn(
        "aclnnChunkGatedDeltaRuleBwdFinalize",
        lambda ctx: [
            logical_tensor(ctx, q, "q"), logical_tensor(ctx, k, "k"), logical_tensor(ctx, v, "v"),
            logical_tensor(ctx, v_new, "v_new"), logical_tensor(ctx, do, "do"), logical_tensor(ctx, du, "du"),
            logical_tensor(ctx, g, "g"), logical_tensor(ctx, beta, "beta"), logical_tensor(ctx, h, "h"),
            logical_tensor(ctx, dh, "dh"), logical_tensor(ctx, a, "a"),
            logical_tensor(ctx, q_rstd, "q_rstd"), logical_tensor(ctx, k_rstd, "k_rstd"),
            logical_tensor(ctx, beta_raw, "beta_raw"),
                ctx.int_array(cu_seqlens), ctx.int_array(chunk_indices),
            ctypes.c_double(float(scale)), ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(bool(use_qk_l2_norm_in_kernel)),
            ctypes.c_bool(bool(use_beta_sigmoid_in_kernel)),
            ctypes.c_bool(bool(use_gate_in_kernel)),
            ctypes.c_bool(bool(state_v_first)),
            ctypes.c_bool(bool(use_exp2)),
            *[logical_tensor(ctx, output, name) for output, name in zip(
                outputs,
                ("dq_out", "dk_out", "dv_out", "dbeta_out", "dg_out")
            )],
        ],
        outputs,
    )
    return tuple(result)


def npu_chunk_bwd_dv_local(
    q,
    k,
    d_o,
    g,
    scale,
    chunk_size,
    *,
    g_gamma=None,
    A=None,
    cu_seqlens=None,
    chunk_indices=None,
):
    out = _empty_like(d_o)
    return _call_aclnn(
        "aclnnChunkBwdDvLocal",
        lambda ctx: [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(d_o, "d_o"),
            ctx.tensor(g, "g"),
            ctx.tensor(g_gamma, "g_gamma"),
            ctx.tensor(A, "A"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_double(float(scale)),
            ctypes.c_int64(int(chunk_size)),
            ctx.tensor(out, "out"),
        ],
        out,
    )


def npu_chunk_gdn_bwd_intra(
    q,
    k,
    v,
    g,
    beta,
    A,
    d_o,
    scale,
    chunk_size,
    *,
    cu_seqlens=None,
    chunk_indices=None,
    use_exp2=True,
):
    """Run fused GDN recompute-w/u and intra-chunk dv in native BNSD."""

    import torch

    op_name = "npu_chunk_gdn_bwd_intra"
    tensors = {"q": q, "k": k, "v": v, "g": g, "beta": beta,
               "A": A, "d_o": d_o}
    for name, tensor in tensors.items():
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(f"{op_name}: {name} must be a torch.Tensor.")
        if tensor.device != q.device:
            raise RuntimeError(f"{op_name}: {name} must be on the same device as q.")
        if not tensor.is_contiguous():
            raise RuntimeError(f"{op_name}: {name} must be contiguous BNSD.")
    if q.ndim != 4 or k.shape != q.shape or v.ndim != 4 or d_o.shape != v.shape:
        raise RuntimeError(f"{op_name}: q/k and v/d_o must be matching rank-4 BNSD tensors.")
    if g.ndim != 3 or beta.shape != g.shape or A.ndim != 4:
        raise RuntimeError(f"{op_name}: g/beta must be rank 3 and A rank 4.")
    if q.dtype not in {torch.float16, torch.bfloat16}:
        raise RuntimeError(f"{op_name}: q must be FP16 or BF16.")
    if any(tensor.dtype != q.dtype for tensor in (k, v, A, d_o)):
        raise RuntimeError(f"{op_name}: k/v/A/d_o must use q.dtype.")
    if g.dtype not in {torch.bfloat16, torch.float32} or beta.dtype not in {torch.bfloat16, torch.float32}:
        raise RuntimeError(f"{op_name}: g and beta must each use BF16 or FP32.")
    batch, qk_heads, seqlen, key_dim = map(int, q.shape)
    value_heads = int(v.shape[1])
    chunk_size = int(chunk_size)
    if chunk_size != 64 or key_dim != 128 or int(v.shape[3]) != 128:
        raise RuntimeError(f"{op_name}: v1 requires chunk_size=64 and K=V=128.")
    if value_heads % qk_heads != 0 or value_heads // qk_heads not in {1, 2, 3, 4}:
        raise RuntimeError(f"{op_name}: HV/HK must be an integer in [1, 4].")
    if tuple(v.shape[:1] + v.shape[2:3]) != (batch, seqlen):
        raise RuntimeError(f"{op_name}: q/k and value tensors must share B and T.")
    if tuple(g.shape) != (batch, value_heads, seqlen):
        raise RuntimeError(f"{op_name}: g/beta shape must be [B, HV, T].")
    if tuple(A.shape) != (batch, value_heads, seqlen, chunk_size):
        raise RuntimeError(f"{op_name}: A shape must be [B, HV, T, chunk_size].")
    if (cu_seqlens is None) != (chunk_indices is None):
        raise RuntimeError(f"{op_name}: cu_seqlens and chunk_indices must be provided together.")

    w_shape = [batch, value_heads, seqlen, key_dim]
    w_out = _empty(w_shape, q, dtype=q.dtype)
    u_out = _empty_like(v)
    dv_local_out = _empty_like(v)
    outputs = (w_out, u_out, dv_local_out)

    # BNSD tensors are already contiguous; expose that physical shape to tiling.
    def nd_tensor(ctx, tensor, name):
        return ctx.tensor(
            tensor,
            name,
            acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=_shape(tensor),
        )

    return _call_aclnn(
        "aclnnChunkGdnBwdIntra",
        lambda ctx: [
            nd_tensor(ctx, q, "q"), nd_tensor(ctx, k, "k"),
            nd_tensor(ctx, v, "v"), nd_tensor(ctx, g, "g"),
            nd_tensor(ctx, beta, "beta"), nd_tensor(ctx, A, "A"),
            nd_tensor(ctx, d_o, "d_o"), ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices), ctypes.c_double(float(scale)),
            ctypes.c_int64(chunk_size), ctypes.c_bool(bool(use_exp2)),
            nd_tensor(ctx, w_out, "w"), nd_tensor(ctx, u_out, "u"),
            nd_tensor(ctx, dv_local_out, "dv_local"),
        ],
        outputs,
    )


def npu_prepare_wy_repr_bwd_da(
    k,
    v,
    beta,
    A,
    dw,
    du,
    g,
    *,
    chunk_size,
    cu_seqlens=None,
    chunk_indices=None,
):
    out = _empty_like(A)
    return _call_aclnn(
        "aclnnPrepareWyReprBwdDa",
        lambda ctx: [
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(A, "A"),
            ctx.tensor(dw, "dw"),
            ctx.tensor(du, "du"),
            ctx.tensor(g, "g"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_int64(int(chunk_size)),
            ctx.tensor(out, "dA"),
        ],
        out,
    )


def npu_chunk_bwd_dqkwg(
    q,
    k,
    v,
    g,
    h,
    dox,
    dh,
    dv,
    chunk_size,
    *,
    cu_seqlens=None,
    chunk_indices=None,
    w=None,
    g_gamma=None,
    scale=None,
    use_exp2=None,
    transpose_state_layout=None,
):
    import torch

    # 参数校验: None/标量/维度错误/dtype 错误在 Python 侧崩溃或只会触发 CANN
    # 的通用报错 (Cannot find binary), 这里提前拦截并给出明确提示。
    op_name = "npu_chunk_bwd_dqkwg"
    required_tensors = {
        "q": q, "k": k, "v": v, "g": g, "h": h,
        "dox": dox, "dh": dh, "dv": dv,
    }
    for name, tensor in required_tensors.items():
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(f"{op_name}: {name} must be a torch.Tensor, got {type(tensor)!r}.")

    expected_ranks = {
        "q": (4, "[B, HK, T, K]"),
        "k": (4, "[B, HK, T, K]"),
        "v": (4, "[B, HV, T, V]"),
        "dox": (4, "[B, HV, T, V]"),
        "dv": (4, "[B, HV, T, V]"),
        "g": (3, "[B, HV, T]"),
        "h": (5, "[B, HV, num_chunks, K, V]"),
        "dh": (5, "[B, HV, num_chunks, K, V]"),
    }
    for name, (rank, layout) in expected_ranks.items():
        tensor = required_tensors[name]
        if tensor.dim() != rank:
            raise ValueError(
                f"{op_name}: {name} must be a rank-{rank} tensor {layout}, "
                f"got shape {tuple(tensor.shape)}."
            )

    supported_dtypes = (torch.float16, torch.bfloat16)
    for name in ("q", "k", "v", "h", "dox", "dh", "dv"):
        tensor = required_tensors[name]
        if tensor.dtype not in supported_dtypes:
            raise ValueError(
                f"{op_name}: {name} must use float16 or bfloat16, got {tensor.dtype}."
            )
    for name in ("k", "v", "h", "dox", "dh", "dv"):
        tensor = required_tensors[name]
        if tensor.dtype != q.dtype:
            raise ValueError(
                f"{op_name}: {name} must use the same dtype as q ({q.dtype}), got {tensor.dtype}."
            )

    q_shape = _shape(q)
    value_num_heads = int(v.shape[1])
    dq = _empty_like(q)
    dk = _empty_like(k)
    dw = _empty((q_shape[0], value_num_heads, q_shape[2], q_shape[3]), q)
    dg = _empty_like(g)
    outputs = (dq, dk, dw, dg)
    return _call_aclnn(
        "aclnnChunkBwdDqkwg",
        lambda ctx: [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(g, "g"),
            ctx.tensor(h, "h"),
            ctx.tensor(dox, "dox"),
            ctx.tensor(dh, "dh"),
            ctx.tensor(dv, "dv"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctx.tensor(w, "w"),
            ctx.tensor(g_gamma, "g_gamma"),
            ctypes.c_float(_optional_float(scale, 1.0)),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(_optional_bool(use_exp2, False)),
            ctypes.c_bool(_optional_bool(transpose_state_layout, False)),
            ctx.tensor(dq, "dq"),
            ctx.tensor(dk, "dk"),
            ctx.tensor(dw, "dw"),
            ctx.tensor(dg, "dg"),
        ],
        outputs,
    )


def npu_chunk_fwd_o(
    q,
    k,
    v,
    h,
    scale,
    *,
    g=None,
    g_gamma=None,
    cu_seqlens=None,
    chunk_indices=None,
    chunk_size=None,
    transpose_state_layout=False,
    use_exp2=False,
    output_layout="BNSD",
):
    del g_gamma
    chunk_size = _optional_int(chunk_size, 64)
    use_exp2 = _optional_bool(use_exp2, False)
    output_layout = str(output_layout)

    batch, hv, seqlen, value_dim = _shape(v)
    if output_layout == "BNSD":
        out_shape = (batch, hv, seqlen, value_dim)
    elif output_layout == "BSND":
        out_shape = (batch, seqlen, hv, value_dim)
    elif output_layout == "TND":
        out_shape = (seqlen, hv, value_dim)
    else:
        out_shape = (hv, seqlen, value_dim)
    out = _empty(out_shape, v)
    layout_buffer = ctypes.create_string_buffer(output_layout.encode("utf-8"))
    return _call_aclnn(
        "aclnnChunkFwdO",
        lambda ctx: [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(h, "h"),
            ctx.tensor(g, "g"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_double(float(scale)),
            ctypes.c_int64(chunk_size),
            ctypes.c_bool(use_exp2),
            ctypes.c_bool(bool(transpose_state_layout)),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctx.tensor(out, "out"),
        ],
        out,
    )


def npu_chunk_gated_delta_rule_fwd_h(
    k,
    w,
    u,
    g=None,
    *,
    gk=None,
    initial_state=None,
    output_final_state=False,
    chunk_size=None,
    cu_seqlens=None,
    chunk_indices=None,
    state_v_first=False,
):
    import torch

    if g is None and gk is None:
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd_h: either g or gk must be provided.")
    output_final_state = _optional_bool(output_final_state, False)
    state_v_first = _optional_bool(state_v_first, False)
    chunk_size = _optional_int(chunk_size, 64)
    B, _, T, K = _shape(k)
    _, HV, _, V = _shape(u)
    cu = None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)
    indices = None if chunk_indices is None else tuple(int(value) for value in chunk_indices)
    if indices is None and cu is not None:
        indices = _kda_build_chunk_indices(cu, chunk_size)
    NT = _kda_total_chunks(B, T, chunk_size, cu, indices)
    N = len(cu) - 1 if cu is not None else B
    state_tail = (V, K) if state_v_first else (K, V)
    if initial_state is not None and _shape(initial_state) != (N, HV, *state_tail):
        raise RuntimeError(
            "npu_chunk_gated_delta_rule_fwd_h: initial_state shape does not match state_v_first."
        )
    h_out = _empty((B, HV, NT, *state_tail), k)
    v_new_out = _empty_like(u)
    if output_final_state:
        if initial_state is not None:
            final_state_out = _empty((N, HV, *state_tail), initial_state)
        else:
            final_state_out = _empty((N, HV, *state_tail), k, dtype=torch.float32)
    else:
        final_state_out = None
    outputs = (h_out, v_new_out, final_state_out if output_final_state else None)
    return _call_aclnn(
        "aclnnChunkGatedDeltaRuleFwdH",
        lambda ctx: [
            ctx.tensor(k, "k"),
            ctx.tensor(w, "w"),
            ctx.tensor(u, "u"),
            ctx.tensor(g, "g"),
            ctx.tensor(gk, "gk"),
            ctx.tensor(initial_state, "initial_state"),
            ctypes.c_bool(output_final_state),
            ctypes.c_int64(chunk_size),
            ctx.int_array(cu),
            ctx.int_array(indices),
            ctypes.c_bool(state_v_first),
            ctx.tensor(h_out, "h"),
            ctx.tensor(v_new_out, "v_new"),
            ctx.tensor(final_state_out, "final_state"),
        ],
        outputs,
    )


def _chunk_fwd_h_ceil_div(value: int, divisor: int) -> int:
    return (int(value) + int(divisor) - 1) // int(divisor)


def _chunk_fwd_h_build_chunk_indices(cu_seqlens, chunk_size: int):
    if cu_seqlens is None:
        return None
    cu = tuple(int(value) for value in cu_seqlens)
    indices = []
    for sequence, (begin, end) in enumerate(zip(cu, cu[1:])):
        for chunk in range(_chunk_fwd_h_ceil_div(end - begin, chunk_size)):
            indices.extend((sequence, chunk))
    return tuple(indices)


def _chunk_fwd_h_total_chunks(seqlen: int, chunk_size: int, cu_seqlens, chunk_indices) -> int:
    if chunk_indices is not None:
        return len(tuple(chunk_indices)) // 2
    if cu_seqlens is None:
        return _chunk_fwd_h_ceil_div(seqlen, chunk_size)
    cu = tuple(int(value) for value in cu_seqlens)
    return sum(
        _chunk_fwd_h_ceil_div(end - begin, chunk_size)
        for begin, end in zip(cu, cu[1:])
    )


def npu_chunk_fwd_h(
    k,
    w,
    u,
    *,
    g=None,
    gk=None,
    initial_state=None,
    output_final_state=False,
    chunk_size=64,
    save_new_value=True,
    cu_seqlens=None,
    chunk_indices=None,
    use_exp2=False,
    state_v_first=False,
):
    import torch

    op_name = "npu_chunk_fwd_h"
    if (g is None) == (gk is None):
        raise RuntimeError(f"{op_name}: exactly one of g and gk must be provided.")
    output_final_state = _optional_bool(output_final_state, False)
    save_new_value = _optional_bool(save_new_value, True)
    use_exp2 = _optional_bool(use_exp2, False)
    state_v_first = _optional_bool(state_v_first, False)
    chunk_size = _optional_int(chunk_size, 64)
    if chunk_size != 64:
        raise RuntimeError(f"{op_name}: chunk_size must be 64.")
    if not save_new_value:
        raise RuntimeError(f"{op_name}: save_new_value must be True.")
    if len(_shape(k)) != 4 or len(_shape(w)) != 4 or len(_shape(u)) != 4:
        raise RuntimeError(f"{op_name}: k, w and u must be rank-4 BNSD tensors.")

    batch, k_heads, seqlen, k_dim = _shape(k)
    _, v_heads, _, v_dim = _shape(u)
    if batch <= 0 or k_heads <= 0 or v_heads <= 0 or seqlen <= 0:
        raise RuntimeError(f"{op_name}: B, HK, HV and T must all be positive.")
    if k.dtype != torch.bfloat16 or w.dtype != k.dtype or u.dtype != k.dtype:
        raise RuntimeError(f"{op_name}: k, w and u must all use bfloat16.")
    if k_dim != 128 or v_dim != 128:
        raise RuntimeError(f"{op_name}: K and V must both be 128.")
    if _shape(w) != (batch, v_heads, seqlen, k_dim) or _shape(u) != (
        batch,
        v_heads,
        seqlen,
        v_dim,
    ):
        raise RuntimeError(f"{op_name}: w/u must be [B, HV, T, K/V].")

    gate_dtype = g.dtype if g is not None else gk.dtype
    if gate_dtype not in {torch.bfloat16, torch.float32}:
        raise RuntimeError(f"{op_name}: g/gk must use bfloat16 or float32.")
    if g is not None:
        if v_heads < k_heads or v_heads % k_heads != 0:
            raise RuntimeError(f"{op_name}: g-only mode requires HV >= HK and HV % HK == 0.")
        if _shape(g) != (batch, v_heads, seqlen):
            raise RuntimeError(f"{op_name}: g must be [B, HV, T].")
    else:
        if k_heads != v_heads:
            raise RuntimeError(f"{op_name}: gk-only mode requires prepared kg to have HV heads.")
        if _shape(gk) != (batch, v_heads, seqlen, k_dim):
            raise RuntimeError(f"{op_name}: gk must be [B, HV, T, K].")

    cu = None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)
    if cu is not None:
        if batch != 1:
            raise RuntimeError(f"{op_name}: variable-length BNSD input requires B=1.")
        if len(cu) < 2 or cu[0] != 0 or cu[-1] != seqlen or any(a >= b for a, b in zip(cu, cu[1:])):
            raise RuntimeError(
                f"{op_name}: cu_seqlens must be strictly increasing, start at 0 and end at T."
            )
    canonical_indices = _chunk_fwd_h_build_chunk_indices(cu, chunk_size)
    indices = canonical_indices if chunk_indices is None else tuple(int(value) for value in chunk_indices)
    if indices is not None and indices != canonical_indices:
        raise RuntimeError(f"{op_name}: chunk_indices must use canonical sequence-major order.")

    total_chunks = _chunk_fwd_h_total_chunks(seqlen, chunk_size, cu, indices)
    sequences = len(cu) - 1 if cu is not None else batch
    state_tail = (v_dim, k_dim) if state_v_first else (k_dim, v_dim)
    if initial_state is not None:
        if _shape(initial_state) != (sequences, v_heads, *state_tail):
            raise RuntimeError(f"{op_name}: initial_state shape does not match state_v_first.")
        if initial_state.dtype not in {torch.bfloat16, torch.float32}:
            raise RuntimeError(f"{op_name}: initial_state must use bfloat16 or float32.")

    h_out = _empty((batch, v_heads, total_chunks, *state_tail), k)
    v_new_out = _empty(_shape(u), u)
    if output_final_state:
        state_template = initial_state if initial_state is not None else k
        state_dtype = initial_state.dtype if initial_state is not None else torch.float32
        final_state_out = _empty(
            (sequences, v_heads, *state_tail), state_template, dtype=state_dtype
        )
    else:
        final_state_out = None
    outputs = (h_out, v_new_out, final_state_out if output_final_state else None)

    # ChunkFwdH 的公开布局契约是 ND。标准连续 rank-4/5 NPU tensor 的物理存储
    # 仍是行主序，但通用 runtime 会按维数推断 NCHW/NCDHW，因此这里由本算子
    # 显式覆盖 descriptor 元数据，不触发格式转换或额外数据搬运。
    def nd_tensor(ctx, tensor, name):
        if tensor is None:
            return ctx.tensor(None, name)
        loaded_torch_npu = sys.modules.get("torch_npu")
        if loaded_torch_npu is not None:
            try:
                actual_format = int(loaded_torch_npu.get_npu_format(tensor))
            except Exception as exc:
                raise RuntimeError(
                    f"{op_name}: cannot determine the real NPU format of {name}."
                ) from exc
        else:
            actual_format = _acl_format(tensor)
        standard_formats = {
            ACL_FORMAT_NCHW,
            ACL_FORMAT_ND,
            ACL_FORMAT_NCDHW,
            ACL_FORMAT_NCL,
        }
        if actual_format not in standard_formats:
            raise RuntimeError(
                f"{op_name}: {name} must use a standard contiguous-compatible layout; "
                f"private NPU format {actual_format} is not supported."
            )
        storage_shape = (
            _shape(tensor)
            if tensor.is_contiguous() and int(tensor.storage_offset()) == 0
            else None
        )
        return ctx.tensor(
            tensor,
            name,
            acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=storage_shape,
        )

    return _call_aclnn(
        "aclnnChunkFwdH",
        lambda ctx: [
            nd_tensor(ctx, k, "k"),
            nd_tensor(ctx, w, "w"),
            nd_tensor(ctx, u, "u"),
            nd_tensor(ctx, g, "g"),
            nd_tensor(ctx, gk, "gk"),
            nd_tensor(ctx, initial_state, "initial_state"),
            ctypes.c_bool(output_final_state),
            ctypes.c_int64(chunk_size),
            ctypes.c_bool(save_new_value),
            ctx.int_array(cu),
            ctx.int_array(indices),
            ctypes.c_bool(use_exp2),
            ctypes.c_bool(state_v_first),
            nd_tensor(ctx, h_out, "h"),
            nd_tensor(ctx, v_new_out, "v_new"),
            nd_tensor(ctx, final_state_out, "final_state"),
        ],
        outputs,
    )


def npu_chunk_kda_fwd_finalize(
    qg_scaled,
    aqk,
    v_new,
    h,
    *,
    output_layout="BSND",
    state_v_first=False,
    cu_seqlens=None,
    chunk_indices=None,
):
    import torch

    op_name = "npu_chunk_kda_fwd_finalize"
    if output_layout not in {"BSND", "BNSD", "TND", "NTD"}:
        raise RuntimeError(f"{op_name}: output_layout must be BSND, BNSD, TND or NTD.")
    packed = output_layout in {"TND", "NTD"}
    q_shape = _shape(qg_scaled)
    if packed:
        if len(q_shape) != 3 or q_shape[-1] != 128:
            raise RuntimeError(f"{op_name}: packed qg_scaled must be [HV, T, 128].")
        heads, seqlen, _ = q_shape
        batch = 1
        if _shape(aqk) != (heads, seqlen, 64) or _shape(v_new) not in {
            (heads, seqlen, 128), (1, heads, seqlen, 128)
        }:
            raise RuntimeError(f"{op_name}: packed aqk/v_new shapes do not match qg_scaled.")
    else:
        if len(q_shape) != 4 or q_shape[-1] != 128:
            raise RuntimeError(f"{op_name}: dense qg_scaled must be [B, HV, T, 128].")
        batch, heads, seqlen, _ = q_shape
        if _shape(aqk) != (batch, heads, seqlen, 64) or _shape(v_new) != (
            batch, heads, seqlen, 128
        ):
            raise RuntimeError(f"{op_name}: dense aqk/v_new must be head-major [B, HV, T, D].")
    if batch <= 0 or heads <= 0 or seqlen <= 0:
        raise RuntimeError(f"{op_name}: B, HV and T must all be positive.")
    for name, tensor in (("qg_scaled", qg_scaled), ("aqk", aqk), ("v_new", v_new), ("h", h)):
        if tensor.dtype != torch.bfloat16:
            raise RuntimeError(f"{op_name}: {name} must use bfloat16.")
        if tensor.device.type != "npu" or tensor.device != qg_scaled.device:
            raise RuntimeError(f"{op_name}: {name} must use the same NPU device.")

    cu = None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)
    if cu is not None:
        if batch != 1 or len(cu) < 2 or cu[0] != 0 or cu[-1] != seqlen or any(
            begin >= end for begin, end in zip(cu, cu[1:])
        ):
            raise RuntimeError(
                f"{op_name}: cu_seqlens requires B=1 and strictly increasing offsets from 0 to T."
            )
    canonical_indices = _chunk_fwd_h_build_chunk_indices(cu, 64)
    indices = canonical_indices if chunk_indices is None else tuple(int(value) for value in chunk_indices)
    if indices is not None and indices != canonical_indices:
        raise RuntimeError(f"{op_name}: chunk_indices must be canonical sequence-major pairs.")
    total_chunks = _chunk_fwd_h_total_chunks(seqlen, 64, cu, indices)
    if _shape(h) != (batch, heads, total_chunks, 128, 128):
        raise RuntimeError(f"{op_name}: h must be [B, HV, total_chunks, 128, 128].")

    out_shape = {
        "BSND": (batch, seqlen, heads, 128),
        "BNSD": (batch, heads, seqlen, 128),
        "TND": (seqlen, heads, 128),
        "NTD": (heads, seqlen, 128),
    }[output_layout]
    attn_out = _empty(out_shape, qg_scaled)
    layout_buffer = ctypes.create_string_buffer(output_layout.encode("utf-8"))

    # 标准物理布局原样透传，仅将 rank-3/4/5 descriptor 标记成算子要求的 ND。
    def nd_tensor(ctx, tensor, name):
        loaded_torch_npu = sys.modules.get("torch_npu")
        if loaded_torch_npu is not None:
            try:
                actual_format = int(loaded_torch_npu.get_npu_format(tensor))
            except Exception as exc:
                raise RuntimeError(f"{op_name}: cannot determine NPU format of {name}.") from exc
        else:
            actual_format = _acl_format(tensor)
        if actual_format not in {ACL_FORMAT_NCHW, ACL_FORMAT_ND, ACL_FORMAT_NCDHW, ACL_FORMAT_NCL}:
            raise RuntimeError(f"{op_name}: {name} must not use a private NPU format.")
        storage_shape = _shape(tensor) if tensor.is_contiguous() and tensor.storage_offset() == 0 else None
        return ctx.tensor(
            tensor, name, acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=storage_shape,
        )

    return _call_aclnn(
        "aclnnChunkKdaFwdFinalize",
        lambda ctx: [
            nd_tensor(ctx, qg_scaled, "qg_scaled"),
            nd_tensor(ctx, aqk, "aqk"),
            nd_tensor(ctx, v_new, "v_new"),
            nd_tensor(ctx, h, "h"),
            ctx.int_array(cu),
            ctx.int_array(indices),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctypes.c_bool(_optional_bool(state_v_first, False)),
            nd_tensor(ctx, attn_out, "attn_out"),
        ],
        attn_out,
    )


def npu_recompute_w_u_fwd(
    k,
    v,
    beta,
    A,
    chunk_size,
    *,
    g=None,
    gk=None,
    cu_seqlens=None,
    chunk_indices=None,
):
    w_shape = list(_shape(v))
    w_shape[3] = int(k.shape[3])
    w_out = _empty(w_shape, v, dtype=k.dtype)
    u_out = _empty_like(v)
    outputs = (w_out, u_out)
    return _call_aclnn(
        "aclnnRecomputeWUFwd",
        lambda ctx: [
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(A, "A"),
            ctx.tensor(g, "g"),
            ctx.tensor(gk, "gk"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_int64(int(chunk_size)),
            ctx.tensor(w_out, "w"),
            ctx.tensor(u_out, "u"),
        ],
        outputs,
    )


def npu_recurrent_gated_delta_rule(
    query,
    key,
    value,
    state,
    *,
    beta,
    scale=1.0,
    actual_seq_lengths,
    ssm_state_indices,
    num_accepted_tokens=None,
    g=None,
    gk=None,
):
    """
    Run recurrent GDN and update ``state`` in place.

    ``g`` and ``gk`` are independent optional gates. Passing ``None`` for
    either input disables that decay term by using an effective factor of one,
    but one of ``g`` or ``gk`` must be provided.
    """

    op_name = "npu_recurrent_gated_delta_rule"
    required_dim = 128
    if g is None and gk is None:
        raise RuntimeError(f"{op_name}: either g or gk must be provided.")

    import math
    import torch

    tensors = {
        "query": query,
        "key": key,
        "value": value,
        "state": state,
        "beta": beta,
        "actual_seq_lengths": actual_seq_lengths,
        "ssm_state_indices": ssm_state_indices,
    }
    optional_tensors = {
        "g": g,
        "gk": gk,
        "num_accepted_tokens": num_accepted_tokens,
    }

    for name, tensor in (*tensors.items(), *optional_tensors.items()):
        if tensor is None:
            if name in tensors:
                raise TypeError(f"{op_name}: {name} must be a torch.Tensor, got None.")
            continue
        if not isinstance(tensor, torch.Tensor):
            raise TypeError(f"{op_name}: {name} must be a torch.Tensor, got {type(tensor)!r}.")
        if tensor.device.type != "npu":
            raise TypeError(f"{op_name}: {name} must be a torch NPU tensor, got device {tensor.device}.")

    dtype_requirements = {
        "query": (torch.bfloat16,),
        "key": (torch.bfloat16,),
        "value": (torch.bfloat16,),
        "beta": (torch.bfloat16,),
        "state": (torch.bfloat16, torch.float32),
        "actual_seq_lengths": (torch.int32,),
        "ssm_state_indices": (torch.int32,),
        "g": (torch.float32,),
        "gk": (torch.float32,),
        "num_accepted_tokens": (torch.int32,),
    }
    for name, supported_dtypes in dtype_requirements.items():
        tensor = tensors.get(name, optional_tensors.get(name))
        if tensor is not None and tensor.dtype not in supported_dtypes:
            supported = ", ".join(str(dtype) for dtype in supported_dtypes)
            raise TypeError(
                f"{op_name}: {name} dtype must be one of ({supported}), got {tensor.dtype}."
            )

    shapes = {
        name: _shape(tensor)
        for name, tensor in (*tensors.items(), *optional_tensors.items())
        if tensor is not None
    }
    expected_ranks = {
        "query": 3,
        "key": 3,
        "value": 3,
        "beta": 2,
        "state": 4,
        "actual_seq_lengths": 1,
        "ssm_state_indices": 1,
        "g": 2,
        "gk": 3,
        "num_accepted_tokens": 1,
    }
    for name, expected_rank in expected_ranks.items():
        shape = shapes.get(name)
        if shape is not None and len(shape) != expected_rank:
            raise RuntimeError(
                f"{op_name}: {name} must be rank {expected_rank}, got shape {shape}."
            )

    query_shape = shapes["query"]
    key_shape = shapes["key"]
    value_shape = shapes["value"]
    state_shape = shapes["state"]
    actual_seq_lengths_shape = shapes["actual_seq_lengths"]
    if query_shape != key_shape:
        raise RuntimeError(
            f"{op_name}: key shape must equal query shape, got query={query_shape}, key={key_shape}."
        )

    total_tokens, key_heads, key_dim = query_shape
    value_tokens, value_heads, value_dim = value_shape
    state_blocks = state_shape[0]
    positive_dims = {
        "T": total_tokens,
        "Nk": key_heads,
        "Nv": value_heads,
        "Dk": key_dim,
        "Dv": value_dim,
        "state blocks": state_blocks,
    }
    for name, size in positive_dims.items():
        if size <= 0:
            raise RuntimeError(f"{op_name}: {name} must be positive, got {size}.")

    if value_tokens != total_tokens:
        raise RuntimeError(
            f"{op_name}: value T dimension must be {total_tokens}, got {value_tokens}."
        )
    expected_beta_shape = (total_tokens, value_heads)
    if shapes["beta"] != expected_beta_shape:
        raise RuntimeError(
            f"{op_name}: beta shape must be {expected_beta_shape}, got {shapes['beta']}."
        )
    expected_state_shape = (state_blocks, value_heads, value_dim, key_dim)
    if state_shape != expected_state_shape:
        raise RuntimeError(
            f"{op_name}: state shape must be {expected_state_shape}, got {state_shape}."
        )
    if actual_seq_lengths_shape[0] < 2:
        raise RuntimeError(
            f"{op_name}: actual_seq_lengths must contain the prefix entry and at least one sequence length."
        )
    if shapes["ssm_state_indices"] != (total_tokens,):
        raise RuntimeError(
            f"{op_name}: ssm_state_indices shape must be ({total_tokens},), "
            f"got {shapes['ssm_state_indices']}."
        )

    batch_size = actual_seq_lengths_shape[0] - 1
    optional_shapes = {
        "g": (total_tokens, value_heads),
        "gk": (total_tokens, value_heads, key_dim),
        "num_accepted_tokens": (batch_size,),
    }
    for name, expected_shape in optional_shapes.items():
        shape = shapes.get(name)
        if shape is not None and shape != expected_shape:
            raise RuntimeError(
                f"{op_name}: {name} shape must be {expected_shape}, got {shape}."
            )

    if (
        key_heads > 256
        or value_heads > 256
        or key_dim != required_dim
        or value_dim != required_dim
    ):
        raise RuntimeError(
            f"{op_name}: Nk and Nv must be <= 256 and Dk and Dv must be exactly {required_dim}, "
            f"got Nk={key_heads}, Nv={value_heads}, Dk={key_dim}, Dv={value_dim}."
        )
    if value_heads % key_heads != 0:
        raise RuntimeError(
            f"{op_name}: Nv must be an integer multiple of Nk, got Nv={value_heads}, Nk={key_heads}."
        )

    scale = _optional_float(scale, 1.0)
    if not math.isfinite(scale):
        raise ValueError(f"{op_name}: scale must be finite, got {scale}.")

    def nd_tensor(ctx, tensor, name):
        if tensor is None:
            return ctx.tensor(tensor, name)
        storage_shape = _shape(tensor) if tensor.is_contiguous() else None
        return ctx.tensor(
            tensor,
            name,
            acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=storage_shape,
        )

    out = _empty(_shape(value), value)
    return _call_aclnn(
        "aclnnRecurrentGatedDeltaRule",
        lambda ctx: [
            nd_tensor(ctx, query, "query"),
            nd_tensor(ctx, key, "key"),
            nd_tensor(ctx, value, "value"),
            nd_tensor(ctx, beta, "beta"),
            nd_tensor(ctx, state, "state"),
            nd_tensor(ctx, actual_seq_lengths, "actual_seq_lengths"),
            nd_tensor(ctx, ssm_state_indices, "ssm_state_indices"),
            nd_tensor(ctx, g, "g"),
            nd_tensor(ctx, gk, "gk"),
            nd_tensor(ctx, num_accepted_tokens, "num_accepted_tokens"),
            ctypes.c_float(scale),
            nd_tensor(ctx, out, "out"),
        ],
        out,
    )


def _chunk_local_cumsum_output_dtype(g, output_dtype):
    import torch

    if output_dtype is None:
        return "float32", torch.float32
    if isinstance(output_dtype, torch.dtype):
        if output_dtype in (torch.float, torch.float32):
            return "float32", torch.float32
        if output_dtype in (torch.float16, torch.half):
            return "float16", torch.float16
        if output_dtype == torch.bfloat16:
            return "bfloat16", torch.bfloat16
        raise TypeError(f"Unsupported chunk_local_cumsum output_dtype: {output_dtype}.")

    normalized = str(output_dtype).removeprefix("torch.").lower()
    if normalized in {"float", "float32"}:
        return "float32", torch.float32
    if normalized in {"half", "float16"}:
        return "float16", torch.float16
    if normalized in {"bf16", "bfloat16"}:
        return "bfloat16", torch.bfloat16
    if normalized in {"same", "input", "none"}:
        return normalized, g.dtype
    raise TypeError(f"Unsupported chunk_local_cumsum output_dtype: {output_dtype}.")


def npu_chunk_local_cumsum(
    g,
    chunk_size,
    *,
    cu_seqlens=None,
    chunk_indices_out=None,
    reverse=False,
    scale=1.0,
    head_first=True,
    output_dtype="float32",
):
    output_dtype_name, out_dtype = _chunk_local_cumsum_output_dtype(g, output_dtype)
    g_contig = g.contiguous()
    out = _empty(_shape(g_contig), g_contig, dtype=out_dtype)
    output_dtype_buffer = ctypes.create_string_buffer(output_dtype_name.encode("utf-8"))
    return _call_aclnn(
        "aclnnChunkLocalCumsum",
        lambda ctx: [
            ctx.tensor(g_contig, "g"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices_out),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(bool(reverse)),
            ctypes.c_double(float(scale)),
            ctypes.c_bool(bool(head_first)),
            ctypes.cast(output_dtype_buffer, ctypes.c_char_p),
            ctx.tensor(out, "out"),
        ],
        out,
    )


def npu_chunk_scaled_dot_kkt(
    k,
    g,
    beta,
    *,
    cu_seqlens=None,
    chunk_indices=None,
    chunk_size=64,
):
    import torch

    k_contig = k.contiguous()
    g_contig = g.contiguous()
    beta_contig = beta.contiguous()
    B, _, T, _ = _shape(k_contig)
    _, Hv, _ = _shape(g_contig)
    out = _empty((B, Hv, T, int(chunk_size)), k_contig, dtype=torch.float32)
    return _call_aclnn(
        "aclnnChunkScaledDotKkt",
        lambda ctx: [
            ctx.tensor(k_contig, "k"),
            ctx.tensor(g_contig, "g"),
            ctx.tensor(beta_contig, "beta"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.c_int64(int(chunk_size)),
            ctx.tensor(out, "out"),
        ],
        out,
    )


# Typing dependencies scoped to the causal_conv1d wrappers below: annotations
# stay lazy, and Sequence is also used at runtime by the metadata helpers.
from collections.abc import Sequence
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    import torch


def _infer_causal_conv1d_y(x, head_num: int, run_mode: int):
    x_dim = len(x.shape)
    if run_mode == 0 and head_num > 0:
        if x_dim == 3:
            b, s, d_model = _shape(x)
            return _empty((b, head_num, s, d_model // head_num), x)
        if x_dim == 2:
            s, d_model = _shape(x)
            return _empty((head_num, s, d_model // head_num), x)
    return _empty_like(x)


def _normalize_causal_conv1d_activation(activation: str | None) -> str:
    if activation not in {None, "silu", "swish"}:
        raise ValueError(
            "activation must be None, 'silu', or 'swish', "
            f"got {activation!r}"
        )
    return "none" if activation is None else activation


def _validate_causal_conv1d_slot_id(
    value: int | None,
    *,
    name: str,
    allow_none: bool,
) -> int:
    if value is None:
        if allow_none:
            return -1  # sentinel disabling the null-block slot
        raise TypeError(f"{name} must be an int")
    if isinstance(value, bool) or not isinstance(value, int):
        expected = "an int or None" if allow_none else "an int"
        raise TypeError(f"{name} must be {expected}, got {type(value).__name__}")
    if allow_none and value < 0:
        raise ValueError(f"{name} must be non-negative or None, got {value}")
    return value


def _reject_unsupported_causal_conv1d_scheduling(**values: object) -> None:
    enabled = [name for name, value in values.items() if value is not None]
    if enabled:
        raise NotImplementedError(
            "CausalConv1d APC/block-cache scheduling is not supported by the "
            f"Ascend operator: {', '.join(enabled)}"
        )


def _causal_conv1d_cpu_metadata_values(
    value: torch.Tensor | Sequence[int] | None,
    *,
    name: str,
) -> list[int] | None:
    import torch

    if value is None:
        return None
    if isinstance(value, torch.Tensor):
        if value.device.type != "cpu":
            raise ValueError(f"{name} must be a CPU Tensor, got {value.device}")
        if value.dim() != 1:
            raise ValueError(f"{name} must be rank 1, got shape {tuple(value.shape)}")
        if value.dtype not in {torch.bool, torch.int32, torch.int64}:
            raise TypeError(f"{name} must use bool, int32, or int64, got {value.dtype}")
        return [int(item) for item in value.tolist()]
    if isinstance(value, Sequence) and not isinstance(value, (str, bytes)):
        return [int(item) for item in value]
    raise TypeError(f"{name} must be a CPU Tensor, an integer sequence, or None")


def _validate_causal_conv1d_device_metadata(
    value: torch.Tensor | None,
    *,
    name: str,
    data_device: torch.device,
    allow_bool: bool = False,
) -> None:
    import torch

    if value is None:
        return
    if not isinstance(value, torch.Tensor):
        raise TypeError(f"{name} must be a device Tensor or None")
    if value.dim() != 1:
        raise ValueError(f"{name} must be rank 1, got shape {tuple(value.shape)}")
    allowed_dtypes = {torch.int32} | ({torch.bool} if allow_bool else set())
    if value.dtype not in allowed_dtypes:
        allowed = "bool or int32" if allow_bool else "int32"
        raise TypeError(f"{name} must use {allowed}, got {value.dtype}")
    if value.device != data_device:
        raise ValueError(f"{name} must be on {data_device}, got {value.device}")


def _check_causal_conv1d_metadata_pair(
    device_value: torch.Tensor | None,
    cpu_value: list[int] | None,
    *,
    name: str,
) -> None:
    if device_value is not None and cpu_value is not None:
        raise ValueError(f"{name} and {name}_cpu are mutually exclusive")


def _causal_conv1d_metadata_length(
    device_value: torch.Tensor | None,
    cpu_value: list[int] | None,
) -> int | None:
    if device_value is not None:
        return device_value.numel()
    if cpu_value is not None:
        return len(cpu_value)
    return None


def _causal_conv1d_metadata_values_for_validation(
    device_value: torch.Tensor | None,
    cpu_value: list[int] | None,
) -> list[int] | None:
    if cpu_value is not None:
        return cpu_value
    if device_value is None:
        return None
    return [int(item) for item in device_value.detach().cpu().tolist()]


def _validate_causal_conv1d_query_start_loc(
    values: list[int],
    *,
    total_tokens: int,
) -> None:
    if len(values) < 2:
        raise ValueError("query_start_loc must contain at least [0, total_tokens]")
    if values[0] != 0 or values[-1] != total_tokens:
        raise ValueError(
            "query_start_loc must start at 0 and end at "
            f"{total_tokens}, got ({values[0]}, {values[-1]})"
        )
    if any(left > right for left, right in zip(values, values[1:])):
        raise ValueError(f"query_start_loc must be non-decreasing, got {values}")


def _validate_causal_conv1d_weight_and_state(
    weight: torch.Tensor,
    conv_state: torch.Tensor | None,
    *,
    allow_missing_state: bool = False,
) -> tuple[int, int]:
    if weight.dim() != 2:
        raise ValueError(f"weight must have shape (width, dim), got {tuple(weight.shape)}")
    width, dim = weight.shape
    supported_widths = {2, 3, 4}
    if width not in supported_widths:
        raise ValueError(
            "weight width must be one of "
            f"{sorted(supported_widths)}, got {width}"
        )
    if dim % 16 != 0:
        raise ValueError(f"weight dim must be divisible by 16, got {dim}")
    if conv_state is None:
        if allow_missing_state:
            return dim, width
        raise ValueError("conv_state is required by causal_conv1d_update")
    if conv_state.numel() == 0:
        if allow_missing_state:
            return dim, width
        raise ValueError("empty conv_state is only supported by causal_conv1d_fn")
    if conv_state.dim() != 3:
        raise ValueError(
            "conv_state(s) must have shape (num_cache_lines, state_len, dim), "
            f"got {tuple(conv_state.shape)}"
        )
    if conv_state.shape[2] != dim:
        raise ValueError(
            f"conv_state(s) dim {conv_state.shape[2]} must match weight dim {dim}"
        )
    if conv_state.shape[1] < width - 1:
        raise ValueError(
            f"conv_state(s) state_len must be at least width - 1 ({width - 1}), "
            f"got {conv_state.shape[1]}"
        )
    return dim, width


def _validate_causal_conv1d_data_tensors(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None,
    conv_state: torch.Tensor | None,
) -> None:
    data_tensors = [("weight", weight)]
    if conv_state is not None:
        data_tensors.append(("conv_state(s)", conv_state))
    for name, tensor in data_tensors:
        if tensor.dtype != x.dtype:
            raise TypeError(f"{name} dtype {tensor.dtype} must match x dtype {x.dtype}")
        if tensor.device != x.device:
            raise ValueError(f"{name} device {tensor.device} must match x device {x.device}")
    if bias is not None:
        if bias.dtype != x.dtype:
            raise TypeError(f"bias dtype {bias.dtype} must match x dtype {x.dtype}")
        if bias.device != x.device:
            raise ValueError(f"bias device {bias.device} must match x device {x.device}")


# Public signature defaults re-exported by fla_npu.ops.ascendc.
PAD_SLOT_ID = -1
NULL_BLOCK_ID = 0

def _launch_causal_conv1d(
    x,
    weight,
    bias=None,
    conv_states=None,
    *,
    query_start_loc=None,
    cache_indices=None,
    has_initial_state=None,
    num_accepted_tokens=None,
    query_start_loc_cpu=None,
    cache_indices_cpu=None,
    has_initial_state_cpu=None,
    num_accepted_tokens_cpu=None,
    activation="none",
    pad_slot_id=-1,
    null_block_id=-1,
    run_mode=0,
    head_num=0,
    max_query_len=-1,
):
    """Build the single aclnnCausalConv1d ABI shared by all Python APIs."""

    # This is the ctypes reference: it validates in Python, normalises the
    # metadata and builds the aclnn call, descriptors included.  The stable path
    # does not come through here any more -- the family has real adapters -- so
    # this stays the parity baseline and the FLA_NPU_STABLE_VALIDATE=1 target.
    out = _infer_causal_conv1d_y(x, int(head_num), int(run_mode))
    activation_buffer = ctypes.create_string_buffer(str(activation).encode("utf-8"))
    result = _call_aclnn(
        "aclnnCausalConv1d",
        lambda ctx: [
            ctx.tensor(x, "x"),
            ctx.tensor(weight, "weight"),
            ctx.tensor(bias, "bias"),
            ctx.tensor(conv_states, "conv_states"),
            ctx.tensor(query_start_loc, "query_start_loc"),
            ctx.tensor(cache_indices, "cache_indices"),
            ctx.tensor(has_initial_state, "has_initial_state"),
            ctx.tensor(num_accepted_tokens, "num_accepted_tokens"),
            ctx.int_array(query_start_loc_cpu),
            ctx.int_array(cache_indices_cpu),
            ctx.int_array(has_initial_state_cpu),
            ctx.int_array(num_accepted_tokens_cpu),
            ctypes.cast(activation_buffer, ctypes.c_char_p),
            ctypes.c_int64(int(pad_slot_id)),
            ctypes.c_int64(int(null_block_id)),
            ctypes.c_int64(int(run_mode)),
            ctypes.c_int64(int(head_num)),
            ctypes.c_int64(int(max_query_len)),
            ctx.tensor(out, "out"),
        ],
        out,
    )
    return result


def npu_causal_conv1d_fn(
    x: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None,
    conv_states: torch.Tensor | None = None,
    query_start_loc: torch.Tensor | None = None,
    cache_indices: torch.Tensor | None = None,
    has_initial_state: torch.Tensor | None = None,
    activation: str | None = "silu",
    pad_slot_id: int = PAD_SLOT_ID,
    null_block_id: int | None = NULL_BLOCK_ID,
    block_idx_first_scheduled_token: torch.Tensor | None = None,
    block_idx_last_scheduled_token: torch.Tensor | None = None,
    initial_state_idx: torch.Tensor | None = None,
    num_computed_tokens: torch.Tensor | None = None,
    block_size_to_align: int = 0,
    metadata: object | None = None,
    validate_data: bool = False,
    *,
    query_start_loc_cpu: torch.Tensor | Sequence[int] | None = None,
    cache_indices_cpu: torch.Tensor | Sequence[int] | None = None,
    has_initial_state_cpu: torch.Tensor | Sequence[int] | None = None,
    head_num: int = 0,
) -> torch.Tensor:
    """Run FN with dim-last ``x=(T,D)`` or ``x=(B,S,D)``."""
    _reject_unsupported_causal_conv1d_scheduling(
        block_idx_first_scheduled_token=block_idx_first_scheduled_token,
        block_idx_last_scheduled_token=block_idx_last_scheduled_token,
        initial_state_idx=initial_state_idx,
        num_computed_tokens=num_computed_tokens,
        metadata=metadata,
    )
    if block_size_to_align not in (0, None):
        raise NotImplementedError(
            "CausalConv1d block_size_to_align is not supported by the Ascend operator"
        )
    raw_pad_slot_id = _validate_causal_conv1d_slot_id(
        pad_slot_id,
        name="pad_slot_id",
        allow_none=False,
    )
    raw_null_block_id = _validate_causal_conv1d_slot_id(
        null_block_id,
        name="null_block_id",
        allow_none=True,
    )

    dim, _ = _validate_causal_conv1d_weight_and_state(
        weight,
        conv_states,
        allow_missing_state=True,
    )
    if x.dim() not in (2, 3) or x.shape[-1] != dim:
        raise ValueError(
            "x must have shape (total_tokens, dim) or (batch, seqlen, dim) "
            f"with dim={dim}, got {tuple(x.shape)}"
        )
    _validate_causal_conv1d_data_tensors(x, weight, bias, conv_states)
    if x.dim() == 3 and (query_start_loc is not None or query_start_loc_cpu is not None):
        raise ValueError("query_start_loc is not supported for 3D x")
    if head_num < 0 or (
        head_num > 0
        and (dim % head_num != 0 or (dim // head_num) % 16 != 0)
    ):
        raise ValueError("head_num must be 0 or divide dim with a head_dim divisible by 16")

    qsl_cpu = _causal_conv1d_cpu_metadata_values(
        query_start_loc_cpu,
        name="query_start_loc_cpu",
    )
    cache_cpu = _causal_conv1d_cpu_metadata_values(
        cache_indices_cpu,
        name="cache_indices_cpu",
    )
    initial_cpu = _causal_conv1d_cpu_metadata_values(
        has_initial_state_cpu,
        name="has_initial_state_cpu",
    )

    _validate_causal_conv1d_device_metadata(
        query_start_loc,
        name="query_start_loc",
        data_device=x.device,
    )
    _validate_causal_conv1d_device_metadata(
        cache_indices,
        name="cache_indices",
        data_device=x.device,
    )
    _validate_causal_conv1d_device_metadata(
        has_initial_state,
        name="has_initial_state",
        data_device=x.device,
        allow_bool=True,
    )
    _check_causal_conv1d_metadata_pair(query_start_loc, qsl_cpu, name="query_start_loc")
    _check_causal_conv1d_metadata_pair(cache_indices, cache_cpu, name="cache_indices")
    _check_causal_conv1d_metadata_pair(
        has_initial_state,
        initial_cpu,
        name="has_initial_state",
    )

    qsl_len = _causal_conv1d_metadata_length(query_start_loc, qsl_cpu)
    if qsl_len is None:
        if x.dim() == 2:
            raise ValueError("query_start_loc or query_start_loc_cpu is required for 2D x")
        batch = x.shape[0]
    else:
        batch = qsl_len - 1
        if batch < 0:
            raise ValueError("query_start_loc must contain at least one element")
    for name, device_value, cpu_value in (
        ("cache_indices", cache_indices, cache_cpu),
        ("has_initial_state", has_initial_state, initial_cpu),
    ):
        length = _causal_conv1d_metadata_length(device_value, cpu_value)
        if length is not None and length != batch:
            raise ValueError(f"{name} must contain {batch} entries")
    if validate_data and qsl_len is not None:
        values = _causal_conv1d_metadata_values_for_validation(query_start_loc, qsl_cpu)
        assert values is not None
        _validate_causal_conv1d_query_start_loc(values, total_tokens=x.shape[0])

    return _launch_causal_conv1d(
        x=x,
        weight=weight,
        bias=bias,
        conv_states=conv_states,
        query_start_loc=query_start_loc,
        cache_indices=cache_indices,
        has_initial_state=has_initial_state,
        query_start_loc_cpu=qsl_cpu,
        cache_indices_cpu=cache_cpu,
        has_initial_state_cpu=initial_cpu,
        activation=_normalize_causal_conv1d_activation(activation),
        pad_slot_id=raw_pad_slot_id,
        null_block_id=raw_null_block_id,
        run_mode=0,
        head_num=head_num,
    )


def npu_causal_conv1d_update(
    x: torch.Tensor,
    conv_state: torch.Tensor,
    weight: torch.Tensor,
    bias: torch.Tensor | None = None,
    activation: str | None = None,
    conv_state_indices: torch.Tensor | None = None,
    num_accepted_tokens: torch.Tensor | None = None,
    query_start_loc: torch.Tensor | None = None,
    max_query_len: int = -1,
    null_block_id: int | None = NULL_BLOCK_ID,
    block_idx_last_scheduled_token: torch.Tensor | None = None,
    initial_state_idx: torch.Tensor | None = None,
    validate_data: bool = False,
    out: torch.Tensor | None = None,
    *,
    conv_state_indices_cpu: torch.Tensor | Sequence[int] | None = None,
    num_accepted_tokens_cpu: torch.Tensor | Sequence[int] | None = None,
    query_start_loc_cpu: torch.Tensor | Sequence[int] | None = None,
) -> torch.Tensor:
    """Run UPDATE with dim-last data and mutate ``conv_state`` in place."""
    _reject_unsupported_causal_conv1d_scheduling(
        block_idx_last_scheduled_token=block_idx_last_scheduled_token,
        initial_state_idx=initial_state_idx,
    )
    raw_null_block_id = _validate_causal_conv1d_slot_id(
        null_block_id,
        name="null_block_id",
        allow_none=True,
    )

    dim, width = _validate_causal_conv1d_weight_and_state(weight, conv_state)
    qsl_cpu = _causal_conv1d_cpu_metadata_values(
        query_start_loc_cpu,
        name="query_start_loc_cpu",
    )
    state_indices_cpu = _causal_conv1d_cpu_metadata_values(
        conv_state_indices_cpu,
        name="conv_state_indices_cpu",
    )
    accepted_cpu = _causal_conv1d_cpu_metadata_values(
        num_accepted_tokens_cpu,
        name="num_accepted_tokens_cpu",
    )

    _validate_causal_conv1d_device_metadata(
        query_start_loc,
        name="query_start_loc",
        data_device=x.device,
    )
    _validate_causal_conv1d_device_metadata(
        conv_state_indices,
        name="conv_state_indices",
        data_device=x.device,
    )
    _validate_causal_conv1d_device_metadata(
        num_accepted_tokens,
        name="num_accepted_tokens",
        data_device=x.device,
    )
    _check_causal_conv1d_metadata_pair(query_start_loc, qsl_cpu, name="query_start_loc")
    _check_causal_conv1d_metadata_pair(
        conv_state_indices,
        state_indices_cpu,
        name="conv_state_indices",
    )
    _check_causal_conv1d_metadata_pair(
        num_accepted_tokens,
        accepted_cpu,
        name="num_accepted_tokens",
    )

    is_varlen = query_start_loc is not None or qsl_cpu is not None
    if isinstance(max_query_len, bool) or not isinstance(max_query_len, int):
        raise TypeError(
            f"max_query_len must be an int, got {type(max_query_len).__name__}"
        )
    if max_query_len < -1:
        raise ValueError(f"max_query_len must be >= -1, got {max_query_len}")
    if is_varlen and max_query_len < 0:
        raise ValueError(
            "max_query_len must be provided and non-negative for varlen update"
        )
    if x.dim() == 2:
        if x.shape[1] != dim:
            raise ValueError(f"x.shape[1] must equal dim={dim}, got {tuple(x.shape)}")
    elif x.dim() == 3 and not is_varlen:
        if x.shape[2] != dim:
            raise ValueError(f"x.shape[2] must equal dim={dim}, got {tuple(x.shape)}")
    else:
        expected = (
            "(total_tokens, dim)"
            if is_varlen
            else "(batch, dim) or (batch, seqlen, dim)"
        )
        raise ValueError(f"x must have shape {expected}, got {tuple(x.shape)}")
    _validate_causal_conv1d_data_tensors(x, weight, bias, conv_state)

    if out is not None:
        if out.shape != x.shape:
            raise ValueError(f"out shape {tuple(out.shape)} must match x shape {tuple(x.shape)}")
        if out.dtype != x.dtype or out.device != x.device:
            raise ValueError("out must have the same dtype and device as x")
    if (
        _causal_conv1d_metadata_length(num_accepted_tokens, accepted_cpu) is not None
        and width != 4
    ):
        raise ValueError(
            "num_accepted_tokens is currently supported only when weight width is 4"
        )
    if (
        is_varlen
        and _causal_conv1d_metadata_length(conv_state_indices, state_indices_cpu) is None
    ):
        raise ValueError(
            "conv_state_indices or conv_state_indices_cpu is required for varlen update"
        )

    qsl_len = _causal_conv1d_metadata_length(query_start_loc, qsl_cpu)
    if qsl_len is not None:
        batch = qsl_len - 1
        state_indices_len = _causal_conv1d_metadata_length(
            conv_state_indices,
            state_indices_cpu,
        )
        accepted_len = _causal_conv1d_metadata_length(
            num_accepted_tokens,
            accepted_cpu,
        )
        if state_indices_len is not None and state_indices_len != batch:
            raise ValueError(f"conv_state_indices must contain {batch} entries")
        if accepted_len is not None and accepted_len != batch:
            raise ValueError(f"num_accepted_tokens must contain {batch} entries")
        if validate_data:
            values = _causal_conv1d_metadata_values_for_validation(
                query_start_loc,
                qsl_cpu,
            )
            assert values is not None
            _validate_causal_conv1d_query_start_loc(values, total_tokens=x.shape[0])
            observed_max = max(
                (right - left for left, right in zip(values, values[1:])),
                default=0,
            )
            if max_query_len >= 0 and max_query_len < observed_max:
                raise ValueError(
                    f"max_query_len={max_query_len} is smaller than the observed "
                    f"segment length {observed_max}"
                )

    result = _launch_causal_conv1d(
        x=x,
        weight=weight,
        bias=bias,
        conv_states=conv_state,
        query_start_loc=query_start_loc,
        cache_indices=conv_state_indices,
        num_accepted_tokens=num_accepted_tokens,
        query_start_loc_cpu=qsl_cpu,
        cache_indices_cpu=state_indices_cpu,
        num_accepted_tokens_cpu=accepted_cpu,
        activation=_normalize_causal_conv1d_activation(activation),
        pad_slot_id=-(1 << 63),
        null_block_id=raw_null_block_id,
        run_mode=1,
        max_query_len=max_query_len,
    )
    if out is not None:
        out.copy_(result)
        return out
    x.copy_(result)
    return x


def npu_causal_conv1d(
    x,
    weight,
    bias=None,
    conv_states=None,
    *,
    query_start_loc=None,
    cache_indices=None,
    initial_state_mode=None,
    num_accepted_tokens=None,
    activation_mode=0,
    pad_slot_id=-1,
    run_mode=0,
    head_num=0,
):
    """Run the deprecated Host-metadata compatibility interface."""
    import warnings

    warnings.warn(
        "fla_npu.ops.ascendc.npu_causal_conv1d is a deprecated compatibility "
        "API and will be removed in 2027/02. Use causal_conv1d_fn or "
        "causal_conv1d_update instead.",
        FutureWarning,
        stacklevel=4,
    )
    activation_mode = int(activation_mode)
    if activation_mode not in (0, 1):
        raise ValueError(f"activation_mode only supports 0/1, got {activation_mode}")
    activation = "silu" if activation_mode == 1 else "none"
    return _launch_causal_conv1d(
        x=x,
        weight=weight,
        bias=bias,
        conv_states=conv_states,
        query_start_loc_cpu=query_start_loc,
        cache_indices_cpu=cache_indices,
        has_initial_state_cpu=initial_state_mode,
        num_accepted_tokens_cpu=num_accepted_tokens,
        activation=activation,
        pad_slot_id=pad_slot_id,
        null_block_id=-1,
        run_mode=run_mode,
        head_num=head_num,
    )


def npu_chunk_gated_delta_rule_fwd(
    q,
    k,
    v,
    g,
    beta,
    *,
    initial_state=None,
    output_final_state=False,
    chunk_size=64,
    cu_seqlens=None,
    chunk_indices=None,
    scale=None,
    use_exp2=False,
    use_qk_l2norm_in_kernel=False,
    use_gate_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    allow_neg_eigval=False,
    disable_recompute=True,
    return_intermediate_states=False,
    state_v_first=False,
    a_log=None,
    dt_bias=None,
    layout="BNSD",
):
    """调用融合 GDN 前向；训练默认导出 gCumsum/A，推理显式设为 False。"""
    import torch

    q_shape = _shape(q)
    k_shape = _shape(k)
    v_shape = _shape(v)
    g_shape = _shape(g)
    beta_shape = _shape(beta)
    layout = str(layout)
    if layout not in ("BNSD", "BSND", "NTD", "TND"):
        raise RuntimeError(
            "npu_chunk_gated_delta_rule_fwd: layout must be one of BNSD, BSND, NTD or TND."
        )
    if len(q_shape) != 4 or len(k_shape) != 4 or len(v_shape) != 4:
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: q, k and v must be rank-4 tensors.")
    if q_shape[3] != 128 or k_shape[3] != 128:
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: the composite implementation requires K=128.")
    if v_shape[3] not in (128, 256):
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: Phase 6 requires V=128 or V=256.")
    if q_shape != k_shape:
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: q and k must have identical shapes.")
    if layout in ("BSND", "TND"):
        batch, tokens, k_heads, k_dim = q_shape
        _, v_tokens, v_heads, v_dim = v_shape
    else:
        batch, k_heads, tokens, k_dim = q_shape
        _, v_heads, v_tokens, v_dim = v_shape
    if v_tokens != tokens or v_shape[0] != batch:
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: v must match q/k in B and T.")
    if v_heads % k_heads != 0:
        raise RuntimeError(
            "npu_chunk_gated_delta_rule_fwd: Phase 6 GVA requires value heads divisible by key heads."
        )
    if beta_shape != (batch, tokens, v_heads) or g_shape != beta_shape:
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: beta and g must have shape [B,T,Hv].")
    if chunk_size not in (64, 128):
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: chunk_size must be 64 or 128.")
    if (cu_seqlens is None) != (chunk_indices is None):
        raise RuntimeError("npu_chunk_gated_delta_rule_fwd: cu_seqlens and chunk_indices must be provided together.")
    if cu_seqlens is not None:
        cu_seqlens = tuple(int(value) for value in cu_seqlens)
        chunk_indices = tuple(int(value) for value in chunk_indices)
        if batch != 1:
            raise RuntimeError("npu_chunk_gated_delta_rule_fwd: varlen BNSD input requires physical B=1.")
        if len(cu_seqlens) < 2 or cu_seqlens[0] != 0 or cu_seqlens[-1] != tokens:
            raise RuntimeError("npu_chunk_gated_delta_rule_fwd: cu_seqlens must start at 0 and end at T.")
        if any(left > right for left, right in zip(cu_seqlens, cu_seqlens[1:])):
            raise RuntimeError("npu_chunk_gated_delta_rule_fwd: cu_seqlens must be nondecreasing.")
        expected_indices = []
        for seq, (begin, end) in enumerate(zip(cu_seqlens, cu_seqlens[1:])):
            for local_chunk in range((end - begin + chunk_size - 1) // chunk_size):
                expected_indices.extend((seq, local_chunk))
        if tuple(expected_indices) != chunk_indices:
            raise RuntimeError("npu_chunk_gated_delta_rule_fwd: chunk_indices must use canonical sequence-major order.")

    output_final_state = _optional_bool(output_final_state, False)
    use_exp2 = _optional_bool(use_exp2, False)
    use_qk_l2norm_in_kernel = _optional_bool(use_qk_l2norm_in_kernel, False)
    use_gate_in_kernel = _optional_bool(use_gate_in_kernel, False)
    use_beta_sigmoid_in_kernel = _optional_bool(use_beta_sigmoid_in_kernel, False)
    allow_neg_eigval = _optional_bool(allow_neg_eigval, False)
    disable_recompute = _optional_bool(disable_recompute, True)
    return_intermediate_states = _optional_bool(return_intermediate_states, False)
    state_v_first = _optional_bool(state_v_first, False)
    if use_gate_in_kernel:
        raise ValueError("use_gate_in_kernel=True is not supported.")
    if a_log is not None or dt_bias is not None:
        raise ValueError("a_log and dt_bias must be None while gate-in-kernel is unsupported.")
    scale = _optional_float(scale, float(k_dim) ** -0.5)
    o = _empty((batch, tokens, v_heads, v_dim), v)
    g_cumsum = (
        _empty((batch, tokens, v_heads), g, dtype=torch.float32)
        if disable_recompute
        else None
    )
    A = (
        _empty((batch, v_heads, tokens, int(chunk_size)), q)
        if disable_recompute
        else None
    )
    beta_eff = (
        _empty((batch, tokens, v_heads), beta, dtype=torch.float32)
        if use_beta_sigmoid_in_kernel
        else None
    )
    final_state = None
    if output_final_state:
        seq_num = len(cu_seqlens) - 1 if cu_seqlens is not None else batch
        if initial_state is None:
            state_dtype = torch.float32
        else:
            state_dtype = initial_state.dtype
        state_tail = (v_dim, k_dim) if state_v_first else (k_dim, v_dim)
        final_state = _empty((seq_num, v_heads, *state_tail), q, dtype=state_dtype)
    h = None
    if return_intermediate_states:
        chunks = (
            sum(
                (right - left + chunk_size - 1) // chunk_size
                for left, right in zip(cu_seqlens, cu_seqlens[1:])
            )
            if cu_seqlens is not None
            else (tokens + chunk_size - 1) // chunk_size
        )
        state_tail = (v_dim, k_dim) if state_v_first else (k_dim, v_dim)
        h = _empty((batch, v_heads, chunks, *state_tail), q)
    layout_buffer = ctypes.create_string_buffer(layout.encode("utf-8"))
    # Hats alias the original inputs when normalization is disabled.
    q_hat = _empty(q_shape, q) if use_qk_l2norm_in_kernel else q
    k_hat = _empty(k_shape, k) if use_qk_l2norm_in_kernel else k
    norm_shape = (batch, k_heads, tokens)
    q_rstd = _empty(norm_shape, q, dtype=torch.float32) if use_qk_l2norm_in_kernel else None
    k_rstd = _empty(norm_shape, k, dtype=torch.float32) if use_qk_l2norm_in_kernel else None
    outputs = (o, final_state, g_cumsum, A, beta_eff, h, q_hat, k_hat, q_rstd, k_rstd)
    return _call_aclnn(
        "aclnnChunkGatedDeltaRuleFwd",
        lambda ctx: [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(g, "g"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(a_log, "a_log"),
            ctx.tensor(dt_bias, "dt_bias"),
            ctx.tensor(initial_state, "initial_state"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctypes.c_double(scale),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(use_exp2),
            ctypes.c_bool(use_qk_l2norm_in_kernel),
            ctypes.c_bool(allow_neg_eigval),
            ctypes.c_bool(state_v_first),
            ctx.tensor(o, "o"),
            ctx.tensor(final_state, "final_state"),
            ctx.tensor(q_hat if use_qk_l2norm_in_kernel else None, "q_hat"),
            ctx.tensor(k_hat if use_qk_l2norm_in_kernel else None, "k_hat"),
            ctx.tensor(q_rstd, "q_rstd"),
            ctx.tensor(k_rstd, "k_rstd"),
            ctx.tensor(beta_eff, "beta_eff"),
            ctx.tensor(g_cumsum, "g_cumsum"),
            ctx.tensor(A, "A"),
            ctx.tensor(h, "h"),
        ],
        outputs,
    )


def npu_causal_conv1d_bwd(
    x,
    y,
    weight,
    dy,
    initial_state=None,
    dht=None,
    *,
    query_start_loc=None,
    activation=0,
    input_layout="BSND",
):
    if not hasattr(x, "shape") or not hasattr(x, "ndim"):
        raise TypeError(
            f"x must be a torch.Tensor, got {type(x).__name__}."
        )
    if not hasattr(weight, "shape") or not hasattr(weight, "ndim"):
        raise TypeError(
            f"weight must be a torch.Tensor, got {type(weight).__name__}."
        )
    if weight.ndim != 2:
        raise ValueError(
            f"weight must have 2 dimensions, "
            f"got shape {tuple(weight.shape)}."
        )

    input_layout = str(input_layout)
    width, dim = int(weight.shape[0]), int(weight.shape[1])

    if input_layout in {"NTD", "TND"}:
        if query_start_loc is None:
            raise ValueError(
                f"query_start_loc is required for {input_layout} input."
            )
        try:
            batch = len(query_start_loc) - 1
        except TypeError:
            raise TypeError(
                "query_start_loc must be an object with a valid length, "
                f"got {type(query_start_loc).__name__}."
            ) from None

        if batch < 0:
            raise ValueError(
                "query_start_loc must contain at least one element."
            )
    else:
        if x.ndim == 0:
            raise ValueError(
                f"x can not be a scalar tensor for "
                f"{input_layout} input."
            )
        batch = int(x.shape[0])

    dx = _empty(_shape(x), x)
    dw = _empty((width, dim), weight)
    db = _empty((dim,), weight)
    dh0 = _empty((batch, width, dim), x)
    outputs = (dx, dw, db, dh0)

    layout_buffer = ctypes.create_string_buffer(
        input_layout.encode("utf-8")
    )

    return _call_aclnn(
        "aclnnCausalConv1dBwd",
        lambda ctx: [
            ctx.tensor(x, "x"),
            ctx.tensor(y, "y"),
            ctx.tensor(weight, "weight"),
            ctx.tensor(dy, "dy"),
            ctx.tensor(initial_state, "initial_state"),
            ctx.tensor(dht, "dht"),
            ctx.int_array(query_start_loc),
            ctypes.c_int64(int(activation)),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctx.tensor(dx, "dx"),
            ctx.tensor(dw, "dw"),
            ctx.tensor(db, "db"),
            ctx.tensor(dh0, "dh0"),
        ],
        outputs,
    )


def _kda_ceil_div(x: int, y: int) -> int:
    return (int(x) + int(y) - 1) // int(y)


def _kda_build_chunk_indices(cu_seqlens, chunk_size: int):
    if cu_seqlens is None:
        return None
    cu = tuple(int(value) for value in cu_seqlens)
    indices = []
    for seq in range(len(cu) - 1):
        seq_len = cu[seq + 1] - cu[seq]
        for chunk in range(_kda_ceil_div(seq_len, chunk_size)):
            indices.extend((seq, chunk))
    return tuple(indices)


def _kda_total_chunks(batch: int, seqlen: int, chunk_size: int, cu_seqlens, chunk_indices) -> int:
    del batch
    if chunk_indices is not None:
        return len(tuple(chunk_indices)) // 2
    if cu_seqlens is None:
        return _kda_ceil_div(seqlen, chunk_size)
    cu = tuple(int(value) for value in cu_seqlens)
    return sum(_kda_ceil_div(cu[i + 1] - cu[i], chunk_size) for i in range(len(cu) - 1))


def _run_kda_bwd_optimized(args):
    import torch

    bias_shape = None if args["dt_bias"] is None else args["dt_bias"].shape
    args = _prepare_kda_bwd_optimized(args)
    q = args["q"]
    token = tuple(q.shape)
    h = token[0 if args["cu_seqlens"] is not None else 1]
    bias = args["dt_bias"]
    cu, indices = args["cu_seqlens"], args["chunk_indices"]
    dq,dk,dv = (torch.empty_like(args[name]) for name in ("q","k","v"))
    db = torch.empty_like(args["beta"])
    dg = torch.empty(token,dtype=torch.float32,device=q.device)
    da = torch.empty((h,),dtype=torch.float32,device=q.device)
    dbias = None if args["dt_bias"] is None else torch.empty(bias_shape, dtype=torch.float32, device=q.device)
    outputs = (dq,dk,dv,db,dg,None,da,dbias)

    def build(ctx):
        def nd(x,name):
            return ctx.tensor(x,name,acl_format_override=ACL_FORMAT_ND,
                storage_shape_override=tuple(x.shape) if x is not None else None)
        values = [nd(args[name],name) for name in
            ("q","k","v","beta","gk","Aqk","Akk","w","qg","kg","v_new","h","d_o","raw_g","A_log")]
        values += [nd(bias,"dt_bias"),nd(None,"initial_state"),nd(None,"dht"),ctx.int_array(cu),ctx.int_array(indices),
            ctypes.c_double(float(args["scale"])),ctypes.c_int64(64),ctypes.c_bool(True),ctypes.c_bool(True),
            ctypes.c_double(float(args["lower_bound"])),ctypes.c_bool(bool(args["disable_recompute"])),
            ctypes.c_bool(True),ctypes.c_bool(False),nd(args["q_rstd"],"q_rstd"),nd(args["k_rstd"],"k_rstd")]
        values += [nd(x,name) for x,name in zip((dq,dk,dv,db,dg,None,da,
            None if dbias is None else dbias.view(h,128)),("dq","dk","dv","db","dg","dh0","dA","dbias"))]
        return values

    return _call_aclnn("aclnnChunkKdaBwdV2",build,outputs)


def npu_chunk_kda_bwd(
    q,
    k,
    v,
    beta,
    gk,
    Aqk,
    Akk,
    w,
    qg,
    kg,
    v_new,
    h,
    d_o,
    scale,
    *,
    raw_g=None,
    A_log=None,
    dt_bias=None,
    initial_state=None,
    dht=None,
    cu_seqlens=None,
    chunk_indices=None,
    chunk_size=64,
    safe_gate=True,
    lower_bound=-5.0,
    use_gate_in_kernel=False,
    disable_recompute=True,
    use_exp2=True,
    state_v_first=False,
    implementation="auto",
    q_rstd=None,
    k_rstd=None,
):
    """Run the canonical head-major fused KDA backward ACLNN operator.

    Dense tensors use ``[B, H, T, D]`` and packed tensors use ``[H, T, D]``.
    ``Aqk/Akk/w/qg/kg/v_new/h/gk`` are the saved intermediates returned by
    ``npu_chunk_kda_fwd(..., disable_recompute=True)`` after canonicalization.
    The return value is always ``(dq, dk, dv, db, dg, dh0, dA, dbias)`` to
    match the upstream GPU interface. ``dh0`` is ``None`` because the current
    fused path does not support ``initial_state``; ``dA`` and ``dbias`` are
    ``None`` unless raw-gate backward is enabled.
    """
    import torch

    if _select_kda_bwd_optimized(implementation, q_rstd, k_rstd, _optional_bool(disable_recompute, True)):
        return _run_kda_bwd_optimized(locals())

    chunk_size = int(chunk_size)
    if chunk_size != 64:
        raise RuntimeError("npu_chunk_kda_bwd: chunk_size must be 64.")
    if not _optional_bool(disable_recompute, True):
        raise RuntimeError(
            "npu_chunk_kda_bwd: disable_recompute=false is reserved but not supported."
        )
    if not _optional_bool(use_exp2, True):
        raise RuntimeError(
            "npu_chunk_kda_bwd: use_exp2=false is reserved but not supported."
        )
    if _optional_bool(state_v_first, False):
        raise RuntimeError(
            "npu_chunk_kda_bwd: state_v_first=true is reserved but not supported."
        )
    if initial_state is not None or dht is not None:
        raise RuntimeError(
            "npu_chunk_kda_bwd: initial_state and dht are not supported by the current fused backward."
        )

    use_gate_in_kernel = _optional_bool(use_gate_in_kernel, False)
    safe_gate = _optional_bool(safe_gate, True)
    if not safe_gate:
        raise RuntimeError(
            "npu_chunk_kda_bwd: safe_gate=False is reserved but not supported."
        )
    lower_bound = _optional_float(lower_bound, -5.0)
    q_shape, k_shape, v_shape = map(_shape, (q, k, v))
    is_varlen = cu_seqlens is not None
    expected_rank = 3 if is_varlen else 4
    if any(len(shape) != expected_rank for shape in (q_shape, k_shape, v_shape)):
        raise RuntimeError(
            "npu_chunk_kda_bwd: dense inputs use [B,H,T,D]; varlen inputs use [H,T,D]."
        )
    if q_shape != k_shape:
        raise RuntimeError("npu_chunk_kda_bwd: q and k must have identical shape.")
    if is_varlen:
        batch, heads, seqlen, key_dim = 1, q_shape[0], q_shape[1], q_shape[2]
        value_dim = v_shape[2]
        token_prefix = (heads, seqlen)
    else:
        batch, heads, seqlen, key_dim = q_shape
        value_dim = v_shape[3]
        token_prefix = (batch, heads, seqlen)
    if v_shape[:-1] != token_prefix:
        raise RuntimeError("npu_chunk_kda_bwd: v must share q's [B,H,T] or [H,T] prefix.")
    if key_dim != 128 or value_dim != 128:
        raise RuntimeError("npu_chunk_kda_bwd: current fused path requires K=128 and V=128.")
    if q.dtype not in {torch.float16, torch.bfloat16} or k.dtype != q.dtype or v.dtype != q.dtype:
        raise RuntimeError("npu_chunk_kda_bwd: q/k/v must use the same float16 or bfloat16 dtype.")

    key_shape = (*token_prefix, key_dim)
    value_shape = (*token_prefix, value_dim)
    matrix_shape = (*token_prefix, chunk_size)
    scalar_shape = token_prefix
    required_key_tensors = {"gk": gk, "w": w, "qg": qg, "kg": kg}
    for name, tensor in required_key_tensors.items():
        if _shape(tensor) != key_shape:
            raise RuntimeError(f"npu_chunk_kda_bwd: {name} must have shape {key_shape}.")
    for name, tensor in {"v_new": v_new, "d_o": d_o}.items():
        if _shape(tensor) != value_shape:
            raise RuntimeError(f"npu_chunk_kda_bwd: {name} must have shape {value_shape}.")
    for name, tensor in {"Aqk": Aqk, "Akk": Akk}.items():
        if _shape(tensor) != matrix_shape:
            raise RuntimeError(f"npu_chunk_kda_bwd: {name} must have shape {matrix_shape}.")
    if _shape(beta) != scalar_shape:
        raise RuntimeError(f"npu_chunk_kda_bwd: beta must have shape {scalar_shape}.")
    if gk.dtype != torch.float32:
        raise RuntimeError("npu_chunk_kda_bwd: gk must be float32.")
    if beta.dtype not in {torch.float32, torch.bfloat16}:
        raise RuntimeError("npu_chunk_kda_bwd: beta must be float32 or bfloat16.")

    cu = None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)
    if cu is not None:
        if len(cu) < 2 or cu[0] != 0 or cu[-1] != seqlen or any(a > b for a, b in zip(cu, cu[1:])):
            raise RuntimeError(
                "npu_chunk_kda_bwd: cu_seqlens must be nondecreasing, start at 0 and end at T."
            )
        if len(cu) - 1 > 1024:
            raise RuntimeError("npu_chunk_kda_bwd: varlen supports at most 1024 sequences.")
    canonical_indices = _kda_build_chunk_indices(cu, chunk_size)
    indices = canonical_indices if chunk_indices is None else tuple(int(value) for value in chunk_indices)
    if indices is not None and indices != canonical_indices:
        raise RuntimeError("npu_chunk_kda_bwd: chunk_indices must use canonical sequence-major order.")
    total_chunks = _kda_total_chunks(batch, seqlen, chunk_size, cu, indices)
    h_shape = ((total_chunks, heads, key_dim, value_dim) if is_varlen
               else (batch, total_chunks, heads, key_dim, value_dim))
    if _shape(h) != h_shape:
        raise RuntimeError(f"npu_chunk_kda_bwd: h must have shape {h_shape}.")

    d_a = None
    d_bias = None
    if use_gate_in_kernel:
        if raw_g is None or A_log is None:
            raise RuntimeError("npu_chunk_kda_bwd: raw_g and A_log are required when use_gate_in_kernel=True.")
        if _shape(raw_g) != key_shape or raw_g.dtype not in {torch.float32, torch.bfloat16}:
            raise RuntimeError("npu_chunk_kda_bwd: raw_g must be BF16/FP32 with the same shape as gk.")
        if _shape(A_log) != (heads,) or A_log.dtype != torch.float32:
            raise RuntimeError("npu_chunk_kda_bwd: A_log must be float32 [H].")
        if safe_gate and not (-5.0 <= lower_bound < 0.0):
            raise RuntimeError("npu_chunk_kda_bwd: lower_bound must be in [-5,0) for safe_gate.")
        d_a = _empty((heads,), q, dtype=torch.float32)
        if dt_bias is not None:
            if _shape(dt_bias) != (heads, key_dim) or dt_bias.dtype != torch.float32:
                raise RuntimeError("npu_chunk_kda_bwd: dt_bias must be float32 [H,K].")
            d_bias = _empty((heads, key_dim), q, dtype=torch.float32)
    elif any(value is not None for value in (raw_g, A_log, dt_bias)):
        raise RuntimeError("npu_chunk_kda_bwd: raw_g/A_log/dt_bias require use_gate_in_kernel=True.")

    # Atlas A2's packed V=256 state-scan path can leave non-finite dh-derived
    # gradients.  Reuse the proven dense kernel for each independent packed
    # sequence.  This keeps the public packed layout and reduction semantics,
    # while model/even-head V=128 calls remain on the original single launch.
    use_dense_varlen_fallback = is_varlen and value_dim == 256
    has_varlen_tail = is_varlen and any(
        (token_end - token_begin) % chunk_size != 0
        for token_begin, token_end in zip(cu, cu[1:])
    )
    needs_device_check = (
        use_dense_varlen_fallback or heads % 2 != 0 or has_varlen_tail
    )
    is_a2_device = False
    is_a5_device = False
    if needs_device_check:
        device_index = q.device.index
        if device_index is None:
            device_index = torch.npu.current_device()
        device_name = str(torch.npu.get_device_name(device_index))
        is_a2_device = device_name.startswith("Ascend910B")
        is_a5_device = "950" in device_name
    # A5's native packed tail can expose a short C-Intra AIC/AIV race.  Split
    # only packed sequences that contain tails into independent dense calls;
    # each call reuses the proven single-sequence padding path below.  Full
    # chunks and the long dense model path remain one fused launch.
    use_a5_varlen_tail_fallback = is_a5_device and has_varlen_tail
    if ((is_a2_device and use_dense_varlen_fallback) or
            use_a5_varlen_tail_fallback):
        sequence_results = []
        chunk_begin = 0
        for token_begin, token_end in zip(cu, cu[1:]):
            sequence_length = token_end - token_begin
            if sequence_length == 0:
                continue
            sequence_chunks = _kda_ceil_div(sequence_length, chunk_size)

            def dense_token_slice(tensor):
                if tensor is None:
                    return None
                return tensor.narrow(1, token_begin, sequence_length).unsqueeze(0).contiguous()

            sequence_results.append(npu_chunk_kda_bwd(
                dense_token_slice(q), dense_token_slice(k), dense_token_slice(v),
                dense_token_slice(beta), dense_token_slice(gk),
                dense_token_slice(Aqk), dense_token_slice(Akk),
                dense_token_slice(w), dense_token_slice(qg), dense_token_slice(kg),
                dense_token_slice(v_new),
                h.narrow(0, chunk_begin, sequence_chunks).unsqueeze(0).contiguous(),
                dense_token_slice(d_o), scale,
                raw_g=dense_token_slice(raw_g), A_log=A_log, dt_bias=dt_bias,
                initial_state=None, dht=None, cu_seqlens=None, chunk_indices=None,
                chunk_size=chunk_size, safe_gate=safe_gate,
                lower_bound=lower_bound, use_gate_in_kernel=use_gate_in_kernel,
                disable_recompute=True, use_exp2=True, state_v_first=False,
            ))
            chunk_begin += sequence_chunks

        restored = []
        for output_index in range(8):
            values = [result[output_index] for result in sequence_results]
            if values[0] is None:
                restored.append(None)
            elif output_index < 5:
                restored.append(torch.cat(
                    [value.squeeze(0) for value in values], dim=1
                ).contiguous())
            else:
                total = values[0]
                for value in values[1:]:
                    total = total + value
                restored.append(total)
        return tuple(restored)

    # A5's fused C-Intra short-tail path is not numerically stable yet.  A
    # single packed sequence can use the proven full-chunk path without
    # changing the math: append zero-gradient rows inside the already existing
    # final chunk, then slice token gradients back to the public shape.  The
    # number and layout of saved chunk states do not change.
    original_seqlen = seqlen
    original_heads = heads
    padded_tail = seqlen % chunk_size != 0 and (cu is None or len(cu) == 2)
    if padded_tail:
        padded_seqlen = _kda_ceil_div(seqlen, chunk_size) * chunk_size
        pad_rows = padded_seqlen - seqlen
        token_dim = 1 if is_varlen else 2

        def pad_token_rows(tensor, *, repeat_last=False):
            if tensor is None:
                return None
            pad_shape = list(_shape(tensor))
            pad_shape[token_dim] = pad_rows
            if repeat_last:
                tail = tensor.narrow(token_dim, seqlen - 1, 1).expand(*pad_shape).clone()
            else:
                tail = tensor.new_zeros(pad_shape)
            return torch.cat((tensor, tail), dim=token_dim).contiguous()

        q, k, v = (pad_token_rows(tensor) for tensor in (q, k, v))
        beta = pad_token_rows(beta)
        # gk is cumulative.  Holding its final real value constant keeps every
        # zero-padded contraction finite while contributing zero gradient.
        gk = pad_token_rows(gk, repeat_last=True)
        Aqk, Akk = (pad_token_rows(tensor) for tensor in (Aqk, Akk))
        w, qg, kg, v_new, d_o = (
            pad_token_rows(tensor) for tensor in (w, qg, kg, v_new, d_o)
        )
        raw_g = pad_token_rows(raw_g)
        seqlen = padded_seqlen
        cu = None if cu is None else (0, padded_seqlen)
        indices = _kda_build_chunk_indices(cu, chunk_size)

    # Atlas A2's fused Intra pipeline processes heads in pairs.  A one-head
    # final window can retain a stale final-head correction across launches.
    # Materialize a valid independent partner head on 910B only, then slice
    # every public gradient back to the original shape.  Ascend950/A5 and all
    # even-head model cases keep the original zero-copy path.
    padded_head = False
    if heads % 2 != 0:
        padded_head = is_a2_device
    if padded_head:
        head_dim = 0 if is_varlen else 1

        def duplicate_last_head(tensor, dim):
            if tensor is None:
                return None
            return torch.cat(
                (tensor, tensor.narrow(dim, heads - 1, 1).clone()), dim=dim
            ).contiguous()

        q, k, v, beta, gk, Aqk, Akk, w, qg, kg, v_new, d_o, raw_g = (
            duplicate_last_head(tensor, head_dim)
            for tensor in (
                q, k, v, beta, gk, Aqk, Akk, w, qg, kg, v_new, d_o, raw_g
            )
        )
        h = duplicate_last_head(h, 1 if is_varlen else 2)
        A_log = duplicate_last_head(A_log, 0)
        dt_bias = duplicate_last_head(dt_bias, 0)
        heads += 1
        d_a = _empty((heads,), q, dtype=torch.float32) if d_a is not None else None
        d_bias = (
            _empty((heads, key_dim), q, dtype=torch.float32)
            if d_bias is not None else None
        )

    dq = _empty_like(q, dtype=torch.float32)
    dk = _empty_like(k, dtype=torch.float32)
    dv = _empty_like(v)
    db = _empty_like(beta, dtype=torch.float32)
    dg = _empty_like(gk)
    # Keep the public result contract aligned with the upstream GPU operator.
    # The device ABI still has seven materialized outputs: initial_state/dh0 is
    # reserved but unsupported, so its public slot is an explicit None.
    dh0 = None
    outputs = (dq, dk, dv, db, dg, dh0, d_a, d_bias)

    # ChunkKdaBwd consumes the canonical dense BNSD/varlen NTD tensors as ND.
    # A contiguous rank-4/5 NPU tensor can otherwise carry an NCHW/NCDHW tag;
    # preserve its row-major storage and override descriptor metadata only.
    def nd_tensor(ctx, tensor, name):
        return ctx.tensor(
            tensor,
            name,
            acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=_shape(tensor) if tensor is not None else None,
        )

    result = _call_aclnn(
        "aclnnChunkKdaBwd",
        lambda ctx: [
            nd_tensor(ctx, q, "q"), nd_tensor(ctx, k, "k"), nd_tensor(ctx, v, "v"),
            nd_tensor(ctx, beta, "beta"), nd_tensor(ctx, gk, "gk"),
            nd_tensor(ctx, Aqk, "Aqk"), nd_tensor(ctx, Akk, "Akk"),
            nd_tensor(ctx, w, "w"), nd_tensor(ctx, qg, "qg"), nd_tensor(ctx, kg, "kg"),
            nd_tensor(ctx, v_new, "v_new"), nd_tensor(ctx, h, "h"), nd_tensor(ctx, d_o, "d_o"),
            nd_tensor(ctx, raw_g, "raw_g"), nd_tensor(ctx, A_log, "A_log"),
            nd_tensor(ctx, dt_bias, "dt_bias"), nd_tensor(ctx, None, "initial_state"),
            nd_tensor(ctx, None, "dht"), ctx.int_array(cu), ctx.int_array(indices),
            ctypes.c_double(float(scale)), ctypes.c_int64(chunk_size),
            ctypes.c_bool(safe_gate), ctypes.c_bool(use_gate_in_kernel),
            ctypes.c_double(lower_bound), ctypes.c_bool(True), ctypes.c_bool(True),
            ctypes.c_bool(False), nd_tensor(ctx, dq, "dq"), nd_tensor(ctx, dk, "dk"),
            nd_tensor(ctx, dv, "dv"), nd_tensor(ctx, db, "db"), nd_tensor(ctx, dg, "dg"),
            nd_tensor(ctx, None, "dh0"), nd_tensor(ctx, d_a, "dA"), nd_tensor(ctx, d_bias, "dbias"),
        ],
        outputs,
    )
    restored = []
    for index, value in enumerate(result):
        if value is None:
            restored.append(None)
            continue
        if padded_tail and index < 5:
            value = value.narrow(token_dim, 0, original_seqlen)
        if padded_head:
            if index < 5:
                value = value.narrow(0 if is_varlen else 1, 0, original_heads)
            elif index in (6, 7):
                value = value.narrow(0, 0, original_heads)
        restored.append(value.contiguous() if padded_tail or padded_head else value)
    return tuple(restored)


# V2 的三算子组合（ChunkKdaFwdPrepare + ChunkFwdH + ChunkKdaFwdFinalize）在
# 大工作量下比融合实现快，但 ChunkFwdH 的耗时对 head 数不敏感：当 (chunk, head)
# 总工作量偏小时整链会慢于单 kernel 的融合实现。
# 这里只按工作量门控，并与 Stable-ABI 适配层（csrc/src/stable_chunk_kda_fwd.cpp
# 的 kChunkKdaFwdV2MinWorkItems）保持同一条判据，两条后端才会逐位一致。
# 门控值取自 A2 实测：head 数 16、T=8192（2048 work item）时组合略慢，
# head 数 32 及以上组合领先 15% 以上。
_CHUNK_KDA_FWD_V2_MIN_WORK_ITEMS = 4096

# KDA chunked forward 的 K/V 只交付两档且必须同档：K=V=64 或 K=V=128；
# 混合档（K=64/V=128 等）与其它取值都不支持。与 Stable-ABI 薄层
# （``_stable._KDA_FWD_SUPPORTED_KV_DIMS``）和 aclnn L2 校验保持同一判据。
_KDA_FWD_SUPPORTED_KV_DIMS = frozenset({64, 128})


def _chunk_kda_fwd_use_v2(*, dtype, k_dim, v_dim, chunk_size, cu, work_items,
                          force_v2) -> bool:
    """是否命中 aclnnChunkKdaFwdV2 的三算子组合场景判据。

    force_v2 用于非默认 gate/L2norm 开关：这些语义只有组合入口支持。
    """

    import torch

    if dtype != torch.bfloat16:
        return False
    if k_dim != 128 or v_dim != 128:
        return False
    if chunk_size != 64:
        return False
    if cu is not None:
        if any(begin >= end for begin, end in zip(cu, cu[1:])):
            return False
    if force_v2:
        return True
    return work_items >= _CHUNK_KDA_FWD_V2_MIN_WORK_ITEMS


def npu_chunk_kda_fwd(
    q,
    k,
    v,
    g,
    beta,
    scale,
    chunk_size=64,
    *,
    layout="BSND",
    initial_state=None,
    output_final_state=False,
    cu_seqlens=None,
    chunk_indices=None,
    safe_gate=False,
    lower_bound=None,
    use_gate_in_kernel=False,
    A_log=None,
    dt_bias=None,
    disable_recompute=False,
    return_intermediate_states=False,
    state_v_first=False,
    epsilon=1e-6,
    use_qk_l2norm_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    allow_neg_eigval=False,
    use_exp2=True,
    # 反向 L2 norm 的保存值出口：调用方传入自己的张量即表示"需要导出"，
    # 不传（None）就是 nullptr，接口不报错、行为与改动前一致。
    q_hat_out=None,
    k_hat_out=None,
    q_rstd_out=None,
    k_rstd_out=None,
    beta_eff_out=None,
):
    import torch

    layout = str(layout)
    if layout not in {"BSND", "BNSD", "TND", "NTD"}:
        raise RuntimeError("npu_chunk_kda_fwd: layout must be uppercase and one of BSND, BNSD, TND, NTD.")
    chunk_size = int(chunk_size)
    if chunk_size not in {64, 128}:
        raise RuntimeError("npu_chunk_kda_fwd: chunk_size must be 64 or 128.")

    is_rank3 = layout in {"TND", "NTD"}
    is_sequence_major = layout in {"BSND", "TND"}
    q_shape, k_shape, v_shape, g_shape, beta_shape = map(
        _shape, (q, k, v, g, beta)
    )
    expected_rank = 3 if is_rank3 else 4
    if any(len(shape) != expected_rank for shape in (q_shape, k_shape, v_shape, g_shape)):
        raise RuntimeError("npu_chunk_kda_fwd: q/k/v/g rank does not match layout.")
    if len(beta_shape) != expected_rank - 1 or q_shape != k_shape:
        raise RuntimeError("npu_chunk_kda_fwd: beta rank must match layout and q/k shapes must be identical.")

    if layout == "TND":
        batch, seqlen, h_num, k_dim = 1, q_shape[0], q_shape[1], q_shape[2]
        hv_num, v_dim = v_shape[1], v_shape[2]
        expected_v = (seqlen, hv_num, v_dim)
        expected_g = (seqlen, hv_num, k_dim)
        expected_beta = (seqlen, hv_num)
    elif layout == "NTD":
        batch, h_num, seqlen, k_dim = 1, q_shape[0], q_shape[1], q_shape[2]
        hv_num, v_dim = v_shape[0], v_shape[2]
        expected_v = (hv_num, seqlen, v_dim)
        expected_g = (hv_num, seqlen, k_dim)
        expected_beta = (hv_num, seqlen)
    elif layout == "BSND":
        batch, seqlen, h_num, k_dim = q_shape
        hv_num, v_dim = v_shape[2], v_shape[3]
        expected_v = (batch, seqlen, hv_num, v_dim)
        expected_g = (batch, seqlen, hv_num, k_dim)
        expected_beta = (batch, seqlen, hv_num)
    else:
        batch, h_num, seqlen, k_dim = q_shape
        hv_num, v_dim = v_shape[1], v_shape[3]
        expected_v = (batch, hv_num, seqlen, v_dim)
        expected_g = (batch, hv_num, seqlen, k_dim)
        expected_beta = (batch, hv_num, seqlen)
    if v_shape != expected_v or g_shape != expected_g or beta_shape != expected_beta:
        raise RuntimeError("npu_chunk_kda_fwd: v/g/beta shapes do not match the selected layout.")
    if h_num <= 0 or hv_num < h_num or hv_num % h_num != 0 or h_num > 128 or hv_num > 128:
        raise RuntimeError("npu_chunk_kda_fwd: H/HV must satisfy 0 < H <= HV <= 128 and HV % H == 0.")
    if q.dtype not in {torch.float16, torch.bfloat16} or k.dtype != q.dtype or v.dtype != q.dtype:
        raise RuntimeError("npu_chunk_kda_fwd: q/k/v must use the same float16 or bfloat16 dtype.")
    if g.dtype not in {torch.float32, torch.bfloat16} or beta.dtype not in {torch.float32, torch.bfloat16}:
        raise RuntimeError("npu_chunk_kda_fwd: g and beta must be float32 or bfloat16.")
    if k_dim != v_dim or k_dim not in _KDA_FWD_SUPPORTED_KV_DIMS:
        raise RuntimeError(
            "npu_chunk_kda_fwd: K/V must both be 64 or both be 128 "
            "(mixed K/V and other dims are not supported), "
            f"but got K={k_dim}, V={v_dim}."
        )

    use_gate_in_kernel = _optional_bool(use_gate_in_kernel, False)
    safe_gate = _optional_bool(safe_gate, False)
    disable_recompute = _optional_bool(disable_recompute, False)
    return_intermediate_states = _optional_bool(return_intermediate_states, False)
    output_final_state = _optional_bool(output_final_state, False)
    state_v_first = _optional_bool(state_v_first, False)
    use_qk_l2norm_in_kernel = _optional_bool(use_qk_l2norm_in_kernel, False)
    use_beta_sigmoid_in_kernel = _optional_bool(use_beta_sigmoid_in_kernel, False)
    allow_neg_eigval = _optional_bool(allow_neg_eigval, False)
    use_exp2 = _optional_bool(use_exp2, True)
    epsilon = _optional_float(epsilon, 1e-6)
    if not (float(epsilon) > 0.0):
        raise RuntimeError("npu_chunk_kda_fwd: epsilon must be a positive finite number.")
    if allow_neg_eigval and not use_beta_sigmoid_in_kernel:
        raise RuntimeError(
            "npu_chunk_kda_fwd: allow_neg_eigval=True requires use_beta_sigmoid_in_kernel=True."
        )
    if (
        use_qk_l2norm_in_kernel or use_beta_sigmoid_in_kernel or allow_neg_eigval or not use_exp2
    ) and not (
        q.dtype == torch.bfloat16 and k_dim == 128 and v_dim == 128 and chunk_size == 64
    ):
        raise RuntimeError(
            "npu_chunk_kda_fwd: non-default gate/L2norm switches require the three-stage "
            "scenario (bfloat16 q/k/v, K=V=128, chunk_size=64)."
        )
    if use_gate_in_kernel:
        if A_log is None or _shape(A_log) != (hv_num,) or A_log.dtype != torch.float32:
            raise RuntimeError("npu_chunk_kda_fwd: A_log must be float32 [HV] when use_gate_in_kernel=True.")
        if dt_bias is not None and (_shape(dt_bias) != (hv_num * k_dim,) or dt_bias.dtype != torch.float32):
            raise RuntimeError("npu_chunk_kda_fwd: dt_bias must be float32 [HV*K].")
    lower_bound = _optional_float(lower_bound, -5.0)
    if use_gate_in_kernel and safe_gate and not (-5.0 <= lower_bound < 0.0):
        raise RuntimeError("npu_chunk_kda_fwd: lower_bound must be in [-5, 0) for safe gate.")

    cu = None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)
    if cu is not None:
        if len(cu) < 2 or cu[0] != 0 or cu[-1] != seqlen or any(a > b for a, b in zip(cu, cu[1:])):
            raise RuntimeError("npu_chunk_kda_fwd: cu_seqlens must be nondecreasing, start at 0 and end at T.")
        if len(cu) - 1 > 1024:
            raise RuntimeError("npu_chunk_kda_fwd: varlen input supports at most 1024 sequences.")
        if not is_rank3 and batch != 1:
            raise RuntimeError("npu_chunk_kda_fwd: rank4 varlen input requires B=1.")
    seq_num = len(cu) - 1 if cu is not None else batch
    canonical_indices = _kda_build_chunk_indices(cu, chunk_size)
    indices = canonical_indices if chunk_indices is None else tuple(int(value) for value in chunk_indices)
    if indices is not None and indices != canonical_indices:
        raise RuntimeError("npu_chunk_kda_fwd: chunk_indices must use canonical sequence-major order.")
    total_chunks = _kda_total_chunks(batch, seqlen, chunk_size, cu, indices)

    state_shape = (
        (seq_num, hv_num, v_dim, k_dim)
        if state_v_first
        else (seq_num, hv_num, k_dim, v_dim)
    )
    if initial_state is not None and (_shape(initial_state) != state_shape or initial_state.dtype != torch.float32):
        raise RuntimeError("npu_chunk_kda_fwd: initial_state shape/dtype does not match state_v_first.")

    attn_shape = (
        (seqlen, hv_num, v_dim)
        if is_rank3
        else (batch, seqlen, hv_num, v_dim)
    )
    matrix_shape = (
        (hv_num, seqlen, chunk_size)
        if is_rank3
        else (batch, hv_num, seqlen, chunk_size)
    )
    k_shape_head = (
        (hv_num, seqlen, k_dim)
        if is_rank3
        else (batch, hv_num, seqlen, k_dim)
    )
    v_shape_head = (
        (hv_num, seqlen, v_dim)
        if is_rank3
        else (batch, hv_num, seqlen, v_dim)
    )
    h_shape = (
        ((total_chunks, hv_num, v_dim, k_dim) if state_v_first
         else (total_chunks, hv_num, k_dim, v_dim))
        if is_rank3
        else ((batch, total_chunks, hv_num, v_dim, k_dim) if state_v_first
              else (batch, total_chunks, hv_num, k_dim, v_dim))
    )

    output_mask = kda_fwd_optional_output_mask(
        output_final_state=output_final_state,
        use_gate_in_kernel=use_gate_in_kernel,
        disable_recompute=disable_recompute,
        return_intermediate_states=return_intermediate_states,
    )
    attn_out = _empty(attn_shape, q)
    final_state = _empty(state_shape, q, dtype=torch.float32) if output_mask[1] else None
    gk_out = _empty(k_shape_head, q, dtype=torch.float32) if output_mask[2] else None
    aqk = _empty(matrix_shape, q)
    akk = _empty(matrix_shape, q)
    w = _empty(k_shape_head, q) if output_mask[5] else None
    u = _empty(v_shape_head, q) if output_mask[6] else None
    qg = _empty(k_shape_head, q) if output_mask[7] else None
    kg = _empty(k_shape_head, q) if output_mask[8] else None
    v_new = _empty(v_shape_head, q) if output_mask[9] else None
    h = _empty(h_shape, q) if output_mask[10] else None

    outputs = (attn_out, final_state, gk_out, aqk, akk, w, u, qg, kg, v_new, h)
    layout_buffer = ctypes.create_string_buffer(layout.encode("utf-8"))
    # 场景选择：命中三个独立算子的组合场景时优先走 aclnnChunkKdaFwdV2，
    # 其余场景回落到签名与 ABI 未变的 aclnnChunkKdaFwd（私有 L0 融合实现）。
    # 非默认 gate/L2norm 开关只有组合入口支持，此时不按工作量门控。
    force_v2 = bool(
        use_qk_l2norm_in_kernel
        or use_beta_sigmoid_in_kernel
        or allow_neg_eigval
        or not use_exp2
    )
    use_v2 = _chunk_kda_fwd_use_v2(
        dtype=q.dtype,
        k_dim=k_dim,
        v_dim=v_dim,
        chunk_size=chunk_size,
        cu=cu,
        work_items=hv_num * total_chunks,
        force_v2=force_v2,
    )
    if not use_v2 and (
        use_qk_l2norm_in_kernel or use_beta_sigmoid_in_kernel or allow_neg_eigval or not use_exp2
    ):
        raise RuntimeError(
            "npu_chunk_kda_fwd: non-default gate/L2norm switches require the three-stage "
            "scenario (bfloat16 q/k/v, K=V=128, chunk_size=64, strictly increasing cu_seqlens)."
        )
    # 保存值出口由 L2 层用空指针表达：只有真正给了张量才算"请求导出"，
    # 而导出只在组合入口（V2）上支持。
    saved_outputs = (q_hat_out, k_hat_out, q_rstd_out, k_rstd_out, beta_eff_out)
    if any(value is not None for value in saved_outputs) and not use_v2:
        raise RuntimeError(
            "npu_chunk_kda_fwd: q_hat/k_hat/q_rstd/k_rstd/beta_eff are only exported by "
            "the three-stage entry (bfloat16, K=V=128, chunk_size=64); do not pass these "
            "outputs in the current scenario."
        )

    def build_args(ctx):
        common = [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(g, "g"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(A_log, "A_log"),
            ctx.tensor(dt_bias, "dt_bias"),
            ctx.tensor(initial_state, "initial_state"),
            ctx.int_array(cu),
            ctx.int_array(indices),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctypes.c_double(float(scale)),
            ctypes.c_int64(chunk_size),
            ctypes.c_bool(safe_gate),
            ctypes.c_double(lower_bound),
            ctypes.c_bool(use_gate_in_kernel),
            ctypes.c_bool(state_v_first),
        ]
        if use_v2:
            common += [
                ctypes.c_double(float(epsilon)),
                ctypes.c_bool(use_qk_l2norm_in_kernel),
                ctypes.c_bool(use_beta_sigmoid_in_kernel),
                ctypes.c_bool(allow_neg_eigval),
                ctypes.c_bool(use_exp2),
            ]
        common += [
            ctx.tensor(attn_out, "attn_out"),
            ctx.tensor(final_state, "final_state"),
            ctx.tensor(gk_out, "gk"),
            ctx.tensor(aqk, "Aqk"),
            ctx.tensor(akk, "Akk"),
            ctx.tensor(w, "w"),
            ctx.tensor(u, "u"),
            ctx.tensor(qg, "qg"),
            ctx.tensor(kg, "kg"),
            ctx.tensor(v_new, "v_new"),
            ctx.tensor(h, "h"),
        ]
        if use_v2:
            # 反向 L2 norm 需要的保存值：调用方传了才导出，没传就是 nullptr，
            # 因此老调用（不传这五个）与改动前逐位一致。
            common += [
                ctx.tensor(q_hat_out, "q_hat"),
                ctx.tensor(k_hat_out, "k_hat"),
                ctx.tensor(q_rstd_out, "q_rstd"),
                ctx.tensor(k_rstd_out, "k_rstd"),
                ctx.tensor(beta_eff_out, "beta_eff"),
            ]
        return common

    _call_aclnn("aclnnChunkKdaFwdV2" if use_v2 else "aclnnChunkKdaFwd", build_args, outputs)
    initial_state_out = initial_state
    return (*outputs, initial_state_out)


def npu_chunk_kda_fwd_prepare(
    q,
    k,
    v,
    g,
    beta,
    scale,
    chunk_size=64,
    *,
    layout="BSND",
    cu_seqlens=None,
    chunk_indices=None,
    safe_gate=False,
    lower_bound=None,
    use_gate_in_kernel=False,
    A_log=None,
    dt_bias=None,
    epsilon=1e-6,
    use_qk_l2norm_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    allow_neg_eigval=False,
    use_exp2=True,
    # 与算子文档一致：Prepare 的公开档位选择器（none/forward/recompute/save）。
    # 默认 save 保持"13 项全部返回"的兼容行为；槽位非空的组合由档位决定，
    # 未选中的槽传 nullptr，不参与公开 GM 写回。
    backward_mode="save",
):
    """三算子组合里 Prepare 阶段的公共入口（ChunkKdaFwdPrepare）。

    老路径完全不受影响：这个入口是新增的，调用方不传任何输出槽时它只做参数
    校验并返回 13 个 None。反向需要的 L2 norm 保存值（q_hat/k_hat/q_rstd/
    k_rstd/beta_eff）就在这里由调用方按需提供输出张量。
    """
    import torch

    layout = str(layout)
    if layout not in {"BSND", "BNSD", "TND", "NTD"}:
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: layout must be BSND, BNSD, TND or NTD.")
    chunk_size = int(chunk_size)
    if chunk_size not in {64, 128}:
        raise RuntimeError("npu_chunk_kda_fwd_prepare: chunk_size must be 64 or 128.")

    is_rank3 = layout in {"TND", "NTD"}
    is_sequence_major = layout in {"BSND", "TND"}
    q_shape, k_shape, v_shape, g_shape, beta_shape = map(
        _shape, (q, k, v, g, beta))
    expected_rank = 3 if is_rank3 else 4
    if any(len(shape) != expected_rank for shape in (q_shape, k_shape, v_shape, g_shape)):
        raise RuntimeError("npu_chunk_kda_fwd_prepare: q/k/v/g rank does not match layout.")
    if q_shape != k_shape or len(beta_shape) != expected_rank - 1:
        raise RuntimeError("npu_chunk_kda_fwd_prepare: q/k shapes must match and beta rank must match layout.")

    if is_rank3:
        seqlen, h_num, k_dim = q_shape
        hv_num, v_dim = v_shape[1], v_shape[2]
        batch = 1
    else:
        if is_sequence_major:
            batch, seqlen, h_num, k_dim = q_shape
            hv_num, v_dim = v_shape[2], v_shape[3]
        else:
            batch, h_num, seqlen, k_dim = q_shape
            hv_num, v_dim = v_shape[1], v_shape[3]
    if h_num <= 0 or hv_num < h_num or hv_num % h_num != 0 or h_num > 128 or hv_num > 128:
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: H/HV must satisfy 0 < H <= HV <= 128 and HV % H == 0.")
    if q.dtype not in {torch.float16, torch.bfloat16} or k.dtype != q.dtype or v.dtype != q.dtype:
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: q/k/v must use the same float16 or bfloat16 dtype.")
    if g.dtype not in {torch.float32, torch.bfloat16} or beta.dtype not in {torch.float32, torch.bfloat16}:
        raise RuntimeError("npu_chunk_kda_fwd_prepare: g and beta must be float32 or bfloat16.")
    if k_dim != v_dim or k_dim not in _KDA_FWD_SUPPORTED_KV_DIMS:
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: K/V must both be 64 or both be 128, "
            f"but got K={k_dim}, V={v_dim}.")
    epsilon = _optional_float(epsilon, 1e-6)
    if not (float(epsilon) > 0.0):
        raise RuntimeError("npu_chunk_kda_fwd_prepare: epsilon must be a positive finite number.")
    use_gate_in_kernel = _optional_bool(use_gate_in_kernel, False)
    safe_gate = _optional_bool(safe_gate, False)
    use_qk_l2norm_in_kernel = _optional_bool(use_qk_l2norm_in_kernel, False)
    use_beta_sigmoid_in_kernel = _optional_bool(use_beta_sigmoid_in_kernel, False)
    allow_neg_eigval = _optional_bool(allow_neg_eigval, False)
    use_exp2 = _optional_bool(use_exp2, True)
    if use_gate_in_kernel:
        if A_log is None or _shape(A_log) != (hv_num,) or A_log.dtype != torch.float32:
            raise RuntimeError(
                "npu_chunk_kda_fwd_prepare: A_log must be float32 [HV] when use_gate_in_kernel=True.")
        if dt_bias is not None and (_shape(dt_bias) != (hv_num * k_dim,) or
                                    dt_bias.dtype != torch.float32):
            raise RuntimeError("npu_chunk_kda_fwd_prepare: dt_bias must be float32 [HV*K].")
    lower_bound = _optional_float(lower_bound, -5.0)
    if use_gate_in_kernel and safe_gate and not (-5.0 <= lower_bound < 0.0):
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: lower_bound must be in [-5, 0) for safe gate.")
    cu = None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)
    if cu is not None:
        if len(cu) < 2 or cu[0] != 0 or cu[-1] != seqlen or any(a > b for a, b in zip(cu, cu[1:])):
            raise RuntimeError(
                "npu_chunk_kda_fwd_prepare: cu_seqlens must be nondecreasing, start at 0 and end at T.")
        if not is_rank3 and batch != 1:
            raise RuntimeError("npu_chunk_kda_fwd_prepare: rank4 varlen input requires B=1.")
    canonical_indices = _kda_build_chunk_indices(cu, chunk_size)
    indices = canonical_indices if chunk_indices is None else tuple(
        int(value) for value in chunk_indices)
    if indices is not None and indices != canonical_indices:
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: chunk_indices must use canonical sequence-major order.")
    total_chunks = _kda_total_chunks(batch, seqlen, chunk_size, cu, indices)

    k_shape_head = ((hv_num, seqlen, k_dim) if is_rank3
                    else (batch, hv_num, seqlen, k_dim))
    qk_shape_head = ((h_num, seqlen, k_dim) if is_rank3
                     else (batch, h_num, seqlen, k_dim))
    v_shape_head = ((hv_num, seqlen, v_dim) if is_rank3
                    else (batch, hv_num, seqlen, v_dim))
    matrix_shape = ((hv_num, seqlen, chunk_size) if is_rank3
                    else (batch, hv_num, seqlen, chunk_size))
    qk_scalar_shape = (h_num, seqlen) if is_rank3 else (batch, h_num, seqlen)
    value_scalar_shape = (hv_num, seqlen) if is_rank3 else (batch, hv_num, seqlen)

    # L2 层的档位契约（见 aclnnChunkKdaFwdPrepare 的 CheckRequiredNotNull /
    # GetOutputMode）：gk/aqk/w/u/kg/qg_scaled 六个槽必选，akk 及以上档位才允许
    # 带 akk，aux（q_hat/k_hat/q_rstd/k_rstd/beta_eff）只允许在 recompute/save 档
    # 出现。为了满足"不给就不报错"，调用方没提供的**前置槽**由这里补齐；
    # 调用方想复用显存就把自己的 buffer 通过对应 out 参数传进来。
    # 期望形状/dtype：
    expected_outputs = {
        "gk": (k_shape_head, torch.float32),
        "Aqk": (matrix_shape, q.dtype),
        "Akk": (matrix_shape, q.dtype),
        "w": (k_shape_head, q.dtype),
        "u": (v_shape_head, q.dtype),
        "qg": (k_shape_head, q.dtype),
        "kg": (k_shape_head, q.dtype),
        "qg_scaled": (k_shape_head, q.dtype),
        "q_hat": (qk_shape_head, q.dtype),
        "k_hat": (qk_shape_head, q.dtype),
        "q_rstd": (qk_scalar_shape, torch.float32),
        "k_rstd": (qk_scalar_shape, torch.float32),
        "beta_eff": (value_scalar_shape, torch.float32),
    }
    # 档位 → 需要产出的槽位（与算子文档的 backward_mode 表一致）。
    mode_slots = {
        "none": ("gk", "Aqk", "w", "u", "kg", "qg_scaled"),
        "forward": ("gk", "Aqk", "Akk", "w", "u", "kg", "qg_scaled"),
        "recompute": ("gk", "Aqk", "Akk", "w", "u", "kg", "qg_scaled",
                      "q_hat", "k_hat", "q_rstd", "k_rstd", "beta_eff"),
        "save": tuple(expected_outputs),
    }
    backward_mode = str(backward_mode).lower()
    if backward_mode not in mode_slots:
        raise RuntimeError(
            "npu_chunk_kda_fwd_prepare: backward_mode must be none/forward/recompute/save.")
    selected = set(mode_slots[backward_mode])

    produced = {
        name: (_empty(shape, q, dtype=dtype) if name in selected else None)
        for name, (shape, dtype) in expected_outputs.items()
    }

    gk_out = produced["gk"]
    aqk_out = produced["Aqk"]
    akk_out = produced["Akk"]
    w_out = produced["w"]
    u_out = produced["u"]
    qg_out = produced["qg"]
    kg_out = produced["kg"]
    qg_scaled_out = produced["qg_scaled"]
    q_hat_out = produced["q_hat"]
    k_hat_out = produced["k_hat"]
    q_rstd_out = produced["q_rstd"]
    k_rstd_out = produced["k_rstd"]
    beta_eff_out = produced["beta_eff"]

    outputs = (gk_out, aqk_out, akk_out, w_out, u_out, qg_out, kg_out,
               qg_scaled_out, q_hat_out, k_hat_out, q_rstd_out, k_rstd_out,
               beta_eff_out)
    layout_buffer = ctypes.create_string_buffer(layout.encode("utf-8"))

    def build_args(ctx):
        def slot(tensor, name):
            # 只覆盖 storage shape（ctypes 描述符默认是展平 numel，prepare 的
            # tiling 需要逻辑维度）；format 不再强制 ND，交给描述符原样传递。
            if tensor is None:
                return ctx.tensor(None, name)
            return ctx.tensor(tensor, name, storage_shape_override=_shape(tensor))

        return [
            slot(q, "q"),
            slot(k, "k"),
            slot(v, "v"),
            slot(g, "g"),
            slot(beta, "beta"),
            slot(A_log, "A_log"),
            slot(dt_bias, "dt_bias"),
            ctx.int_array(cu),
            ctx.int_array(indices),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctypes.c_double(float(scale)),
            ctypes.c_int64(chunk_size),
            ctypes.c_double(float(epsilon)),
            ctypes.c_bool(use_qk_l2norm_in_kernel),
            ctypes.c_bool(use_gate_in_kernel),
            ctypes.c_bool(use_beta_sigmoid_in_kernel),
            ctypes.c_bool(allow_neg_eigval),
            ctypes.c_bool(safe_gate),
            ctypes.c_double(lower_bound),
            ctypes.c_bool(use_exp2),
            slot(gk_out, "gk"),
            slot(aqk_out, "Aqk"),
            slot(akk_out, "Akk"),
            slot(w_out, "w"),
            slot(u_out, "u"),
            slot(qg_out, "qg"),
            slot(kg_out, "kg"),
            slot(qg_scaled_out, "qg_scaled"),
            slot(q_hat_out, "q_hat"),
            slot(k_hat_out, "k_hat"),
            slot(q_rstd_out, "q_rstd"),
            slot(k_rstd_out, "k_rstd"),
            slot(beta_eff_out, "beta_eff"),
        ]

    return _call_aclnn("aclnnChunkKdaFwdPrepare", build_args, outputs)


def npu_kda_gate_cumsum(
    g,
    chunk_size,
    *,
    A_log=None,
    dt_bias=None,
    cu_seqlens=None,
    use_gate_in_kernel=False,
    safe_gate=False,
    lower_bound=None,
):
    import torch

    out = _empty(_shape(g), g, dtype=torch.float32)
    return _call_aclnn(
        "aclnnKdaGateCumsum",
        lambda ctx: [
            ctx.tensor(g, "g"),
            ctx.tensor(A_log, "A_log"),
            ctx.tensor(dt_bias, "dt_bias"),
            ctx.int_array(None if cu_seqlens is None else tuple(int(value) for value in cu_seqlens)),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(_optional_bool(use_gate_in_kernel, False)),
            ctypes.c_bool(_optional_bool(safe_gate, False)),
            ctypes.c_double(_optional_float(lower_bound, -5.0)),
            ctx.tensor(out, "gk"),
        ],
        out,
    )

def npu_recurrent_kda(
    q,
    k,
    v,
    g,
    beta,
    initial_state=None,
    *,
    cu_seqlens=None,
    ssm_state_indices=None,
    A_log=None,
    dt_bias=None,
    num_accepted_tokens=None,
    layout="BSND",
    scale=None,
    output_final_state=False,
    inplace_final_state=True,
    use_qk_l2norm_in_kernel=False,
    use_gate_in_kernel=False,
    use_beta_sigmoid_in_kernel=False,
    allow_neg_eigval=False,
    safe_gate=False,
    lower_bound=None,
    state_v_first=False,
):
    import torch

    layout = str(layout)
    if layout not in ("BSND", "TND"):
        raise RuntimeError("npu_recurrent_kda: layout must be BSND or TND.")
    is_tnd = layout == "TND"
    q_shape, k_shape, v_shape = _shape(q), _shape(k), _shape(v)
    g_shape, beta_shape = _shape(g), _shape(beta)
    expected_q_rank = 3 if is_tnd else 4
    if (
        len(q_shape) != expected_q_rank
        or len(k_shape) != expected_q_rank
        or len(v_shape) != expected_q_rank
        or len(g_shape) != expected_q_rank
        or len(beta_shape) != (2 if is_tnd else 3)
    ):
        raise RuntimeError(
            "npu_recurrent_kda: layout/rank mismatch. TND expects q/k [T,H,K], v [T,HV,V], "
            "g [T,HV,K], beta [T,HV]; BSND expects q/k [B,T,H,K], v [B,T,HV,V], "
            "g [B,T,HV,K], beta [B,T,HV]."
        )
    if q_shape != k_shape:
        raise RuntimeError("npu_recurrent_kda: q and k must have identical shape.")
    if q.dtype != torch.bfloat16 or k.dtype != torch.bfloat16 or v.dtype != torch.bfloat16:
        raise RuntimeError("npu_recurrent_kda: q/k/v currently support bfloat16 only.")
    if any(tensor.device != q.device for tensor in (k, v, g, beta)):
        raise RuntimeError("npu_recurrent_kda: q/k/v/g/beta must be on the same device.")
    if g.dtype not in (torch.float16, torch.bfloat16, torch.float32):
        raise RuntimeError("npu_recurrent_kda: g must use FP16, BF16 or FP32.")
    if beta.dtype not in (torch.float16, torch.bfloat16, torch.float32):
        raise RuntimeError("npu_recurrent_kda: beta must use FP16, BF16 or FP32.")

    if is_tnd:
        total_tokens, heads, key_dim = q_shape
        batch, dense_seq_len = 1, total_tokens
        value_heads, value_dim = v_shape[1], v_shape[2]
        value_shape_ok = (
            v_shape[0] == total_tokens
            and g_shape == (total_tokens, value_heads, key_dim)
            and beta_shape == (total_tokens, value_heads)
        )
    else:
        batch, dense_seq_len, heads, key_dim = q_shape
        total_tokens = batch * dense_seq_len
        value_heads, value_dim = v_shape[2], v_shape[3]
        value_shape_ok = (
            v_shape[:2] == (batch, dense_seq_len)
            and g_shape == (batch, dense_seq_len, value_heads, key_dim)
            and beta_shape == (batch, dense_seq_len, value_heads)
        )
    if not value_shape_ok:
        raise RuntimeError("npu_recurrent_kda: v/g/beta shape mismatch.")
    if min(total_tokens, dense_seq_len, heads, value_heads, key_dim, value_dim) <= 0:
        raise RuntimeError("npu_recurrent_kda: all shape dimensions must be positive.")
    if value_heads % heads != 0:
        raise RuntimeError("npu_recurrent_kda: HV must be divisible by H.")
    if (key_dim, value_dim) not in ((128, 128), (128, 256)):
        raise RuntimeError("npu_recurrent_kda: K/V currently support only K=128,V=128 or K=128,V=256.")

    if cu_seqlens is None:
        seq_num = batch if not is_tnd else 1
    else:
        if (
            not isinstance(cu_seqlens, torch.Tensor)
            or cu_seqlens.dim() != 1
            or cu_seqlens.numel() < 2
            or cu_seqlens.dtype not in (torch.int32, torch.int64)
        ):
            raise RuntimeError("npu_recurrent_kda: cu_seqlens must be a 1D INT32 or INT64 tensor.")
        if cu_seqlens.device != q.device:
            raise RuntimeError("npu_recurrent_kda: cu_seqlens must be on the same device as q.")
        seq_num = int(cu_seqlens.shape[0]) - 1

    state_v_first = _optional_bool(state_v_first, False)
    expected_tail = (
        (value_heads, value_dim, key_dim)
        if state_v_first
        else (value_heads, key_dim, value_dim)
    )
    inplace = _optional_bool(inplace_final_state, True)
    if initial_state is None:
        if inplace:
            raise RuntimeError("npu_recurrent_kda: inplace_final_state=True requires initial_state.")
        state_shape = (seq_num, *expected_tail)
        initial_state_work = _zeros(state_shape, q, dtype=torch.float32)
    else:
        if initial_state.dtype not in (torch.float32, torch.bfloat16):
            raise RuntimeError("npu_recurrent_kda: initial_state must use FP32 or BF16.")
        if initial_state.device != q.device:
            raise RuntimeError("npu_recurrent_kda: initial_state must be on the same device as q.")
        state_shape = _shape(initial_state)
        if len(state_shape) != 4 or state_shape[0] <= 0 or state_shape[1:] != expected_tail:
            layout_desc = "[state_capacity,HV,V,K]" if state_v_first else "[state_capacity,HV,K,V]"
            raise RuntimeError(f"npu_recurrent_kda: initial_state must be {layout_desc}.")
        initial_state_work = initial_state

    if ssm_state_indices is not None:
        packed_1d = ssm_state_indices.dim() == 1 and int(ssm_state_indices.shape[0]) >= total_tokens
        speculative_2d = (
            ssm_state_indices.dim() == 2
            and int(ssm_state_indices.shape[0]) == seq_num
            and int(ssm_state_indices.shape[1]) > 0
        )
        if ssm_state_indices.dtype not in (torch.int32, torch.int64) or not (packed_1d or speculative_2d):
            raise RuntimeError(
                "npu_recurrent_kda: ssm_state_indices must be INT32/INT64 packed [T] "
                "or speculative [seq_num,max_step]."
            )
        if ssm_state_indices.device != q.device:
            raise RuntimeError("npu_recurrent_kda: ssm_state_indices must be on the same device as q.")
    elif state_shape[0] != seq_num:
        raise RuntimeError("npu_recurrent_kda: without ssm_state_indices, state_capacity must equal seq_num.")
    if num_accepted_tokens is not None:
        if ssm_state_indices is None:
            raise RuntimeError("npu_recurrent_kda: num_accepted_tokens requires ssm_state_indices.")
        if num_accepted_tokens.dtype not in (torch.int32, torch.int64) or _shape(num_accepted_tokens) != (seq_num,):
            raise RuntimeError("npu_recurrent_kda: num_accepted_tokens must be INT32/INT64 [seq_num].")
        if num_accepted_tokens.device != q.device:
            raise RuntimeError("npu_recurrent_kda: num_accepted_tokens must be on the same device as q.")

    use_gate = _optional_bool(use_gate_in_kernel, False)
    safe = _optional_bool(safe_gate, False)
    lower = _optional_float(lower_bound, -5.0)
    if use_gate:
        if A_log is None or A_log.dtype != torch.float32 or _shape(A_log) != (value_heads,):
            raise RuntimeError("npu_recurrent_kda: A_log must be FP32 [HV] when use_gate_in_kernel=True.")
        if A_log.device != q.device:
            raise RuntimeError("npu_recurrent_kda: A_log must be on the same device as q.")
        if safe and not -5.0 <= lower < 0.0:
            raise RuntimeError("npu_recurrent_kda: lower_bound must be in [-5,0) when safe_gate=True.")
        if dt_bias is not None:
            valid_bias_shape = _shape(dt_bias) in ((value_heads * key_dim,), (value_heads, key_dim))
            if dt_bias.dtype != torch.float32 or not valid_bias_shape:
                raise RuntimeError("npu_recurrent_kda: dt_bias must be FP32 [HV*K] or [HV,K].")
            if dt_bias.device != q.device:
                raise RuntimeError("npu_recurrent_kda: dt_bias must be on the same device as q.")
    elif safe or A_log is not None or dt_bias is not None:
        raise RuntimeError("npu_recurrent_kda: A_log, dt_bias and safe_gate require use_gate_in_kernel=True.")

    out = _empty_like(v)
    final_state_work = initial_state_work if inplace else _empty(state_shape, initial_state_work)
    final_state_arg = final_state_work
    output_final = _optional_bool(output_final_state, False)
    scale_value = _optional_float(scale, key_dim ** -0.5)
    layout_buffer = ctypes.create_string_buffer(layout.encode("utf-8"))

    def build_args(ctx):
        return [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(g, "g"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(initial_state_work, "initial_state"),
            ctx.tensor(cu_seqlens, "cu_seqlens"),
            ctx.tensor(ssm_state_indices, "ssm_state_indices"),
            ctx.tensor(A_log, "A_log"),
            ctx.tensor(dt_bias, "dt_bias"),
            ctx.tensor(num_accepted_tokens, "num_accepted_tokens"),
            ctypes.cast(layout_buffer, ctypes.c_char_p),
            ctypes.c_double(float(scale_value)),
            ctypes.c_bool(output_final),
            ctypes.c_bool(inplace),
            ctypes.c_bool(_optional_bool(use_qk_l2norm_in_kernel, False)),
            ctypes.c_bool(use_gate),
            ctypes.c_bool(_optional_bool(use_beta_sigmoid_in_kernel, False)),
            ctypes.c_bool(_optional_bool(allow_neg_eigval, False)),
            ctypes.c_bool(safe),
            ctypes.c_double(lower),
            ctypes.c_bool(state_v_first),
            ctx.tensor(out, "attn_out"),
            ctx.tensor(final_state_arg, "final_state"),
        ]

    _call_aclnn(
        "aclnnRecurrentKda",
        build_args,
        (out, initial_state_work, final_state_arg),
    )
    final_state = final_state_work if output_final else None
    return out, final_state

# Dense BSND Host code transposes all ten inputs to BNSD. Its four internal
# outputs alias the transposed gradient inputs, so bounding this input footprint
# bounds the dominant per-call workspace without changing kernel/tiling.
_KDA_BSND_TRANSPOSE_WORKSPACE_BUDGET_BYTES = 960 * 1024 * 1024


def _chunk_kda_bwd_intra_bsnd_segment_tokens(
    tensors,
    seqlen,
    chunk_size,
    *,
    workspace_budget_bytes=None,
):
    """Return a chunk-aligned BSND segment length for bounded transposes."""

    if workspace_budget_bytes is None:
        workspace_budget_bytes = _KDA_BSND_TRANSPOSE_WORKSPACE_BUDGET_BYTES
    total_transpose_bytes = sum(
        int(tensor.numel()) * int(tensor.element_size()) for tensor in tensors
    )
    if total_transpose_bytes <= workspace_budget_bytes:
        return int(seqlen)

    bytes_per_token = total_transpose_bytes // int(seqlen)
    budget_tokens = int(workspace_budget_bytes) // bytes_per_token
    aligned_tokens = (budget_tokens // int(chunk_size)) * int(chunk_size)
    return min(int(seqlen), max(int(chunk_size), aligned_tokens))


def npu_chunk_kda_bwd_intra(
    q,
    k,
    gk,
    beta,
    dAqk,
    dAkk,
    dq,
    dk,
    db,
    dg,
    *,
    cu_seqlens=None,
    chunk_indices=None,
    chunk_size=64,
    safe_gate=True,
    layout="BSND",
):
    """Run the safe-gate KDA intra-chunk backward kernel.

    BNSD is the native performance layout. BSND is converted through the same
    layout-swap operator used by the existing KDA forward path for dense input.
    Varlen uses zero-copy TND [T,H,D], with BSND [1,T,H,D] accepted as a
    storage-compatible form. q/k must be BF16; beta accepts BF16 or FP32.
    """
    import torch

    tensors = {
        "q": q,
        "k": k,
        "gk": gk,
        "beta": beta,
        "dAqk": dAqk,
        "dAkk": dAkk,
        "dq": dq,
        "dk": dk,
        "db": db,
        "dg": dg,
    }
    layout = str(layout)
    if layout not in {"BSND", "BNSD", "TND"}:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: supports dense BSND/BNSD or varlen TND."
        )
    if not bool(safe_gate):
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: safe_gate=False is reserved but not supported in v1."
        )
    chunk_size = int(chunk_size)
    if chunk_size != 64:
        raise RuntimeError("npu_chunk_kda_bwd_intra: chunk_size must be 64.")
    expected_dtypes = {
        "q": torch.bfloat16,
        "k": torch.bfloat16,
        "gk": torch.float32,
        "dAqk": torch.float32,
        "dAkk": torch.float32,
        "dq": torch.float32,
        "dk": torch.float32,
        "db": torch.float32,
        "dg": torch.float32,
    }
    for name, tensor in tensors.items():
        if name == "beta":
            if tensor.dtype not in {torch.bfloat16, torch.float32}:
                raise RuntimeError(
                    "npu_chunk_kda_bwd_intra: beta must be torch.bfloat16 "
                    "or torch.float32."
                )
        elif tensor.dtype != expected_dtypes[name]:
            raise RuntimeError(
                f"npu_chunk_kda_bwd_intra: {name} must be {expected_dtypes[name]}."
            )
        if tensor.device != q.device:
            raise RuntimeError(
                f"npu_chunk_kda_bwd_intra: {name} must be on the same device as q."
            )
        if not tensor.is_contiguous():
            raise RuntimeError(
                f"npu_chunk_kda_bwd_intra: {name} must be contiguous; implicit copies are disabled."
            )
    if chunk_indices is not None and cu_seqlens is None:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: chunk_indices requires cu_seqlens."
        )
    is_varlen = cu_seqlens is not None
    if is_varlen and layout == "BNSD":
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: varlen supports TND or BSND, not BNSD."
        )
    if not is_varlen and layout == "TND":
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: TND requires cu_seqlens."
        )

    q_shape = _shape(q)
    expected_rank = 3 if layout == "TND" else 4
    if len(q_shape) != expected_rank:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: q rank does not match layout."
        )
    if layout == "TND":
        seqlen, heads, head_dim = q_shape
        batch = 1
        scalar_shape = (seqlen, heads)
        matrix_shape = (seqlen, heads, chunk_size)
    elif layout == "BSND":
        batch, seqlen, heads, head_dim = q_shape
        scalar_shape = (batch, seqlen, heads)
        matrix_shape = (batch, seqlen, heads, chunk_size)
    else:
        batch, heads, seqlen, head_dim = q_shape
        scalar_shape = (batch, heads, seqlen)
        matrix_shape = (batch, heads, seqlen, chunk_size)
    if batch <= 0 or heads <= 0 or seqlen <= 0:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: B/H/T must be positive."
        )
    if (is_varlen and head_dim != 128) or (
        not is_varlen and head_dim not in {64, 128, 256}
    ):
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: varlen supports K=128; "
            "dense supports K=64, 128 or 256."
        )
    if is_varlen and layout == "BSND" and batch != 1:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: varlen BSND compatibility requires B=1."
        )
    for name in ("k", "gk", "dq", "dk", "dg"):
        if _shape(tensors[name]) != q_shape:
            raise RuntimeError(
                f"npu_chunk_kda_bwd_intra: {name} must have the same shape as q."
            )
    if _shape(beta) != scalar_shape or _shape(db) != scalar_shape:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: beta/db shape must match the selected layout."
        )
    if _shape(dAqk) != matrix_shape or _shape(dAkk) != matrix_shape:
        raise RuntimeError(
            "npu_chunk_kda_bwd_intra: dAqk/dAkk shape must match the selected layout."
        )

    cu_seqlens_arg = None
    chunk_indices_arg = None
    if is_varlen:
        cu_seqlens_arg = tuple(int(value) for value in cu_seqlens)
        if not 2 <= len(cu_seqlens_arg) <= 65:
            raise RuntimeError(
                "npu_chunk_kda_bwd_intra: cu_seqlens must contain 2..65 entries."
            )
        if cu_seqlens_arg[0] != 0 or cu_seqlens_arg[-1] != seqlen:
            raise RuntimeError(
                "npu_chunk_kda_bwd_intra: cu_seqlens must start at 0 and end at T."
            )
        canonical_chunks = []
        for seq, (begin, end) in enumerate(
            zip(cu_seqlens_arg[:-1], cu_seqlens_arg[1:])
        ):
            if begin < 0 or end < begin:
                raise RuntimeError(
                    "npu_chunk_kda_bwd_intra: cu_seqlens must be nondecreasing."
                )
            for local_chunk in range((end - begin + chunk_size - 1) // chunk_size):
                canonical_chunks.extend((seq, local_chunk))
        if not canonical_chunks:
            raise RuntimeError(
                "npu_chunk_kda_bwd_intra: varlen input has no non-empty sequence."
            )
        if chunk_indices is not None:
            chunk_indices_arg = tuple(int(value) for value in chunk_indices)
            if chunk_indices_arg != tuple(canonical_chunks):
                raise RuntimeError(
                    "npu_chunk_kda_bwd_intra: chunk_indices must use canonical "
                    "sequence-major order."
                )

    dq_out = _empty_like(dq)
    dk_out = _empty_like(dk)
    db_out = _empty_like(db)
    dg_out = _empty_like(dg)
    outputs = (dq_out, dk_out, db_out, dg_out)
    layout_buffer = ctypes.create_string_buffer(layout.encode("utf-8"))

    # The custom op consumes dense BSND/BNSD as an ND tensor. Standard contiguous
    # rank-4 NPU tensors can carry an NCHW tag despite row-major storage, so
    # override descriptor metadata without a format conversion or data copy.
    def nd_tensor(ctx, tensor, name):
        return ctx.tensor(
            tensor,
            name,
            acl_format_override=ACL_FORMAT_ND,
            storage_shape_override=_shape(tensor),
        )

    input_tensors = (
        q, k, gk, beta, dAqk, dAkk, dq, dk, db, dg
    )
    input_names = (
        "q", "k", "gk", "beta", "dAqk",
        "dAkk", "dq", "dk", "db", "dg",
    )
    output_names = ("dq_out", "dk_out", "db_out", "dg_out")

    def launch(call_inputs, call_outputs):
        def build_args(ctx):
            return [
                *(
                    nd_tensor(ctx, tensor, name)
                    for tensor, name in zip(call_inputs, input_names)
                ),
                ctx.int_array(cu_seqlens_arg),
                ctx.int_array(chunk_indices_arg),
                ctypes.c_int64(chunk_size),
                ctypes.c_bool(True),
                ctypes.cast(layout_buffer, ctypes.c_char_p),
                *(
                    nd_tensor(ctx, tensor, name)
                    for tensor, name in zip(call_outputs, output_names)
                ),
            ]

        return _call_aclnn(
            "aclnnChunkKdaBwdIntra",
            build_args,
            call_outputs,
        )

    if not is_varlen and layout == "BSND" and batch == 1:
        segment_tokens = _chunk_kda_bwd_intra_bsnd_segment_tokens(
            input_tensors,
            seqlen,
            chunk_size,
        )
        if segment_tokens < seqlen:
            # Intra-chunk math has no dependency across chunk boundaries. B=1
            # makes every token slice physically contiguous; each launch writes
            # directly into disjoint views of the final full-size outputs.
            for begin in range(0, seqlen, segment_tokens):
                length = min(segment_tokens, seqlen - begin)
                segment_inputs = tuple(
                    tensor.narrow(1, begin, length) for tensor in input_tensors
                )
                segment_outputs = tuple(
                    tensor.narrow(1, begin, length) for tensor in outputs
                )
                launch(segment_inputs, segment_outputs)
            return outputs

    return launch(input_tensors, outputs)


def npu_chunk_kda_bwd_recompute(
    q,
    k,
    v,
    g,
    beta,
    a,
    chunk_size,
    *,
    A_log=None,
    dt_bias=None,
    cu_seqlens=None,
    chunk_indices=None,
    use_gate_in_kernel=True,
    use_exp2=True,
    lower_bound=-5.0,
):
    import torch

    if chunk_size != 64:
        raise RuntimeError("npu_chunk_kda_bwd_recompute: chunk_size must be 64.")
    if q.dtype != torch.bfloat16 or k.dtype != torch.bfloat16 or v.dtype != torch.bfloat16:
        raise RuntimeError("npu_chunk_kda_bwd_recompute: q/k/v must be bfloat16.")
    if a.dtype != torch.bfloat16:
        raise RuntimeError("npu_chunk_kda_bwd_recompute: A must be bfloat16.")
    if g.dtype not in (torch.bfloat16, torch.float32):
        raise RuntimeError("npu_chunk_kda_bwd_recompute: g must be bfloat16 or float32.")
    if beta.dtype not in (torch.bfloat16, torch.float32):
        raise RuntimeError("npu_chunk_kda_bwd_recompute: beta must be bfloat16 or float32.")
    if len(q.shape) != 4 or len(k.shape) != 4 or len(v.shape) != 4 or len(g.shape) != 4:
        raise RuntimeError("npu_chunk_kda_bwd_recompute: expects dense BNSD rank-4 tensors.")
    if q.shape[-1] != 128 or k.shape[-1] != 128 or v.shape[-1] != 128 or g.shape[-1] != 128:
        raise RuntimeError("npu_chunk_kda_bwd_recompute: K/V must be 128.")
    if use_gate_in_kernel and A_log is None:
        raise RuntimeError("npu_chunk_kda_bwd_recompute: A_log is required when use_gate_in_kernel=True.")

    hv = g.shape[1]
    gk = _empty((g.shape[0], hv, g.shape[2], 128), g, dtype=torch.float32) if use_gate_in_kernel else None
    w = _empty((v.shape[0], hv, v.shape[2], 128), v, dtype=torch.bfloat16)
    u = _empty((v.shape[0], hv, v.shape[2], 128), v, dtype=torch.bfloat16)
    qg = _empty((g.shape[0], hv, g.shape[2], 128), g, dtype=torch.bfloat16)
    kg = _empty((g.shape[0], hv, g.shape[2], 128), g, dtype=torch.bfloat16)

    def build_args(ctx):
        return [
            ctx.tensor(q, "q"),
            ctx.tensor(k, "k"),
            ctx.tensor(v, "v"),
            ctx.tensor(g, "g"),
            ctx.tensor(beta, "beta"),
            ctx.tensor(a, "a"),
            ctx.tensor(A_log, "A_log"),
            ctx.tensor(dt_bias, "dt_bias"),
            ctx.int_array(None if cu_seqlens is None else tuple(int(x) for x in cu_seqlens)),
            ctx.int_array(None if chunk_indices is None else tuple(int(x) for x in chunk_indices)),
            ctypes.c_int64(int(chunk_size)),
            ctypes.c_bool(bool(use_exp2)),
            ctypes.c_double(float(lower_bound)),
            ctx.tensor(w, "w"),
            ctx.tensor(u, "u"),
            ctx.tensor(qg, "qg"),
            ctx.tensor(kg, "kg"),
            ctx.tensor(gk, "gk") if gk is not None else ctypes.c_void_p(0),
        ]

    _call_aclnn("aclnnChunkKdaBwdRecompute", build_args, (w, u, qg, kg, gk))
    return gk, w, u, qg, kg


def npu_solve_tri(x, *, cu_seqlens=None, chunk_indices=None, layout="bsnd"):
    layout = str(layout)
    if layout == "tnd":
        # Measured on Ascend910B3 with the OPP in this tree: the tnd spelling
        # kills the process inside aclnnSolveTri, with and without cu_seqlens.
        # Crashing has no defined semantics to be compatible with, so this one
        # is refused with a message instead -- see
        # docs/architecture/适配层设计.md.
        #
        # `ntd` crashes the same way (re-measured: five of six shapes segfault,
        # the sixth is rejected 161001 -- see the inventory's known limits), and
        # it is deliberately *not* intercepted here: the reference does not
        # either, and whether to refuse it is the operator owner's call.
        raise RuntimeError(
            "npu_solve_tri: layout='tnd' is refused because the operator "
            "crashes the process for that spelling on this OPP (verified on "
            "both the ctypes and the Stable-ABI path). Use layout='bsnd' or "
            "'bnsd'.")
    x_contig = x.contiguous()
    out = _empty_like(x_contig)
    layout_arg = ctypes.c_char_p(str(layout).encode("utf-8"))
    return _call_aclnn(
        "aclnnSolveTri",
        lambda ctx: [
            ctx.tensor(x_contig, "x"),
            ctx.int_array(cu_seqlens),
            ctx.int_array(chunk_indices),
            layout_arg,
            ctx.tensor(out, "out"),
        ],
        out,
    )


ASCENDC_CTYPES_OPS = {
    name: value
    for name, value in globals().items()
    if name.startswith("npu_") and callable(value)
}
