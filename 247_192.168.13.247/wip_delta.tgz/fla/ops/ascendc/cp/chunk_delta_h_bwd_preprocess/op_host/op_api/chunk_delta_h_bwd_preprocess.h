/**
 * Copyright (c) 2026 Tianjin University, Ltd.
 * This program is free software, you can redistribute it and/or modify it under the terms and conditions of
 * the BSD 3-Clause License (the "License").
 * Please refer to the License for details. You may not use this file except in compliance with the License.
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND, EITHER EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT, MERCHANTABILITY, OR FITNESS FOR A PARTICULAR PURPOSE.
 */
#ifndef OP_API_INC_LEVEL0_OP_CHUNK_DELTA_H_BWD_PREPROCESS_H
#define OP_API_INC_LEVEL0_OP_CHUNK_DELTA_H_BWD_PREPROCESS_H

#include "opdev/op_executor.h"

namespace l0op {
const aclTensor *ChunkDeltaHBwdPreprocess(
    const aclTensor *q,
    const aclTensor *k,
    const aclTensor *w,
    const aclTensor *dO,
    const aclTensor *dv,
    const aclTensor *gOptional,
    const aclTensor *gkOptional,
    const aclIntArray *cuSeqlensOptional,
    double scale,
    int64_t chunkSize,
    const aclTensor *dhmOut,
    aclOpExecutor *executor);
}

#endif // OP_API_INC_LEVEL0_OP_CHUNK_DELTA_H_BWD_PREPROCESS_H
