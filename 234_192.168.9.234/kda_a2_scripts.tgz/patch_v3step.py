"""A4′ 诊断第四步：在 StageV3 里分步 dump tile（清零后 / +(−N) 后 / +I₈ 后）。

基：vec_aug2.h + patch_tileoff；插入体为 v3step_body.txt（放在 tile DataCopy 之后）。

用法: python patch_v3step.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "v3step_body.txt").read_text(encoding="utf-8")
ANCHOR = ("            AscendC::DataCopy(\n"
          "                augRelay[Workspace::kAugTileInRelay / sizeof(float)],\n"
          "                augTile, 1024);\n")


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if BODY in text:
        raise SystemExit("[patch_v3step] already patched")
    if text.count(ANCHOR) != 1:
        raise SystemExit(f"[patch_v3step] anchor count={text.count(ANCHOR)}")
    write_lf(path, text.replace(ANCHOR, ANCHOR + BODY, 1))
    print("[patch_v3step] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
