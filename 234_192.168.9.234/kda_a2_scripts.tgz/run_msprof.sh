#!/bin/bash
# 在 kda_a2 容器里对某个用例采集 msprof op（整核画像 + 分 pipe busy）。
#   CID=63 TAG=e1_63 bash run_msprof.sh
set +u
MY=${MY:-/home/admin123/kda_a2}
CID=${CID:?CID=<case id>}
TAG=${TAG:-e1_$CID}
DEV=${DEV:-7}
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
JSON=$MY/repo/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=$DEV
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
source "$MY/python-a2c/fla_npu/opp/vendors/fla_npu_transformer/bin/set_env.bash" 2>/dev/null

OUT=$MY/out/$TAG
rm -rf "$OUT"; mkdir -p "$OUT"
echo "[msprof] case=$CID dev=$DEV out=$OUT"
msprof op --application="$PY $MY/kda_a2_bench.py $JSON $CID 0 1" \
    --output="$OUT" --kernel-name=ChunkKdaFwdPrepare \
    --launch-count=1 --warm-up=1 --aic-metrics=Default > "$OUT/msprof.log" 2>&1
echo "rc=$?"
CSV=$(find "$OUT" -name OpBasicInfo.csv 2>/dev/null | head -1)
echo "--- OpBasicInfo.csv ---"; [ -n "$CSV" ] && cat "$CSV" || tail -12 "$OUT/msprof.log"
for f in $(find "$OUT" -name "*PipeUtilization*.csv" -o -name "*AivPipe*.csv" -o -name "*AicPipe*.csv" 2>/dev/null | head -3); do
  echo "--- $(basename "$f") ---"; head -4 "$f"
done
