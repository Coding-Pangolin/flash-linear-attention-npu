"""从 ATK perf 用例里复制 case 63，翻掉若干属性开关，生成"纯计时"消融用例。

属性开关是算子已有的运行时入口（tiling 里决定 V0 走哪个分支），因此不需要重编：
  * use_qk_l2norm_in_kernel=False  → V0 跳过 Q/K 的逐行 L2 norm
  * use_gate_in_kernel=False       → V0 跳过 gate 的 softplus/exp 链（g 直接当已算好的门）
  * use_beta_sigmoid_in_kernel=False → 跳过 beta 的 sigmoid
  * safe_gate=False                → gate 走另一条（非 safe）分支
  * use_exp2=False                 → gate/exp 走 e 底而不是 2 底

注意：这些用例只用于**计时**（数值语义不再成立），不要拿去跑精度。

用法: python make_ablate_json.py <in.json> <out.json> <src_id>
"""

import json
import sys

SRC = int(sys.argv[3]) if len(sys.argv) > 3 else 63
VARIANTS = [
    (1, {"use_qk_l2norm_in_kernel": False}),
    (2, {"use_gate_in_kernel": False}),
    (3, {"use_beta_sigmoid_in_kernel": False}),
    (4, {"safe_gate": False}),
    (5, {"use_exp2": False}),
    (6, {"allow_neg_eigval": False}),
]

cases = json.load(open(sys.argv[1], encoding="utf-8"))
src = next(c for c in cases if c["id"] == SRC)
out = []
for suffix, flips in VARIANTS:
    import copy

    case = copy.deepcopy(src)
    case["id"] = SRC * 1000 + suffix
    case["name"] = f"{src['name']}_ablate_{'_'.join(flips)}"
    for raw in case["inputs"]:
        it = raw[0] if isinstance(raw, list) else raw
        if it.get("name") in flips:
            it["range_values"] = flips[it["name"]]
    out.append(case)

json.dump(out, open(sys.argv[2], "w", encoding="utf-8"), ensure_ascii=False, indent=1)
print(f"wrote {len(out)} cases -> {sys.argv[2]}")
