"""A4' 探针：按变体装配（cube 侧是否求逆 / AIV 侧 tile 怎么搬）。

用法: python3 patch_probe4x.py <cube.h> <vec.h> <variant>
  c: AIV 4 个 tile（2 批，共享区 8 KiB）+ cube 空转   -> 量 AIV 侧代价
  d: AIV 4 个 tile（2 批）          + cube 4 次求逆   -> 量总代价
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
CUBE_START = "    // A4′：16×16 块级增广求逆（4 次平方）"
CUBE_END = "    __aicore__ inline void StageC4(const ChunkRange &chunk,"
VEC_START = "        // A4′ 数据契约：为 L00 的"
VEC_END = "    __aicore__ inline void StageV6(const ChunkRange &chunk,"
VEC_SENT_ANCHOR = (
    "        AscendC::DataCopy(vBetaRelay, vBeta, rhsRows * Shape::kValueDim);\n")
INIT_OLD = "        pipe_->InitBuffer(l1Buf_, L1::kPeak + 0x2000);"
INIT_NEW = "        pipe_->InitBuffer(l1Buf_, L1::kPeak + 0x8000);"
VARIANT = {
    "c": "probe4x_cubenone.txt",
    "d": "probe4_cube.txt",
}


def main() -> int:
    cube, vec, tag = sys.argv[1], sys.argv[2], sys.argv[3]
    ctext = pathlib.Path(cube).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    for text, needle, where in ((ctext, CUBE_START, "cube"), (ctext, CUBE_END, "cube"),
                                (ctext, INIT_OLD, "cube"),
                                (vtext, VEC_START, "vec"), (vtext, VEC_END, "vec"),
                                (vtext, VEC_SENT_ANCHOR, "vec")):
        if text.count(needle) != 1:
            raise SystemExit(f"[patch_probe4x] {where} anchor x{text.count(needle)}")
    cube_new = (HERE / VARIANT[tag]).read_text(encoding="utf-8")
    vec_new = (HERE / "probe4x_tiles2.txt").read_text(encoding="utf-8")
    sent = (HERE / "probe4_sent.txt").read_text(encoding="utf-8")
    c0, c1 = ctext.index(CUBE_START), ctext.index(CUBE_END)
    ctext = ctext[:c0] + cube_new + ctext[c1:]
    ctext = ctext.replace(INIT_OLD, INIT_NEW, 1)
    v0, v1 = vtext.index(VEC_START), vtext.index(VEC_END)
    vtext = vtext[:v0] + vec_new + vtext[v1:]
    vtext = vtext.replace(VEC_SENT_ANCHOR, VEC_SENT_ANCHOR + sent, 1)
    pathlib.Path(cube).write_text(ctext, encoding="utf-8", newline="\n")
    pathlib.Path(vec).write_text(vtext, encoding="utf-8", newline="\n")
    print(f"[patch_probe4x] applied variant={tag}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
