"""A4 算法预验证（纯 CPU，不需要设备）：分块幂级数求逆 vs 直接代入（标杆口径）。

标杆 `executor_chunk_kda_fwd_prepare.py::_block_inverse` 的做法：
    X0 = (I + L00)^-1, X1 = (I + L11)^-1, X10 = -X1 @ (L10 @ X0)
后再把结果 round 到 BF16。

本脚本验证"用 8x8 分块 + 幂级数"能否复现同一结果：
    L = D + E （D = 8x8 块对角, E = 严格块下三角）
    (I+L)^-1 = (I - K + K^2 - K^3) @ (I+D)^-1 ,  K = (I+D)^-1 E   （K^4 = 0）
并对 64x64（M>32）情形连同跨叶修正一起验证。
"""

from __future__ import annotations

import numpy as np

BLK = 8


def forward_inverse(a: np.ndarray) -> np.ndarray:
    """单位下三角 a（float32）的逆，按行直接代入（与标杆同口径）。"""
    n = a.shape[0]
    x = np.eye(n, dtype=np.float32)
    for i in range(1, n):
        x[i, :i] = -a[i, :i] @ x[:i, :i]
    return x


def block_neumann(l: np.ndarray) -> np.ndarray:
    """8x8 分块 + 幂级数（K^4 = 0）求 (I+L)^-1。"""
    n = l.shape[0]
    d = np.zeros_like(l)
    for b in range(0, n, BLK):
        d[b:b + BLK, b:b + BLK] = l[b:b + BLK, b:b + BLK]
    e = l - d
    eye = np.eye(n, dtype=np.float32)
    dinv = np.zeros_like(l)
    for b in range(0, n, BLK):
        sl = slice(b, b + BLK)
        dinv[sl, sl] = forward_inverse(eye[sl, sl] + d[sl, sl])
    k = dinv @ e
    k2 = k @ k
    k3 = k2 @ k
    return (eye - k + k2 - k3) @ dinv


def inv8_series(n: np.ndarray) -> np.ndarray:
    """8x8 单位下三角逆：Neumann 级数 (I+N)^-1 = I - N + N^2 - ... （N^8 = 0）。
    对应 cube 上 7 次（可 padding 到 16x16 的）MMAD。"""
    eye = np.eye(n.shape[0], dtype=np.float32)
    acc = eye.copy()
    term = eye.copy()
    neg = (-n).astype(np.float32)
    for _ in range(7):          # 累到 N^7
        term = term @ neg
        acc = acc + term
    return acc


def inv16_two_level(m: np.ndarray) -> np.ndarray:
    """16x16 单位下三角逆：8x8 两级（cube 原生 16x16 适配）。"""
    a = inv8_series(m[:8, :8])
    b = inv8_series(m[8:, 8:])
    c = m[8:, :8]
    out = np.zeros_like(m)
    out[:8, :8] = a
    out[8:, 8:] = b
    out[8:, :8] = -(b @ (c @ a))     # 与标杆同序：-B^-1 (C A^-1)
    return out


def strict_lower(rows: int, rng) -> np.ndarray:
    t = rng.standard_normal((rows, rows)).astype(np.float32) * 0.05
    return np.tril(t, -1).astype(np.float32)


def report(name: str, ref: np.ndarray, got: np.ndarray) -> bool:
    diff = np.abs(ref - got)
    rel = diff.max() / max(1e-12, np.abs(ref).max())
    ref16 = ref.astype(np.float16) if ref.dtype == np.float64 else ref
    same_bf16 = np.array_equal(
        np.round(ref.astype(np.float64), 0).astype(np.float32) if False else
        ref.astype(np.float32), got.astype(np.float32))
    print(f"{name}: max|Δ|={diff.max():.3e}  rel={rel:.3e}  |X|max={np.abs(ref).max():.4g}")
    return rel < 1e-5


def main() -> int:
    rng = np.random.default_rng(20261008)
    ok = True
    for rows in (8, 16, 32):
        l = strict_lower(rows, rng)
        ref = forward_inverse(np.eye(rows, dtype=np.float32) + l)
        got = block_neumann(l)
        ok &= report(f"single leaf rows={rows}", ref, got)
    # 64x64：两个 32 叶 + 跨叶修正
    l = strict_lower(64, rng)
    x0 = forward_inverse(np.eye(32, dtype=np.float32) + l[:32, :32])
    x1 = forward_inverse(np.eye(32, dtype=np.float32) + l[32:, 32:])
    x10 = -x1 @ (l[32:, :32] @ x0)
    ref = np.zeros((64, 64), dtype=np.float32)
    ref[:32, :32] = x0
    ref[32:, 32:] = x1
    ref[32:, :32] = x10
    got = block_neumann(l)
    ok &= report("64x64 (two leaves + cross)", ref, got)

    # 精化变体：两个叶子用分块幂级数，跨叶块保持标杆的 -X1 @ (L10 @ X0)
    x0n = block_neumann(l[:32, :32])
    x1n = block_neumann(l[32:, 32:])
    x10n = -x1n @ (l[32:, :32] @ x0n)
    got2 = np.zeros((64, 64), dtype=np.float32)
    got2[:32, :32] = x0n
    got2[32:, 32:] = x1n
    got2[32:, :32] = x10n
    ok2 = report("64x64 refined (neumann leaves + 标杆 cross)", ref, got2)
    print("REFINED RESULT:", "PASS" if ok2 else "FAIL")
    ok = ok2
    # 多随机种子：精化变体 vs 标杆，看 fp32 误差与 bf16 rounding 后的一致性
    def to_bf16_bits(a):
        return (a.astype(np.float32).view(np.uint32) & np.uint32(0xFFFF0000))

    worst = 0.0
    identical = 0
    trials = 30
    for t in range(trials):
        r2 = np.random.default_rng(1000 + t)
        lt = strict_lower(64, r2)
        a0 = forward_inverse(np.eye(32, dtype=np.float32) + lt[:32, :32])
        a1 = forward_inverse(np.eye(32, dtype=np.float32) + lt[32:, 32:])
        refr = np.zeros((64, 64), dtype=np.float32)
        refr[:32, :32] = a0
        refr[32:, 32:] = a1
        refr[32:, :32] = -a1 @ (lt[32:, :32] @ a0)
        g0 = block_neumann(lt[:32, :32])
        g1 = block_neumann(lt[32:, 32:])
        gotr = np.zeros((64, 64), dtype=np.float32)
        gotr[:32, :32] = g0
        gotr[32:, 32:] = g1
        gotr[32:, :32] = -g1 @ (lt[32:, :32] @ g0)
        worst = max(worst, float(np.abs(refr - gotr).max()))
        identical += int(np.array_equal(to_bf16_bits(refr), to_bf16_bits(gotr)))
    print(f"refined over {trials} random cases: worst max|Δ|={worst:.3e}, "
          f"bf16-rounded bit-identical {identical}/{trials}")
    ok &= identical == trials or worst < 1e-6

    # 推荐的 cube 口径：32x32 逆 = 两个 16x16 逆（8x8 级数 + 两级）+ 跨块同序
    worst16 = 0.0
    ident16 = 0
    for t in range(trials):
        r3 = np.random.default_rng(2000 + t)
        lt = strict_lower(64, r3)
        a0 = forward_inverse(np.eye(32, dtype=np.float32) + lt[:32, :32])
        a1 = forward_inverse(np.eye(32, dtype=np.float32) + lt[32:, 32:])
        refr = np.zeros((64, 64), dtype=np.float32)
        refr[:32, :32] = a0
        refr[32:, 32:] = a1
        refr[32:, :32] = -a1 @ (lt[32:, :32] @ a0)
        g0 = inv16_two_level(lt[:32, :32])
        g1 = inv16_two_level(lt[32:, 32:])
        gotr = np.zeros((64, 64), dtype=np.float32)
        gotr[:32, :32] = g0
        gotr[32:, 32:] = g1
        gotr[32:, :32] = -g1 @ (lt[32:, :32] @ g0)
        worst16 = max(worst16, float(np.abs(refr - gotr).max()))
        ident16 += int(np.array_equal(to_bf16_bits(refr), to_bf16_bits(gotr)))
    print(f"cube-style (16x16 two-level) over {trials} random cases: "
          f"worst max|Δ|={worst16:.3e}, bf16 bit-identical {ident16}/{trials}")
    ok &= worst16 < 1e-5
    print("RESULT:", "PASS" if ok else "FAIL")
    return 0 if ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
