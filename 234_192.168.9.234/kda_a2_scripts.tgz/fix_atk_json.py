"""把 A5 风格的 ATK 用例 json（standard.acc 为字符串 BM 名）转成本机 ATK2678 认的 schema。

本机已验证的 BM 形如：
  "acc": {"cv_fused_double_benchmark": {"max_re_ratio": 5, "avg_re_ratio": 1.5,
                                        "root_mean_squared_ratio": 1.5}}
用法：python fix_atk_json.py <src.json> <dst.json>
"""

import json
import sys

BM = {
    "cv_fused_double_benchmark": {
        "max_re_ratio": 5,
        "avg_re_ratio": 1.5,
        "root_mean_squared_ratio": 1.5,
    }
}


def main() -> int:
    src, dst = sys.argv[1], sys.argv[2]
    with open(src, encoding="utf-8") as fh:
        cases = json.load(fh)
    patched = 0
    for case in cases:
        std = case.get("standard")
        if isinstance(std, dict) and not isinstance(std.get("acc"), dict):
            std["acc"] = BM
            patched += 1
    with open(dst, "w", encoding="utf-8") as fh:
        json.dump(cases, fh, ensure_ascii=False, indent=1)
    print(f"[fix] {src} -> {dst}  patched={patched}/{len(cases)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
