"""对比：我们算子的 ATK 标杆（executor 的 FP64 reference）vs fla v0.5.2 的 KDA prepare 数学。

用法: python3 cmp_atk_vs_fla.py <case_json> <cid> <cache.pt> [<cache.pt> ...]

对标来源（fla v0.5.2）：
  gate 激活 + chunk 内 cumsum   fla/ops/kda/gate.py  (kda_gate_fwd_kernel / kda_gate_chunk_cumsum, scale=RCP_LN2)
  打分 / mask                   fla/ops/kda/chunk_intra.py (chunk_kda_fwd_kernel_intra_sub_chunk)
  逆矩阵                        fla/ops/kda/chunk_intra.py (16 行前代 + inter_solve_fused)
  w,u,qg,kg                     fla/ops/kda/wy_fast.py (recompute_w_u_fwd_kda_kernel)

差异只允许来自三处（本脚本会分别量化）：① 求逆分块/舍入路径；② 尾块参考行取法；
③ ATK 的指数 clamp（fla 没有）。
"""

from __future__ import annotations

import importlib.util
import json
import math
import sys

import torch

EXEC = ("/home/admin123/kda_a2/repo/tests/atk/chunk_kda_fwd_prepare/"
        "executor_chunk_kda_fwd_prepare.py")
CHUNK, SUB = 64, 16
RCP_LN2 = 1.0 / math.log(2.0)


def load_exec():
    spec = importlib.util.spec_from_file_location("kda_exec", EXEC)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["kda_exec"] = mod
    spec.loader.exec_module(mod)
    return mod


def bf16(x: torch.Tensor) -> torch.Tensor:
    return x.to(torch.bfloat16).to(torch.float64)


def fla_reference(ex, spec, inp):
    """按 fla v0.5.2 的口径重算 13 个输出里的关键几项（fp64，bf16 落点与 fla 一致）。"""
    layout = str(spec["layout"])
    q = ex._layout_to_bsnd(inp.q, layout).to(torch.float64)
    k = ex._layout_to_bsnd(inp.k, layout).to(torch.float64)
    v = ex._layout_to_bsnd(inp.v, layout).to(torch.float64)
    B, T, H, K = q.shape
    HV = v.shape[2]
    group = HV // H
    out = {}
    use_exp2 = bool(spec["use_exp2"])
    # 存储域 → 因子：fla 恒为 exp2（log2 域）；我们这个算子支持 exp 的自然对数域
    def EXP(x):
        return torch.exp2(x) if use_exp2 else torch.exp(x)

    # ---- q/k L2norm（fla 在 layer 层用 l2norm_fwd 做，再按 bf16 落一次） ----
    if spec["use_qk_l2norm_in_kernel"]:
        eps = float(spec["epsilon"])
        q = bf16(q * torch.rsqrt(q.square().sum(-1, keepdim=True) + eps))
        k = bf16(k * torch.rsqrt(k.square().sum(-1, keepdim=True) + eps))

    # ---- Stage 0: gate + chunk 内 cumsum（fla: scale=RCP_LN2 ⇒ log2 域） ----
    g_raw = ex._layout_to_bsnd(inp.g, layout).to(torch.float64)
    if spec["use_gate_in_kernel"]:
        a_log = inp.a_log.to(torch.float64).view(1, 1, HV, 1)
        x = g_raw + (inp.dt_bias.to(torch.float64).view(1, 1, HV, K)
                     if inp.dt_bias is not None else 0.0)
        if spec["safe_gate"]:
            step = float(spec["lower_bound"]) * torch.sigmoid(
                torch.exp(a_log) * x)
        else:
            step = -torch.exp(a_log) * torch.nn.functional.softplus(x)
    else:
        step = g_raw
    g = torch.zeros_like(step)
    if inp.cu_seqlens is None:
        spans = [(b, s, min(s + CHUNK, T))
                 for b in range(B) for s in range(0, T, CHUNK)]
    else:
        cu = list(inp.cu_seqlens)
        spans = [(0, s, min(s + CHUNK, e))
                 for sb, e in zip(cu, cu[1:]) for s in range(sb, e, CHUNK)]
    for b, s, e in spans:
        g[b, s:e] = torch.cumsum(step[b, s:e], dim=0) * (
            RCP_LN2 if use_exp2 else 1.0)
    out["gk"] = g.permute(0, 2, 1, 3).contiguous()      # [B, HV, T, D]，与标杆一致

    # beta
    beta = ex._layout_to_bsnd(inp.beta, layout, scalar=True).to(torch.float64)
    if spec["use_beta_sigmoid_in_kernel"]:
        beta = torch.sigmoid(beta)
        if spec["allow_neg_eigval"]:
            beta = beta * 2.0

    # 与标杆同 layout：[B, HV, T, *]
    Aqk = torch.zeros(B, HV, T, CHUNK, dtype=torch.float64)
    Akk = torch.zeros(B, HV, T, CHUNK, dtype=torch.float64)
    w = torch.zeros(B, HV, T, K, dtype=torch.float64)
    u = torch.zeros(B, HV, T, v.shape[-1], dtype=torch.float64)
    qg = torch.zeros(B, HV, T, K, dtype=torch.float64)
    kg = torch.zeros(B, HV, T, K, dtype=torch.float64)
    qg_scaled = torch.zeros_like(qg)
    sat = 0
    tot = 0
    sat_pre = 0
    tot_pre = 0

    for b, s, e in spans:
        rows = e - s
        if rows <= 0:
            continue
        for hv in range(HV):
            hk = hv // group
            for i0 in range(0, rows, SUB):
                i1 = min(i0 + SUB, rows)
                qs = q[b, s + i0:s + i1, hk]
                ks = k[b, s + i0:s + i1, hk]
                gs = g[b, s + i0:s + i1, hv]
                # fla 的参考行：min(BC//2, 块内剩余-1)
                ref = i0 + min(SUB // 2, rows - i0 - 1)
                gr = g[b, s + ref, hv]
                # fla 不做 clamp（注释只说"小于 85 以免 exp2 溢出"）
                gm = gs - gr
                sat += int((gm.abs() > 126).sum())
                tot += gm.numel()
                fq = EXP(gm)
                fk = EXP(-gm)
                prefix = g[b, s:s + i1, hv]
                kp = k[b, s:s + i1, hk]
                # 前缀行的右因子用同一个参考行
                fkp = EXP(gr - prefix)
                sat_pre += int(((gr - prefix).abs() > 126).sum())
                tot_pre += (gr - prefix).numel()
                b_Aqk = (qs * fq) @ (kp * fkp).T * float(spec["scale"])
                b_Akk = (ks * fq) @ (kp * fkp).T * beta[b, s + i0:s + i1, hv][:, None]
                # 列是 chunk 内相对列（0..i1），行是该子带的 chunk 内行 i0+local
                col = torch.arange(i1)
                row = i0 + torch.arange(i1 - i0)
                mask_q = col[None, :] <= row[:, None]
                mask_k = col[None, :] < row[:, None]
                Aqk[b, hv, s + i0:s + i1, :i1] = torch.where(
                    mask_q, b_Aqk, torch.zeros_like(b_Aqk))
                Akk[b, hv, s + i0:s + i1, :i1] = torch.where(
                    mask_k, b_Akk, torch.zeros_like(b_Akk))

            # 逆矩阵：同一数学 (I+L)^{-1}（fla 用 16 行前代 + inter-solve，这里直接三角求解）
            L = Akk[b, hv, s:e, :rows]
            eye = torch.eye(rows, dtype=torch.float64)
            inv = torch.linalg.solve_triangular(L + eye, eye, upper=False)
            Akk[b, hv, s:e, :rows] = inv

            # ---- Stage 6/7: qg / kg / k_beta_g / v_beta / w / u（fla: wy_fast） ----
            gg = g[b, s:e, hv]
            qs = q[b, s:e, hk]
            ks = k[b, s:e, hk]
            vs = v[b, s:e, hv]
            bb = beta[b, s:e, hv]
            qg_b = qs * EXP(gg)
            glast = g[b, e - 1, hv]
            kg_b = ks * EXP(glast[None, :] - gg)
            k_beta = (ks * bb[:, None]) * EXP(gg)
            v_beta = vs * bb[:, None]
            qg[b, hv, s:e] = bf16(qg_b)
            qg_scaled[b, hv, s:e] = bf16(bf16(qg_b) * float(spec["scale"]))
            kg[b, hv, s:e] = bf16(kg_b)
            A_b = bf16(Akk[b, hv, s:e, :rows])
            w[b, hv, s:e] = bf16(A_b @ bf16(k_beta).to(torch.float64))
            u[b, hv, s:e] = bf16(A_b @ bf16(v_beta).to(torch.float64))

    out.update(aqk=bf16(Aqk), akk=bf16(Akk), w=w, u=u, qg=qg, kg=kg,
               qg_scaled=qg_scaled)
    return out, (sat, tot, sat_pre, tot_pre)


def main() -> int:
    case_json, cid = sys.argv[1], int(sys.argv[2])
    ex = load_exec()
    case = next(c for c in json.load(open(case_json, encoding="utf-8"))
                if c["id"] == cid)
    for cache in sys.argv[3:]:
        blob = torch.load(cache, map_location="cpu")
        values = dict(blob)
        if values.get("cu_seqlens") is not None and not isinstance(
                values["cu_seqlens"], (list, tuple)):
            t = int(values["q"].shape[-2])
            values["cu_seqlens"] = [0, t // 2, t]
        spec = ex._derive_spec(values, cid)
        spec["backward_mode"] = str(spec.get("backward_mode") or "none")
        inp = ex._direct_inputs(values, high_precision=True)
        golden = ex.run_cpu(spec, inp)
        mine, (sat, tot, sat_pre, tot_pre) = fla_reference(ex, spec, inp)
        print(f"\n==== case {cid} ({case['name']}) cache={cache}")
        print(f"  子带内 |g-G_ref|>126：{sat}/{tot} = {100.0 * sat / max(tot, 1):.2f}%"
              f"；前缀 |G_ref-g|>126：{sat_pre}/{tot_pre} = "
              f"{100.0 * sat_pre / max(tot_pre, 1):.2f}%（ATK 会 clamp、fla 不会）")
        names = {0: "gk", 1: "aqk", 2: "akk", 3: "w", 4: "u", 5: "qg",
                 6: "kg", 7: "qg_scaled"}
        for i, key in names.items():
            got, want = mine.get(key), golden[i]
            if want is None:
                continue
            d = (got - want.to(torch.float64)).abs()
            scale = want.abs().max().item()
            print(f"  out{i:<2}{key:<10} max_abs={d.max().item():.3e}  "
                  f"max|want|={scale:.3e}  相对={d.max().item() / max(scale, 1e-30):.2e}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
