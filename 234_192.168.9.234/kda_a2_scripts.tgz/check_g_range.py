"""看 gk（= 累积 gate G 的公开输出，out 0）的绝对值范围：
用来判定"把 V0 的输出契约从 G 改成 E(G)"是否安全——E(G) 在 |G|>126 时会
下溢/上溢（fp32 指数范围），而差异 (Gref-G) 可能仍在范围内，信息就丢了。

用法: python3 check_g_range.py <case.pt> [更多 case.pt ...]
"""

from __future__ import annotations
import sys

import torch


def main() -> int:
    for path in sys.argv[1:]:
        blob = torch.load(path, map_location="cpu")
        gk = blob["cpu"][0]
        v = gk.float()
        overs = (v.abs() > 126.0).float().mean().item()
        print(f"{path}: shape={tuple(v.shape)} max|G|={v.abs().max().item():.4g} "
              f"min={v.min().item():.4g} 超 126 的比例={overs:.4%}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
