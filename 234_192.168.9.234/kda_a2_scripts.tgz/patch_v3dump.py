"""A4′ 诊断第三步：在 StageV3 里 dump UB tile 与 GM 回读 tile（各前 64 fp32 → w[0:128]）。

基：vec_aug2.h + patch_tileoff（tile 落点 relay+0x4000）。插入体来自 v3dump_body.txt。

用法: python patch_v3dump.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "v3dump_body.txt").read_text(encoding="utf-8")

ANCHOR = ("            AscendC::DataCopy(\n"
          "                augRelay[Workspace::kAugTileInRelay / sizeof(float)],\n"
          "                augTile, 1024);\n")


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if BODY in text:
        raise SystemExit("[patch_v3dump] already patched")
    if text.count(ANCHOR) != 1:
        raise SystemExit(f"[patch_v3dump] anchor count={text.count(ANCHOR)}")
    write_lf(path, text.replace(ANCHOR, ANCHOR + BODY, 1))
    print("[patch_v3dump] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
