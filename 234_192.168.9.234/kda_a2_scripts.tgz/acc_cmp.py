"""比较两个 vendor 跑同一用例的 NPU 出参（baseline vs 改动版）。

用法: python acc_cmp.py <caseN.pt...> -- 每个 .pt 由 acc_ab.py 落盘，
     另存一份带 tag 的文件名：<tag>.caseN.pt。
"""

from __future__ import annotations

import sys

import torch

OUTPUT_NAMES = (
    "hm",
    "w",
    "u",
    "qg",
    "kg",
    "qg_scaled",
    "q_hat",
    "k_hat",
    "q_rstd",
    "k_rstd",
    "beta_eff",
)


def load(path):
    blob = torch.load(path, map_location="cpu")
    return blob["npu"], blob["cpu"]


def main() -> int:
    base_path, new_path = sys.argv[1], sys.argv[2]
    b, _ = load(base_path)
    n, _ = load(new_path)
    print(f"== {base_path.split('/')[-1]}")
    for i, (x, y) in enumerate(zip(b, n)):
        name = OUTPUT_NAMES[i] if i < len(OUTPUT_NAMES) else f"out{i}"
        if x is None or y is None:
            print(f"  {i:2d} {name:10s} None-slot base={x is None} new={y is None}")
            continue
        xf, yf = x.float(), y.float()
        if xf.shape != yf.shape:
            print(f"  {i:2d} {name:10s} SHAPE base={tuple(xf.shape)} "
                  f"new={tuple(yf.shape)}")
            continue
        nan_b = int(torch.isnan(xf).sum())
        nan_n = int(torch.isnan(yf).sum())
        d = (xf - yf).abs()
        d = d[~torch.isnan(d)]
        same = torch.equal(x, y)
        print(f"  {i:2d} {name:10s} {tuple(xf.shape)} bitwise_same={same} "
              f"nan(base/new)={nan_b}/{nan_n} max|Δ|="
              f"{(d.max().item() if d.numel() else 0.0):.3e}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
