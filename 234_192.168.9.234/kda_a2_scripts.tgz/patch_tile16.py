"""A4′：把增广 tile 从"8×8 块级"升级为"16×16 块级"（tilebuild16.txt，无 mask/无块步长）。

基：vec_aug2.h（其 tile 构造是第一版 Sub/mask 写法）。

用法: python patch_tile16.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
NEW = (HERE / "tilebuild16.txt").read_text(encoding="utf-8")

OLD = """            auto augBase =
                ub[Arch22Ub::kSharedScratch].template ReinterpretCast<float>();
            auto augTile = augBase;
            auto augZero = augBase[1024];  // 8 个零：给 Sub 当 src0（repStride=0）
            AscendC::Duplicate(augTile, 0.0F, 1024);
            AscendC::Duplicate(augZero, 0.0F, 8);
            AscendC::PipeBarrier<PIPE_V>();
            // dst = 0 - lkk 的左上 8x8：src0 用独立零块 + repStride=0
            // （不能读 augTile 自己，否则第 0 行写完就被后面几行读到），
            // src1 = lkk（行距 64 元素 = 8 block），每行取 1 block。
            AscendC::Sub(augTile, augZero, lkk, 8, 8, {1, 1, 1, 4, 0, 8});
            AscendC::PipeBarrier<PIPE_V>();
            // 两个 I8：VEC 的 dst 必须 32B 对齐 ⇒ 用"行首对齐基址 + mask 选中
            // 块内 lane"。元素 (i, 8+i) 在 block 1 的 lane i 上，8 行后 block
            // 前进 33（8 行 = 32 block，另加 8 列 = 1 block）。
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[lane * 32], 1.0F, mask, 1, 1, 33);
            }
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[(8 + lane) * 32], 1.0F, mask, 1, 1,
                                   33);
            }
            AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            // 写进 relay 开头 4 KiB（V3 已经消费完 raw score；C4 之后才复用前
            // 4 KiB 放 T，所以顺序上安全）。
            AscendC::GlobalTensor<float> augRelay;
            augRelay.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(
                args_.workspace + slot + Workspace::kArch22CubeRelay),
                Workspace::kArch22RawScoreBytes / sizeof(float));
            AscendC::DataCopy(augRelay, augTile, 1024);
"""


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if text.count(OLD) != 1:
        raise SystemExit(f"[patch_tile16] anchor count={text.count(OLD)}")
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text.replace(OLD, NEW, 1))
    print("[patch_tile16] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
