"""把 arch22 的 V0Vf 逐行 L2 norm 改成块状（A2/A3 stage 重设计的第一个落地项）。

依据（234 实测 2026-10-08）：
  * 分 stage 屏蔽差分：V0+V1 = 60.0% 整算子时长；
  * 属性消融：use_qk_l2norm_in_kernel=False ⇒ 18,949.7 → 10,329.6 µs，
    即 Q/K 的逐行 L2 norm 单项 8,620 µs = 45.5%。

替换方式：用 START/END 标记定位整段逐行 norm（q 与 k 两个 64 行循环），
整段替换成对 L2NormRowsBlock() 的两次调用；helper 从
norm_block_helper.txt 读入并插在 V0Vf 之前。

用法: python patch_norm.py <chunk_kda_fwd_prepare_vec.h> [--revert]
"""

from __future__ import annotations

import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
HELPER = (HERE / "norm_block_helper.txt").read_text(encoding="utf-8")
NEW_BODY = (HERE / "norm_call_body.txt").read_text(encoding="utf-8")


def write_lf(path, text):
    """内核源码必须保持 LF（Windows 上默认会写成 CRLF）。"""
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)

START = "        const uint32_t count = validRows * Shape::kHeadDim;\n" \
        "        if constexpr (CompilePolicy::normMode == QkNormMode::L2) {\n"
END = "        } else {\n" \
      "            // 固定输出合同下 Identity 仍写确定值；反向关闭 L2Norm 时不会\n" \
      "            // 使用 rstd，但不能留下未初始化输出。\n" \
      "            AscendC::Duplicate(qRstd, 1.0F, validRows);\n" \
      "            AscendC::Duplicate(kRstd, 1.0F, validRows);\n" \
      "            AscendC::PipeBarrier<PIPE_V>();\n" \
      "        }\n"

HELPER_ANCHOR = "    __aicore__ inline void V0Vf(\n"


def main() -> int:
    path = sys.argv[1]
    revert = "--revert" in sys.argv[2:]
    backup = pathlib.Path(path + ".orig")
    src = open(path, encoding="utf-8").read()
    if revert:
        if not backup.exists():
            raise SystemExit(f"[patch_norm] no backup at {backup}")
        write_lf(path, backup.read_text(encoding="utf-8"))
        print("[patch_norm] reverted from backup")
        return 0

    if src.count(START) != 1 or src.count(END, src.index(START)) != 1:
        raise SystemExit(f"[patch_norm] anchors not unique: "
                         f"start={src.count(START)} end={src.count(END)}")
    if "L2NormRowsBlock" in src:
        raise SystemExit("[patch_norm] already patched")
    if src.count(HELPER_ANCHOR) != 1:
        raise SystemExit(f"[patch_norm] V0Vf anchor count="
                         f"{src.count(HELPER_ANCHOR)}")
    if not backup.exists():
        write_lf(backup, src)

    begin = src.index(START)
    end = src.index(END, begin) + len(END)
    src = src[:begin] + NEW_BODY + src[end:]
    anchor = src.index(HELPER_ANCHOR)
    src = src[:anchor] + HELPER + src[anchor:]
    write_lf(path, src)
    print("[patch_norm] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
