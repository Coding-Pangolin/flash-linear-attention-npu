#!/bin/bash
# E2 v2：分 Stage 屏蔽差分（A2/910B3）。在**调用点**上屏蔽 stage，保留 Process 里的
# 核间 flag 回合 ⇒ 不挂死。每次：还原 → 打补丁 → 重编 → 装 OPP → 换软链 → 测 case 63。
#
#   CID=63 bash e2_v2.sh            # 全量
#   CID=63 ONLY=B_V3 bash e2_v2.sh  # 只跑一个变体（不重跑基线）
#
# 变体与令牌账（见 chunk_kda_fwd_prepare_{vec,cube}.h）：
#   B_V01   : V0 的 wait(ioFree,sharedFree,mte3ToV) 与 V1 的 set 成对消失
#   B_V3    : V3 自成一对（ioFree/sharedFree）
#   B_V6    : V6 自成一对（ioFree/sharedFree/mte3ToV）
#   B_C2    : C2 内部 mToMte1/fixToM/M_FIX/MTE1_M 全成对
#   B_C45C7 : C4→C5 的 tReady_、C5→C7 的 fixToMte1_ 都是这两者之间的令牌，
#             必须一起屏蔽；C7 的核间 free 许可在调用点补发
#   B_C7    : 只屏蔽 C7，补发核间 free 许可
set +u   # CANN set_env.sh 在 set -u 下会中断
MY=${MY:-/home/admin123/kda_a2}
REPO=$MY/repo
OP=$REPO/fla/ops/ascendc/kda/chunk_kda_fwd_prepare/op_kernel/arch22
VEC=$OP/chunk_kda_fwd_prepare_vec.h
CUBE=$OP/chunk_kda_fwd_prepare_cube.h
PKG=$MY/python-a2c/fla_npu
VLNK=$PKG/opp/vendors/fla_npu_transformer
JSON=$REPO/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
CID=${CID:-63}
CACHE=${CACHE:-$MY/cache/case$CID.pt}

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
BASE_OPP=${ASCEND_CUSTOM_OPP_PATH:-}
mkdir -p "$(dirname "$CACHE")"

cp -n "$VEC" "$VEC.p0"; cp -n "$CUBE" "$CUBE.p0"
if grep -q "E2 blank-out" "$VEC.p0" "$CUBE.p0"; then
  echo "!! .p0 里还有旧版 blank 残留，先清理"; exit 1
fi

point_link() { # $1 tag
  local exp=$PKG/opp_vendors/$1
  [ -d "$exp/vendors/fla_npu_transformer" ] || { echo "  (no pkg $1)"; return 1; }
  rm -rf "$VLNK"; ln -sT "$exp/vendors/fla_npu_transformer" "$VLNK"
  local v=$exp/vendors/fla_npu_transformer
  export ASCEND_CUSTOM_OPP_PATH=${BASE_OPP:+$BASE_OPP:}$v:$v/op_api/lib
}

build_tag() { # $1 tag
  bash $REPO/build.sh --pkg --soc=ascend910b --vendor_name=fla_npu \
      --ops=chunk_kda_fwd_prepare > "$MY/build_$1.log" 2>&1 \
    || { echo "[$1] BUILD FAIL"; tail -15 "$MY/build_$1.log"; return 1; }
  local run exp
  run=$(ls -t $REPO/build_out/*.run | head -1)
  exp=$PKG/opp_vendors/$1
  rm -rf "$exp"; mkdir -p "$exp"
  "$run" --quiet --install-path="$exp" > "$MY/install_$1.log" 2>&1 \
    || { echo "[$1] INSTALL FAIL"; return 1; }
  mkdir -p "$exp/vendors"; echo "load_priority=fla_npu_transformer" > "$exp/vendors/config.ini"
}

measure() { # $1 tag
  local log=$MY/bench_$1.log
  timeout 900 "$PY" "$MY/kda_a2_bench.py" "$JSON" "$CID" 1 3 "$CACHE" \
      > "$log" 2>&1
  local line
  line=$(grep -a "event=" "$log" | tail -1)
  if [ -n "$line" ]; then
    echo "[$1] $line"
  else
    echo "[$1] MEASURE FAIL:"; tail -5 "$log" | sed 's/^/        /'
  fi
}

variant() { # $1 tag  $2 file  $3 mode  $4.. names
  local tag=$1 file=$2 mode=$3; shift 3
  if [ -n "$ONLY" ] && [ "$ONLY" != "$tag" ]; then return 0; fi
  cp -f "$file.p0" "$file"
  "$PY" "$MY/e2_apply.py" "$file" "$mode" "$@" || { echo "[$tag] PATCH FAIL"; return 1; }
  echo "=== $tag ==="
  build_tag "$tag" || return 0
  point_link "$tag" || return 0
  measure "$tag"
}

if [ -z "$ONLY" ]; then
  echo "=== 基线（未屏蔽） ==="
  cp -f "$VEC.p0" "$VEC"; cp -f "$CUBE.p0" "$CUBE"
  build_tag e2v2_base || exit 1
  point_link e2v2_base && measure e2v2_base
fi

variant B_V01   "$VEC"  comment    StageV0 StageV1
variant B_V3    "$VEC"  comment    StageV3
variant B_V6    "$VEC"  comment    StageV6
variant B_C2    "$CUBE" comment    StageC2
variant B_C7    "$CUBE" replace-c7 StageC7
variant B_C45C7 "$CUBE" mixed      StageC4 StageC5 StageC7

echo "=== 恢复源码 ==="
cp -f "$VEC.p0" "$VEC"; cp -f "$CUBE.p0" "$CUBE"
echo done
