"""单段 dump 补丁（§4.18 规矩）：把 one_body.txt 插到 StageV3 的 tile 落盘之后。

用法: python patch_one.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "one_body.txt").read_text(encoding="utf-8")
ANCHOR = ("            AscendC::DataCopy(\n"
          "                augRelay[Workspace::kAugTileInRelay / sizeof(float)],\n"
          "                augTile, 1024);\n")


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "outAqk" in text:
        raise SystemExit("[patch_one] already patched")
    if text.count(ANCHOR) != 1:
        raise SystemExit(f"[patch_one] anchor count={text.count(ANCHOR)}")
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text.replace(ANCHOR, ANCHOR + BODY, 1))
    print("[patch_one] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
