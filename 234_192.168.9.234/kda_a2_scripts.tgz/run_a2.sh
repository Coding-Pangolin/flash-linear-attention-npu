#!/bin/bash
# 192.168.9.234（A2/910B3）上跑 chunk_kda_fwd_prepare 的 ATK 精度/性能。
# 隔离环境：MY 下自带 repo + python-a2c(fla_npu+OPP)，不动别人的 /data/fla_kda 与 wym 容器。
#   DEV=7 bash run_a2.sh acc [start end]
#   DEV=7 bash run_a2.sh perf
set +u
MY=${MY:-/home/admin123/kda_a2}
DEV=${DEV:-7}
# ATK 是 cp310 编译扩展 ⇒ 必须用 py3.10 解释器（宿主的 conda env 只读挂载）
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=$DEV
export ATK2678=/data/fla_kda/atk2678
export PYTHONPATH="$ATK2678:$MY/python-a2c:${PYTHONPATH:-}"
export TORCH_EXTENSIONS_DIR=$MY/torch_ext
mkdir -p "$TORCH_EXTENSIONS_DIR"
source "$MY/python-a2c/fla_npu/opp/vendors/fla_npu_transformer/bin/set_env.bash" 2>/dev/null

ATK_DIR=$MY/repo/tests/atk/chunk_kda_fwd_prepare
OUT=$MY/out/${TAG:-$1}
mkdir -p "$OUT"
echo "[env] dev=$DEV py=$PY python=$($PY -V 2>&1) cann=$ASCEND_TOOLKIT_HOME out=$OUT"

strip() { sed -e 's/\x1b\[[0-9;]*m//g'; }

case "$1" in
acc)
  cd "$ATK_DIR" || exit 1
  $PY -m atk node --name npu_dut --backend npu --devices 0 -o "$OUT" \
      node --name cpu_reference --backend cpu -o "$OUT" \
      task -c atk_chunk_kda_fwd_prepare_a2.json --task accuracy --bm_device cpu \
      -p executor_chunk_kda_fwd_prepare.py -s "${2:-0}" -e "${3:-1}" -sp -mt 1 -to 900 \
      --save_data output > "$OUT/acc.log" 2>&1
  echo "rc=$?"
  strip < "$OUT/acc.log" | grep -aE "acc_pass_result|PASS|FAIL|Traceback|Error" | tail -8
  ;;
perf)
  cd "$ATK_DIR" || exit 1
  $PY -m atk node --name npu_dut --backend npu --devices 0 --output_path "$OUT" \
      task -c atk_chunk_kda_fwd_prepare_perf_a2.json --task performance_device \
      -p executor_chunk_kda_fwd_prepare.py --save_data profile -sp -to 1800 \
      > "$OUT/perf.log" 2>&1
  echo "rc=$?"
  strip < "$OUT/perf.log" | grep -aE "device性能|Total Task|acc_pass_result|性能|Task Duration" | tail -20
  ;;
*)
  echo "usage: DEV=<n> $0 acc [start end] | perf"; exit 2;;
esac
