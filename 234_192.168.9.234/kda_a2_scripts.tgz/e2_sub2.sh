#!/bin/bash
# 顺序跑多个"块级"子 Stage 屏蔽变体（每个变体：还原 → 打补丁 → 重编 → 装包 → 测 case 63）。
#   bash e2_sub2.sh "S_cumsum|<marker>" "S_gate|<marker>" ...
set +u
MY=${MY:-/home/admin123/kda_a2}
REPO=$MY/repo
OP=$REPO/fla/ops/ascendc/kda/chunk_kda_fwd_prepare/op_kernel/arch22
VEC=$OP/chunk_kda_fwd_prepare_vec.h
BASE_SRC=$MY/vec_normblk4.h
PKG=$MY/python-a2c/fla_npu
VLNK=$PKG/opp/vendors/fla_npu_transformer
JSON=$REPO/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
CID=${CID:-63}
CACHE=${CACHE:-$MY/cache/case$CID.pt}

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
BASE_OPP=${ASCEND_CUSTOM_OPP_PATH:-}
mkdir -p "$(dirname "$CACHE")"

for spec in "$@"; do
  tag=${spec%%|*}; marker=${spec#*|}
  echo "=== $tag ==="
  cp -f "$BASE_SRC" "$VEC"
  "$PY" "$MY/e2_sub.py" "$VEC" block "$marker" || { cp -f "$VEC.e2sub" "$VEC"; continue; }
  if ! bash $REPO/build.sh --pkg --soc=ascend910b --vendor_name=fla_npu \
        --ops=chunk_kda_fwd_prepare > "$MY/build_$tag.log" 2>&1; then
    echo "[$tag] BUILD FAIL"; grep -a -m3 "error:" "$MY/build_$tag.log"
    cp -f "$VEC.e2sub" "$VEC"; continue
  fi
  run=$(ls -t $REPO/build_out/*.run | head -1)
  exp=$PKG/opp_vendors/$tag
  rm -rf "$exp"; mkdir -p "$exp"
  "$run" --quiet --install-path="$exp" > "$MY/install_$tag.log" 2>&1 || { echo "[$tag] INSTALL FAIL"; continue; }
  mkdir -p "$exp/vendors"; echo "load_priority=fla_npu_transformer" > "$exp/vendors/config.ini"
  rm -rf "$VLNK"; ln -sT "$exp/vendors/fla_npu_transformer" "$VLNK"
  V=$exp/vendors/fla_npu_transformer
  export ASCEND_CUSTOM_OPP_PATH=${BASE_OPP:+$BASE_OPP:}$V:$V/op_api/lib
  timeout 900 "$PY" "$MY/kda_a2_bench.py" "$JSON" "$CID" 2 10 "$CACHE" \
      > "$MY/bench_$tag.log" 2>&1
  line=$(grep -a "event=" "$MY/bench_$tag.log" | tail -1)
  if [ -n "$line" ]; then echo "[$tag] $line"; else echo "[$tag] MEASURE FAIL"; tail -5 "$MY/bench_$tag.log"; fi
  cp -f "$VEC.e2sub" "$VEC"
done
echo "=== 恢复源码（已优化版） ==="
cp -f "$BASE_SRC" "$VEC"
echo done
