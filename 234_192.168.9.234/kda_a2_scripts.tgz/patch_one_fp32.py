"""纯 fp32 单段 dump：把 one_fp32_body.txt 插到 StageV3 的 tile 落盘之后。

用法: python patch_one_fp32.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "one_fp32_body.txt").read_text(encoding="utf-8")
ANCHOR = ("            AscendC::DataCopy(\n"
          "                augRelay[Workspace::kAugTileInRelay / sizeof(float)],\n"
          "                augTile, 1024);\n")


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "outGk" in text:
        raise SystemExit("[patch_one_fp32] already patched")
    if text.count(ANCHOR) != 1:
        raise SystemExit(f"[patch_one_fp32] anchor count={text.count(ANCHOR)}")
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text.replace(ANCHOR, ANCHOR + BODY, 1))
    print("[patch_one_fp32] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
