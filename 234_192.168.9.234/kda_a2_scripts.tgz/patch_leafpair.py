"""把两个叶子逆（两次 SolveLeafRightLooking）合并成一次共享屏障的调用。

依据：V3 的 3,075 µs 里有 2,362 µs 是两次叶子逆（函数级屏蔽实测），
代码形态是 2 × 31 步 × (Gather+Mul+Sub+3 PipeBarrier) = 186 个屏障；
两个叶子互不依赖 ⇒ 合并成一个 31 步的循环、屏障减半且两条链互相掩盖。
数学与每步算子顺序不变（逐位舍入顺序不变）。

用法: python patch_leafpair.py <vec.h> [--revert]
"""

from __future__ import annotations

import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
HELPER = (HERE / "leafpair_helper.txt").read_text(encoding="utf-8")

ANCHOR_DEF = "    __aicore__ inline void V0Vf(\n"

OLD_CALLS = """        auto coeffTile = raw;
        auto prodTile = raw[2048];
        SolveLeafRightLooking(x0, lkk, coeffOffset, coeffTile, prodTile,
                              topRows, 0, Shape::kChunkRows);
        SolveLeafRightLooking(x1, lkk, coeffOffset, coeffTile, prodTile,
                              bottomRows, 32 * Shape::kChunkRows + 32,
                              Shape::kChunkRows);
"""

NEW_CALLS = """        auto coeffTile = raw;
        auto prodTile = raw[2048];
        // 合并两个叶子的逆：4 块 scratch 各 1024 FP32，仍在 compact raw 区间内
        // （raw 可用到 5120 FP32，解包已经消费完，之后不再读 raw）。
        auto coeffTileB = raw[3072];
        auto prodTileB = raw[4096];
        SolveTwoLeavesRightLooking(
            x0, x1, lkk, coeffOffset, coeffTile, prodTile, coeffTileB,
            prodTileB, topRows, bottomRows, 0,
            32 * Shape::kChunkRows + 32, Shape::kChunkRows);
"""


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    backup = pathlib.Path(path + ".leafpair")
    src = pathlib.Path(path).read_text(encoding="utf-8")
    if "--revert" in sys.argv[2:]:
        if not backup.exists():
            raise SystemExit(f"[patch_leafpair] no backup {backup}")
        write_lf(path, backup.read_text(encoding="utf-8"))
        print("[patch_leafpair] reverted")
        return 0
    if "SolveTwoLeavesRightLooking" in src:
        raise SystemExit("[patch_leafpair] already patched")
    if src.count(OLD_CALLS) != 1:
        raise SystemExit(f"[patch_leafpair] call anchor count="
                         f"{src.count(OLD_CALLS)}")
    if src.count(ANCHOR_DEF) != 1:
        raise SystemExit(f"[patch_leafpair] def anchor count="
                         f"{src.count(ANCHOR_DEF)}")
    write_lf(backup, src)
    src = src.replace(OLD_CALLS, NEW_CALLS, 1)
    anchor = src.index(ANCHOR_DEF)
    src = src[:anchor] + HELPER + src[anchor:]
    write_lf(path, src)
    print("[patch_leafpair] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
