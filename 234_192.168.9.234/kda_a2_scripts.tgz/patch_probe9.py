"""probe9：两个实测出来的 AIV 侧小改（互不相关，一起上）——

A) L2 norm 尾部：去掉"把 WholeReduceSum 的结果压紧到另一个缓冲"的 64 次标量
   GetValue/SetValue（+2 次 V_S/S_V 往返）。依据：WholeReduceSum 的结果在 dst 上
   **连续落位**（A1 文档与实测都确认），所以直接原地做 eps→Sqrt→Div 即可。

B) token 维 cumsum：63 步"逐行 Add + 1 个 PipeBarrier"（= 63 次流水排空，E2 屏蔽实测
   333 µs）换成 Hillis-Steele 对数扫描：log2(validRows) 轮、每轮 2 条块指令 + 1 个屏障，
   在 g（共享区）与 tileBuf（私有区 0x8000，本 Stage 的 norm/gate 已用完）之间乒乓。
   ⚠ 求和顺序变成树形 ⇒ gk 的末位与改动前不同（相对 ~1e-7）。

用法: python3 patch_probe9.py <vec.h> [AB|A] [--revert]      # 默认 AB 两个一起
"""

from __future__ import annotations
import pathlib
import sys

A_OLD = """        {
            AscendC::SetFlag<AscendC::HardEvent::V_S>(scalarRead_);
            AscendC::WaitFlag<AscendC::HardEvent::V_S>(scalarRead_);
            for (uint32_t row = 0; row < validRows; ++row) {
                rowSum.SetValue(row, sumBlocks.GetValue(row));
            }
            AscendC::SetFlag<AscendC::HardEvent::S_V>(scalarWrite_);
            AscendC::WaitFlag<AscendC::HardEvent::S_V>(scalarWrite_);
        }
        AscendC::Adds(rowSum, rowSum, args_.tiling.epsilon, validRows);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Sqrt(rowSum, rowSum, validRows);
        AscendC::Duplicate(oneVec, 1.0F, validRows);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Div(rstdOut, oneVec, rowSum, validRows);
"""

A_NEW = """        // probe9-A：WholeReduceSum 的结果在 dst 上连续落位 ⇒ 原地做
        // eps→Sqrt→Div，省掉 64 次 GetValue/SetValue 与一次 V_S/S_V 往返。
        AscendC::Adds(sumBlocks, sumBlocks, args_.tiling.epsilon, validRows);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Sqrt(sumBlocks, sumBlocks, validRows);
        AscendC::Duplicate(oneVec, 1.0F, validRows);
        AscendC::PipeBarrier<PIPE_V>();
        AscendC::Div(rstdOut, oneVec, sumBlocks, validRows);
"""

B_OLD = """        // token 维前缀和保留 headDim 向量宽度，不跨 chunk 传播。
        // 这里刻意保留逐行累加：保证 gk（FP32 公开输出）与改动前逐位一致，
        // 63 步累加相对整块指令链的开销很小。
        for (uint32_t row = 1; row < validRows; ++row) {
            AscendC::Add(g[row * Shape::kHeadDim],
                         g[row * Shape::kHeadDim],
                         g[(row - 1) * Shape::kHeadDim], Shape::kHeadDim);
            AscendC::PipeBarrier<PIPE_V>();
        }
"""

B_NEW = """        // probe9-B：token 维前缀和改成 Hillis-Steele 对数扫描。
        // 原来 63 步"逐行 Add + 1 个屏障"= 63 次流水排空（屏蔽实测 333 µs）；
        // 现在 log2(validRows) 轮、每轮 2 条块指令 + 1 个屏障，源/目的在
        // g（共享区）与 tileBuf（私有区 0x8000，本 Stage 的 norm/gate 已用完）
        // 之间乒乓。⚠ gk 的求和顺序变成树形，末位与改动前不同（相对 ~1e-7）。
        {
            auto scanSrc = g;
            auto scanDst = tileBuf;
            bool inG = true;
            for (uint32_t d = 1; d < validRows; d <<= 1) {
                AscendC::Adds(scanDst, scanSrc, 0.0F, d * Shape::kHeadDim);
                AscendC::Add(scanDst[d * Shape::kHeadDim],
                             scanSrc[d * Shape::kHeadDim], scanSrc,
                             (validRows - d) * Shape::kHeadDim);
                AscendC::PipeBarrier<PIPE_V>();
                auto swap = scanSrc;
                scanSrc = scanDst;
                scanDst = swap;
                inG = !inG;
            }
            if (!inG) {
                AscendC::Adds(g, tileBuf, 0.0F, count);
                AscendC::PipeBarrier<PIPE_V>();
            }
        }
"""


def main() -> int:
    path = sys.argv[1]
    args = [a for a in sys.argv[2:] if not a.startswith("--")]
    mode = args[0] if args else "AB"
    revert = "--revert" in sys.argv
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8")
    bak = p.with_name(p.name + ".probe9bak")
    if revert:
        if not bak.exists():
            raise SystemExit("[patch_probe9] no backup")
        p.write_text(bak.read_text(encoding="utf-8"), encoding="utf-8",
                     newline="\n")
        print("[patch_probe9] reverted")
        return 0
    if bak.exists():
        raise SystemExit("[patch_probe9] already patched")
    for name, old, want in (("A", A_OLD, mode in ("AB", "A")),
                            ("B", B_OLD, mode in ("AB", "B"))):
        if want and src.count(old) != 1:
            raise SystemExit(f"[patch_probe9] anchor {name} x{src.count(old)}")
    if mode in ("AB", "B"):
        if src.count(B_OLD) != 1:
            raise SystemExit(f"[patch_probe9] anchor B x{src.count(B_OLD)}")
        src = src.replace(B_OLD, B_NEW, 1)
    if mode in ("AB", "A"):
        src = src.replace(A_OLD, A_NEW, 1)
    bak.write_text(p.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    p.write_text(src, encoding="utf-8", newline="\n")
    print(f"[patch_probe9] applied mode={mode}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
