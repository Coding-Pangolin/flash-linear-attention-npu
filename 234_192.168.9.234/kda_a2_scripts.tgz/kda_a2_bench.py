"""A2(910B3) 上直接调用 chunk_kda_fwd_prepare 做计时（绕开 ATK 执行层）。

用法: python kda_a2_bench.py <case_json> <case_id> [warmup] [repeat] [cache.pt]
输入按用例的声明式 spec 生成（dtype/shape/range），spec 与输入适配复用
tests/atk/chunk_kda_fwd_prepare/executor_chunk_kda_fwd_prepare.py 里的
_derive_spec / _direct_inputs / run_npu。

第 5 个参数给一个 .pt 路径时，第一次跑会把生成的输入缓存下来，之后复用
（本机 CPU 被其他容器压得很满，大 shape 的 randn 要 2~3 分钟，缓存后只剩
 磁盘 IO）。缓存里存的是 host 侧张量。
"""

from __future__ import annotations

import importlib.util
import json
import os
import sys
import time

import torch
import torch_npu  # noqa: F401

EXEC = "/home/admin123/kda_a2/repo/tests/atk/chunk_kda_fwd_prepare/executor_chunk_kda_fwd_prepare.py"
DT = {
    "bf16": torch.bfloat16,
    "fp16": torch.float16,
    "fp32": torch.float32,
    "int32": torch.int32,
    "int64": torch.int64,
}


def load_exec():
    spec = importlib.util.spec_from_file_location("kda_exec", EXEC)
    mod = importlib.util.module_from_spec(spec)
    sys.modules["kda_exec"] = mod
    spec.loader.exec_module(mod)
    return mod


def call_op(spec, inputs):
    """直接调稳定入口（参数名按 _stable.py：A_log 大写）。"""
    from fla_npu.ops.ascendc import chunk_kda_fwd_prepare as op

    return op(
        inputs.q, inputs.k, inputs.v, inputs.g, inputs.beta, float(spec["scale"]),
        layout=str(spec["layout"]), chunk_size=int(spec["chunk_size"]),
        epsilon=float(spec["epsilon"]),
        use_qk_l2norm_in_kernel=bool(spec["use_qk_l2norm_in_kernel"]),
        use_gate_in_kernel=bool(spec["use_gate_in_kernel"]),
        use_beta_sigmoid_in_kernel=bool(spec["use_beta_sigmoid_in_kernel"]),
        allow_neg_eigval=bool(spec["allow_neg_eigval"]),
        safe_gate=bool(spec["safe_gate"]), lower_bound=float(spec["lower_bound"]),
        use_exp2=bool(spec["use_exp2"]),
        A_log=inputs.a_log, dt_bias=inputs.dt_bias,
        cu_seqlens=inputs.cu_seqlens, chunk_indices=inputs.chunk_indices,
        backward_mode=str(spec.get("backward_mode", "save")),
    )


def make_inputs(items, dev):
    values = {}
    for raw in items:
        item = raw[0] if isinstance(raw, list) else raw
        name, dtype, shape = item["name"], item["dtype"], item.get("shape")
        rng = item.get("range_values")
        if shape is None:  # 标量 / 属性
            if dtype == "float":
                values[name] = float(rng)
            elif dtype == "int":
                values[name] = int(rng)
            elif dtype in ("attr_bool", "bool"):
                values[name] = bool(rng)
            else:
                # 用例里 cu_seqlens/chunk_indices 的缺省写作字符串 "null"
                if isinstance(rng, str) and rng.strip().lower() in ("null", "none", ""):
                    values[name] = None
                else:
                    values[name] = rng
            continue
        gen = torch.Generator().manual_seed(int(item.get("default_seed") or 0))
        if isinstance(rng, dict):
            mean, std = float(rng["mean"][0]), float(rng["std"][0])
            t = torch.randn(shape, generator=gen, dtype=torch.float32) * std + mean
        elif isinstance(rng, list) and len(rng) == 2:
            lo, hi = float(rng[0]), float(rng[1])
            t = torch.rand(shape, generator=gen, dtype=torch.float32) * (hi - lo) + lo
        else:
            t = torch.zeros(shape, dtype=torch.float32)
        values[name] = t.to(DT.get(dtype, torch.float32)).to(dev)
    return values


def load_or_make(items, dev, cache):
    if cache and os.path.exists(cache):
        t0 = time.time()
        blob = torch.load(cache, map_location="cpu")
        values = {k: (v.to(dev) if torch.is_tensor(v) else v)
                  for k, v in blob.items()}
        print(f"[bench] inputs loaded <{cache}> in {time.time() - t0:.1f}s",
              flush=True)
        return values
    t0 = time.time()
    values = make_inputs(items, dev)
    print(f"[bench] inputs generated in {time.time() - t0:.1f}s", flush=True)
    if cache:
        torch.save({k: (v.detach().cpu() if torch.is_tensor(v) else v)
                    for k, v in values.items()}, cache)
    return values


def main() -> int:
    case_json, cid = sys.argv[1], int(sys.argv[2])
    warmup = int(sys.argv[3]) if len(sys.argv) > 3 else 3
    repeat = int(sys.argv[4]) if len(sys.argv) > 4 else 10
    cache = sys.argv[5] if len(sys.argv) > 5 else None
    dev = "npu:0"
    ex = load_exec()
    cases = json.load(open(case_json, encoding="utf-8"))
    case = next(c for c in cases if c["id"] == cid)
    print(f"[bench] case {cid} {case['name']}", flush=True)

    values = load_or_make(case["inputs"], dev, cache)
    spec = ex._derive_spec(values, cid)
    inputs = ex._direct_inputs(values, high_precision=False)
    print(f"[bench] B={spec['B']} HK={spec['HK']} HV={spec['HV']} T={spec['T']} "
          f"layout={spec['layout']} mode={spec['backward_mode']}", flush=True)

    for _ in range(warmup):
        call_op(spec, inputs)
    torch.npu.synchronize()
    s = torch.npu.Event(enable_timing=True)
    e = torch.npu.Event(enable_timing=True)
    s.record()
    for _ in range(repeat):
        call_op(spec, inputs)
    e.record()
    torch.npu.synchronize()
    ev = s.elapsed_time(e) / repeat * 1000.0
    t0 = time.time()
    for _ in range(repeat):
        call_op(spec, inputs)
    torch.npu.synchronize()
    wall = (time.time() - t0) / repeat * 1e6
    print(f"[bench] event={ev:.1f} us/call  wall={wall:.1f} us/call "
          f"(warmup={warmup} repeat={repeat})", flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
