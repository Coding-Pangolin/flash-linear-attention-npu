"""在 AIV 的 StageV6 末尾加入 A4′ 值校验（诊断）：
cube 的 X^8 右上 8x8 与本 AIV X0 的 (0,0) 8x8 比对，超阈值就把 w[0] 置 1.0。

插入体来自 cbcheck_body.txt。

用法: python patch_cbcheck.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "cbcheck_body.txt").read_text(encoding="utf-8")

ANCHOR = ("        AscendC::DataCopy(vBetaRelay, vBeta, rhsRows * Shape::kValueDim);\n")


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "--revert" in sys.argv[2:]:
        if BODY not in text:
            raise SystemExit("[patch_cbcheck] revert anchor missing")
        write_lf(path, text.replace(BODY, "", 1))
        print("[patch_cbcheck] reverted")
        return 0
    if "checkCube" in text:
        raise SystemExit("[patch_cbcheck] already patched")
    if text.count(ANCHOR) != 1:
        raise SystemExit(f"[patch_cbcheck] anchor count={text.count(ANCHOR)}")
    write_lf(path, text.replace(ANCHOR, ANCHOR + BODY, 1))
    print("[patch_cbcheck] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
