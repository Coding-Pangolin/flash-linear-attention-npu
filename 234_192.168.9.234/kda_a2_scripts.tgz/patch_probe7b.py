"""probe7b：只保留 V1Vf / V6Vf 里"必须"的同流水屏障，其余冗余屏障删掉。

probe7（全部删）实测：**精度炸到 3.4e+11** ⇒ 这些 `PipeBarrier<PIPE_V>` 在本硬件/
CANN 版本上**确实承担同流水 RAW 顺序**（长延迟算子如 `Exp` 之后，读同一 UB 缓冲必须等）。

本版按"生产者是否长延迟/多指令"保留两处屏障：
  * 紧跟在 `AscendC::Exp(` 之后的屏障（长延迟）
  * 紧跟在 `SubTileMinusRow(` / `SubRowMinusTile(` 之后的屏障（多指令 helper，内部有多拍）
其余（Maxs/Mins/Muls/Cast/Mul 之间的）删除，然后用精度判据（case 60/80）验证。

用法: python3 patch_probe7b.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

FUNCS = ("__aicore__ inline void V1Vf(", "__aicore__ inline void V6Vf(")
BARRIER = "AscendC::PipeBarrier<PIPE_V>();"
KEEP_AFTER = ("AscendC::Exp(", "SubTileMinusRow(", "SubRowMinusTile(")


def main() -> int:
    path = sys.argv[1]
    revert = len(sys.argv) > 2 and sys.argv[2] == "--revert"
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8")
    bak = p.with_name(p.name + ".probe7bbak")
    if revert:
        if not bak.exists():
            raise SystemExit("[patch_probe7b] no backup")
        p.write_text(bak.read_text(encoding="utf-8"), encoding="utf-8",
                     newline="\n")
        print("[patch_probe7b] reverted")
        return 0
    if bak.exists():
        raise SystemExit("[patch_probe7b] already patched")
    removed = kept = 0
    spans = []
    for name in FUNCS:
        start = src.index(name)
        nxt = src.find("    __aicore__ inline void ", start + 1)
        spans.append((start, nxt if nxt != -1 else len(src)))
    for start, end in sorted(spans, reverse=True):
        lines = src[start:end].splitlines(keepends=True)
        out = []
        prev = ""
        for line in lines:
            if line.strip() == BARRIER:
                if any(k in prev for k in KEEP_AFTER):
                    kept += 1
                    out.append(line)
                else:
                    removed += 1
                continue
            out.append(line)
            if line.strip():
                prev = line
        src = src[:start] + "".join(out) + src[end:]
    if removed == 0:
        raise SystemExit("[patch_probe7b] nothing removed")
    bak.write_text(p.read_text(encoding="utf-8"), encoding="utf-8", newline="\n")
    p.write_text(src, encoding="utf-8", newline="\n")
    print(f"[patch_probe7b] removed {removed}, kept {kept}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
