"""A4′ 前置（AIC）：C4 里把 payload 的 L00/L11 读进 L1 空闲区（只搬不算）。

基：pristine cube.h（+ policy 需含 kL00Shadow/kL11Shadow，用 policy_aug.h 那一支）。

用法: python patch_c4l.py <cube.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "c4l_body.txt").read_text(encoding="utf-8")
ANCHOR = ("        AscendC::GlobalTensor<float> payload;\n"
          "        payload.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(\n")
L1_ANCHOR = "        pipe_->InitBuffer(l1Buf_, L1::kPeak);\n"
L1_NEW = "        pipe_->InitBuffer(l1Buf_, L1::kPeak + 0x2000);\n"


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "l00L1" in text:
        raise SystemExit("[patch_c4l] already patched")
    if text.count(ANCHOR) != 1 or text.count(L1_ANCHOR) != 1:
        raise SystemExit(f"[patch_c4l] anchors {text.count(ANCHOR)}"
                         f"/{text.count(L1_ANCHOR)}")
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        out = text.replace(ANCHOR, BODY + ANCHOR, 1)
        out = out.replace(L1_ANCHOR, L1_NEW, 1)
        handle.write(out)
    print("[patch_c4l] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
