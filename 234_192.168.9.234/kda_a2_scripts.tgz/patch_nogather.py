"""诊断用：把合并后叶子逆循环里的两次 Gather 关掉（Mul/Sub 保留），
用来定量区分"叶逆 2.4 ms 里 Gather 占多少、短向量 Mul/Sub 占多少"。

只用于计时（关掉 Gather 后 coeffTile 是旧值，数值必错），不跑精度。

用法: python patch_nogather.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

PAIRS = [
    ("""            if (rowsA > 0) {
                AscendC::Gather(
                    coeffA, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseA + (rowStride + 1) * k) * sizeof(float)),
                    rowsA * kLeaf);
            }
""",
     """            if (false && rowsA > 0) {  // NOGATHER 诊断
                AscendC::Gather(
                    coeffA, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseA + (rowStride + 1) * k) * sizeof(float)),
                    rowsA * kLeaf);
            }
"""),
    ("""            if (rowsB > 0) {
                AscendC::Gather(
                    coeffB, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseB + (rowStride + 1) * k) * sizeof(float)),
                    rowsB * kLeaf);
            }
""",
     """            if (false && rowsB > 0) {  // NOGATHER 诊断
                AscendC::Gather(
                    coeffB, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseB + (rowStride + 1) * k) * sizeof(float)),
                    rowsB * kLeaf);
            }
"""),
]


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "--revert" in sys.argv[2:]:
        for old, new in PAIRS:
            if new not in text:
                raise SystemExit("[patch_nogather] revert anchor missing")
            text = text.replace(new, old, 1)
        write_lf(path, text)
        print("[patch_nogather] reverted")
        return 0
    if "NOGATHER" in text:
        raise SystemExit("[patch_nogather] already patched")
    for old, new in PAIRS:
        if text.count(old) != 1:
            raise SystemExit(f"[patch_nogather] anchor count={text.count(old)}")
        text = text.replace(old, new, 1)
    write_lf(path, text)
    print("[patch_nogather] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
