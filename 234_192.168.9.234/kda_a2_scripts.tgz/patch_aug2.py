"""A4′ 第二步：把增广矩阵 tile 做成 32x32 fp32（4 KiB）写进 **relay**，
这样 cube 侧可以直接复用 C4 已验证的 32x32 fp32 装载/MMAD 写法。

为什么改 32x32 + relay：
  * C4 的 MMAD 流水（Nd2Nz 装 L1 → LoadData2D/LoadData3D 装 L0A/L0B → Mmad(fp32)）
    已经在跑 32x32 fp32，照抄它比新写 16x16 的 L0/L1 参数风险低得多；
  * payload 尾部只有 10 KiB（已被 kL00Shadow/kL11Shadow 占满），而 relay 有 20 KiB，
    且 V3 读完 raw score 后 relay 在本轮就空出来了（C4 之后只复用前 4 KiB 放 T，
    时序上"先读 tile 再写 T"由代码顺序保证）。

tile 内容（32x32，行距 32）：
    [ -N8  I8   0   0 ]
    [  0   I8   0   0 ]
    [  0   0    0   0 ]
    [  0   0    0   0 ]
其中 N8 = L00 的 (0,0) 8x8 严格下三角块 ⇒ X^8 的右上 8x8 = (I+N)^-1。

只做加法（写 relay 的空闲区），用于验证不破坏现有行为。

用法: python patch_aug2.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

OLD = """        if (chunk.validRows >= 8) {
            auto augBase =
                ub[Arch22Ub::kSharedScratch].template ReinterpretCast<float>();
            auto augTile = augBase;
            auto augZero = augBase[512];   // 8 个零：给 Sub 当 src0（repStride=0）
            AscendC::Duplicate(augTile, 0.0F, 512);
            AscendC::Duplicate(augZero, 0.0F, 8);
            AscendC::PipeBarrier<PIPE_V>();
            // dst = 0 - lkk 的左上 8x8：src0 用 repStride=0 反复读独立零块
            // （不能读 augTile 自己，否则第一行写完就被后面几行读到），
            // src1 = lkk 行距 8 block、每行取 1 block。
            AscendC::Sub(augTile, augZero, lkk, 8, 8, {1, 1, 1, 4, 0, 8});
            AscendC::PipeBarrier<PIPE_V>();
            // 两个 I8 都用"行首对齐的基址 + mask 选中块内 lane"的写法（VEC 的 dst
            // 必须 32B 对齐）：元素 (i, 8+i) 在第 1 个 block 的 lane i 上，8 行
            // 之后 block 前进 33（8 行 = 32 block，另加 8 列 = 1 block）。
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[lane * 32], 1.0F, mask, 1, 1, 33);
            }
            // 右下 I8：(8+i, 8+i) → 基址取第 8+lane 行行首，同样 mask 选块 1 的 lane
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[(8 + lane) * 32], 1.0F, mask, 1, 1,
                                   33);
            }
            AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            AscendC::GlobalTensor<float> payloadT;
            payloadT.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(
                args_.workspace + slot + Workspace::kPayload));
            AscendC::DataCopy(payloadT[Workspace::kAugTile / sizeof(float)],
                              augTile, 512);
        }
"""

NEW = """        if (chunk.validRows >= 8) {
            auto augBase =
                ub[Arch22Ub::kSharedScratch].template ReinterpretCast<float>();
            auto augTile = augBase;
            auto augZero = augBase[1024];  // 8 个零：给 Sub 当 src0（repStride=0）
            AscendC::Duplicate(augTile, 0.0F, 1024);
            AscendC::Duplicate(augZero, 0.0F, 8);
            AscendC::PipeBarrier<PIPE_V>();
            // dst = 0 - lkk 的左上 8x8：src0 用独立零块 + repStride=0
            // （不能读 augTile 自己，否则第 0 行写完就被后面几行读到），
            // src1 = lkk（行距 64 元素 = 8 block），每行取 1 block。
            AscendC::Sub(augTile, augZero, lkk, 8, 8, {1, 1, 1, 4, 0, 8});
            AscendC::PipeBarrier<PIPE_V>();
            // 两个 I8：VEC 的 dst 必须 32B 对齐 ⇒ 用"行首对齐基址 + mask 选中
            // 块内 lane"。元素 (i, 8+i) 在 block 1 的 lane i 上，8 行后 block
            // 前进 33（8 行 = 32 block，另加 8 列 = 1 block）。
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[lane * 32], 1.0F, mask, 1, 1, 33);
            }
            for (uint32_t lane = 0; lane < 8; ++lane) {
                uint64_t mask[2] = {1ULL << (8 + lane), 0};
                AscendC::Duplicate(augTile[(8 + lane) * 32], 1.0F, mask, 1, 1,
                                   33);
            }
            AscendC::SetFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            AscendC::WaitFlag<AscendC::HardEvent::V_MTE3>(outputReady_[pair]);
            // 写进 relay 开头 4 KiB（V3 已经消费完 raw score；C4 之后才复用前
            // 4 KiB 放 T，所以顺序上安全）。
            AscendC::GlobalTensor<float> augRelay;
            augRelay.SetGlobalBuffer(reinterpret_cast<__gm__ float *>(
                args_.workspace + slot + Workspace::kArch22CubeRelay),
                Workspace::kArch22RawScoreBytes / sizeof(float));
            AscendC::DataCopy(augRelay, augTile, 1024);
        }
"""


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "--revert" in sys.argv[2:]:
        if NEW not in text:
            raise SystemExit("[patch_aug2] revert anchor missing")
        write_lf(path, text.replace(NEW, OLD, 1))
        print("[patch_aug2] reverted")
        return 0
    if text.count(OLD) != 1:
        raise SystemExit(f"[patch_aug2] anchor count={text.count(OLD)}")
    write_lf(path, text.replace(OLD, NEW, 1))
    print("[patch_aug2] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
