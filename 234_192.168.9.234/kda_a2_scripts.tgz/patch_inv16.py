"""A4′ 验收：cube 侧 16×16 增广求逆（4 次平方）+ AIV 侧比对哨兵。

基：cube_c4l.h（已含 L00/L11 读取）+ vec_t16.h（已含 16×16 块级 tile 落 relay）。

用法: python patch_inv16.py <cube.h> <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
INV = (HERE / "inv16_def.txt").read_text(encoding="utf-8")
SENT = (HERE / "sent_body.txt").read_text(encoding="utf-8")

CUBE_ANCHOR = "    __aicore__ inline void StageC4(const ChunkRange &chunk,"
CUBE_CALL_ANCHOR = ("        AscendC::DataCopy(akkL1, akkSource, akkCopy);\n")
CUBE_CALL = "        StageC4Inv16(chunk, localHead);\n"
ROW_ANCHOR = "constexpr AscendC::FixpipeConfig kFixpipeNz = {"
ROW_NEW = ("constexpr AscendC::FixpipeConfig kFixpipeRow = {\n"
           "    AscendC::CO2Layout::ROW_MAJOR, false};\n"
           "constexpr AscendC::FixpipeConfig kFixpipeNz = {")
VEC_ANCHOR = "        AscendC::DataCopy(vBetaRelay, vBeta, rhsRows * Shape::kValueDim);\n"


def main() -> int:
    cube, vec = sys.argv[1], sys.argv[2]
    ctext = pathlib.Path(cube).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    if "StageC4Inv16" in ctext or "cubeBlk" in vtext:
        raise SystemExit("[patch_inv16] already patched")
    if ctext.count(CUBE_ANCHOR) != 1 or ctext.count(CUBE_CALL_ANCHOR) != 1:
        raise SystemExit("[patch_inv16] cube anchors missing")
    if vtext.count(VEC_ANCHOR) != 1:
        raise SystemExit(f"[patch_inv16] vec anchor={vtext.count(VEC_ANCHOR)}")
    idx = ctext.index(CUBE_ANCHOR)
    ctext = ctext[:idx] + INV + ctext[idx:]
    ctext = ctext.replace(CUBE_CALL_ANCHOR, CUBE_CALL_ANCHOR + CUBE_CALL, 1)
    if "kFixpipeRow = {" not in ctext:
        if ctext.count(ROW_ANCHOR) != 1:
            raise SystemExit("[patch_inv16] kFixpipeNz anchor missing")
        ctext = ctext.replace(ROW_ANCHOR, ROW_NEW, 1)
    with open(cube, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(ctext)
    with open(vec, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(vtext.replace(VEC_ANCHOR, VEC_ANCHOR + SENT, 1))
    print("[patch_inv16] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
