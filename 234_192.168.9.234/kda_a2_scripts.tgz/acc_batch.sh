#!/bin/bash
# 精度 A/B 批跑：对给定用例集合，用指定 vendor（TAG）跑 acc_ab.py。
#   TAG=normblk bash acc_batch.sh 0 4 10 11 13 17 19 26 46 61
set +u
MY=${MY:-/home/admin123/kda_a2}
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
JSON=${JSON:-$MY/repo/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_a2.json}
TAG=${TAG:-}
PKG=$MY/python-a2c/fla_npu
V=$PKG/opp/vendors/fla_npu_transformer

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
BASE_OPP=${ASCEND_CUSTOM_OPP_PATH:-}
if [ -n "$TAG" ]; then
  VDIR=$PKG/opp_vendors/$TAG/vendors/fla_npu_transformer
else
  VDIR=$(readlink -f "$V")
fi
[ -d "$VDIR" ] || { echo "no vendor: $VDIR"; exit 1; }
# 必须同时改软链：op store 会跟着 opp/vendors/fla_npu_transformer 走。
rm -rf "$V"; ln -sT "$VDIR" "$V"
export ASCEND_CUSTOM_OPP_PATH=${BASE_OPP:+$BASE_OPP:}$VDIR:$VDIR/op_api/lib
OUTDIR=$MY/acc/$(basename "$(dirname "$(dirname "$VDIR")")")
mkdir -p "$OUTDIR" "$MY/cache"
echo "[acc_batch] vendor=$VDIR out=$OUTDIR"

for cid in "$@"; do
  log=$OUTDIR/acc_$cid.log
  timeout 3600 "$PY" "$MY/acc_ab.py" "$JSON" "$cid" "$MY/cache/acc$cid.pt" \
      "$OUTDIR/case$cid" >> "$log" 2>&1
  if [ $? -ne 0 ]; then echo "[case $cid] RUN FAIL (see $log)"; continue; fi
  echo "[case $cid] $(grep -a '^\[acc\] worst' "$log" | tail -1) " \
       "$(grep -a -E '^\[acc\] (PASS|FAIL)' "$log" | tail -1)"
done
