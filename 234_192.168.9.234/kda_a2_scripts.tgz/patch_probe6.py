"""P1 判定探针：叶逆的 `Gather` 到底"按条数"还是"按元素数"计费。

背景：`SolveTwoLeavesRightLooking` 每步一次 `Gather`，每步取 rowsA 行 × 32 lane
（rowsA 从 31 递减到 1，共 62 次/chunk-head）。计划中的 P1 是"两列一批"：
**Gather 条数减半、但每条读的元素数翻倍**（因为静态偏移表要求每列占满 32 行）。
所以先做一个**不改变正确性**的探针：把每次 Gather 的行数直接写成满 32 行
（多读的元素不会被 Mul/Sub 消费，结果逐位不变），这样：
  * 时长基本不变 ⇒ Gather 按**条数**计费 ⇒ P1（两列一批）成立，预计省 ~0.6 ms；
  * 时长明显变长 ⇒ Gather 按**元素数/吞吐**计费 ⇒ P1 无效，改走 P2（V1 指数去重）。

用法: python3 patch_probe6.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

OLD = """            if (rowsA > 0) {
                AscendC::Gather(
                    coeffA, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseA + (rowStride + 1) * k) * sizeof(float)),
                    rowsA * kLeaf);
            }
            if (rowsB > 0) {
                AscendC::Gather(
                    coeffB, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseB + (rowStride + 1) * k) * sizeof(float)),
                    rowsB * kLeaf);
            }
"""

NEW = """            if (rowsA > 0) {
                // probe6：行数写满 32（多读的行不被消费，结果逐位不变）
                AscendC::Gather(
                    coeffA, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseA + (rowStride + 1) * k) * sizeof(float)),
                    kLeaf * kLeaf);
            }
            if (rowsB > 0) {
                AscendC::Gather(
                    coeffB, lkk, coeffOffset,
                    static_cast<uint32_t>(
                        (baseB + (rowStride + 1) * k) * sizeof(float)),
                    kLeaf * kLeaf);
            }
"""


def main() -> int:
    path = sys.argv[1]
    revert = len(sys.argv) > 2 and sys.argv[2] == "--revert"
    src = pathlib.Path(path).read_text(encoding="utf-8")
    if revert:
        if src.count(NEW) != 1:
            raise SystemExit("[patch_probe6] revert anchor missing")
        src = src.replace(NEW, OLD, 1)
        pathlib.Path(path).write_text(src, encoding="utf-8", newline="\n")
        print("[patch_probe6] reverted")
        return 0
    if src.count(OLD) != 1:
        raise SystemExit(f"[patch_probe6] anchor count={src.count(OLD)}")
    src = src.replace(OLD, NEW, 1)
    pathlib.Path(path).write_text(src, encoding="utf-8", newline="\n")
    print("[patch_probe6] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
