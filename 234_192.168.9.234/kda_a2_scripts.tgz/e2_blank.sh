#!/bin/bash
# E2：分 stage 屏蔽差分（blank-out）——在容器内执行。
# 对每个 stage 的 arch22 实现插入一句 return（body 置空、同步回合不变），重编、换 OPP、测 case 63，
# 与基线之差 ≈ 该 stage 的关键路径贡献。
#   CID=63 STAGES="V0 V1 V3 V6 C2 C4 C5 C7" bash e2_blank.sh
set +u   # ⚠ CANN 的 set_env.sh 在 set -u 下会因未定义变量直接中断
MY=${MY:-/home/admin123/kda_a2}
REPO=$MY/repo
OP=$REPO/fla/ops/ascendc/kda/chunk_kda_fwd_prepare
VEC=$OP/op_kernel/arch22/chunk_kda_fwd_prepare_vec.h
CUBE=$OP/op_kernel/arch22/chunk_kda_fwd_prepare_cube.h
PKG=$MY/python-a2c/fla_npu
V=$PKG/opp/vendors/fla_npu_transformer
JSON=$OP/../../../tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
CID=${CID:-63}
STAGES=${STAGES:-"V0 V1 V3 V6 C2 C4 C5 C7"}

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
[ -e "$V.orig" ] || cp -a "$V" "$V.orig"

blank() { # $1 file  $2 func
  "$PY" - "$1" "$2" <<'PY'
import re, sys
path, fn = sys.argv[1], sys.argv[2]
src = open(path).read()
pat = re.compile(r"(__aicore__\s+inline\s+void\s+" + fn + r"\s*\([^)]*\)\s*\n\s*\{\n)")
new, cnt = pat.subn(lambda m: m.group(1) + "        return;  // E2 blank-out\n", src, count=1)
if cnt != 1:
    raise SystemExit(f"[blank] NOT FOUND {fn} in {path}")
open(path, "w").write(new)
print(f"[blank] {fn}")
PY
}

measure() { # $1 tag
  local log=$MY/bench_$1.log
  "$PY" "$MY/kda_a2_bench.py" "$JSON" "$CID" 1 3 > "$log" 2>&1
  local line
  line=$(grep -a "event=" "$log" | tail -1)
  if [ -n "$line" ]; then
    echo "[$1] $line"
  else
    echo "[$1] MEASURE FAIL:"; tail -3 "$log" | sed "s/^/        /"
  fi
}

install_tag() { # $1 tag
  local tag=$1
  bash $REPO/build.sh --pkg --soc=ascend910b --vendor_name=fla_npu --ops=chunk_kda_fwd_prepare \
      > "$MY/build_$tag.log" 2>&1 || { echo "[$tag] BUILD FAIL (see build_$tag.log)"; return 1; }
  local run
  run=$(ls -t $REPO/build_out/*.run | head -1)
  local exp=$PKG/opp_vendors/$tag
  mkdir -p "$PKG/opp_vendors"; rm -rf "$exp"
  "$run" --quiet --install-path="$exp" > /dev/null 2>&1 || { echo "[$tag] INSTALL FAIL"; return 1; }
  mkdir -p "$exp/vendors"; echo "load_priority=fla_npu_transformer" > "$exp/vendors/config.ini"
  rm -rf "$V"; ln -sT "$exp/vendors/fla_npu_transformer" "$V"
  source "$V/bin/set_env.bash" 2>/dev/null
}

echo "=== 基线 ==="
install_tag e2_base && measure e2_base
for s in $STAGES; do
  case "$s" in
    V*) f=$VEC ;;
    C*) f=$CUBE ;;
    *) echo "[skip] $s"; continue ;;
  esac
  cp -f "$f" "$f.e2bak"
  blank "$f" "Stage$s" || { cp -f "$f.e2bak" "$f"; continue; }
  install_tag "e2_blank_$s" && measure "e2_blank_$s"
  cp -f "$f.e2bak" "$f"
done
echo "=== 恢复后复测 ==="
install_tag e2_restore && measure e2_restore
