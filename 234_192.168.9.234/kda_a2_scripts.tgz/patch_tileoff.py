"""修 A4′ 的"tile 落点 ≠ 读取点"：AIV 之前把增广 tile 写在 relay+0，而 probe 读 relay+0x4000，
且 relay+0 会被 C4 的 T 覆写（所以回读到的其实是上一个 head 的 T —— 实测回读值 = T[0]）。
本补丁把 AIV 的写法改到 relay + kAugTileInRelay。

用法: python patch_tileoff.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

OLD = "            AscendC::DataCopy(augRelay, augTile, 1024);\n"
NEW = ("            AscendC::DataCopy(\n"
       "                augRelay[Workspace::kAugTileInRelay / sizeof(float)],\n"
       "                augTile, 1024);\n")


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "--revert" in sys.argv[2:]:
        if NEW not in text:
            raise SystemExit("[patch_tileoff] revert anchor missing")
        write_lf(path, text.replace(NEW, OLD, 1))
        print("[patch_tileoff] reverted")
        return 0
    if NEW in text:
        raise SystemExit("[patch_tileoff] already patched")
    if text.count(OLD) != 1:
        raise SystemExit(f"[patch_tileoff] anchor count={text.count(OLD)}")
    write_lf(path, text.replace(OLD, NEW, 1))
    print("[patch_tileoff] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
