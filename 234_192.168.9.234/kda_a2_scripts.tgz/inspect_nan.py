"""看 case*.pt 里 npu 出参的 NaN / 大偏差落在哪些 (b,h,t) 位置。

用法: python3 inspect_nan.py <case.pt> [out_index]
"""

from __future__ import annotations
import sys

import torch


def report(name: str, mask: torch.Tensor, rows: int) -> None:
    flat = mask.reshape(mask.shape[0], mask.shape[1], -1)
    per = flat.sum(dim=-1)
    nz = per.nonzero()
    print(f"{name}: (b,h) pairs={nz.shape[0]} total={int(mask.sum().item())}")
    for row in nz[:12]:
        b, h = int(row[0]), int(row[1])
        bad_rows = mask[b, h].reshape(-1, mask.shape[-1]).any(dim=1)
        first = bad_rows.nonzero().flatten()
        print(f"  b={b} h={h} elems={int(per[b, h].item())} "
              f"rows={int(bad_rows.sum().item())}/{rows} "
              f"first_rows={first[:8].tolist()}")


def main() -> int:
    path = sys.argv[1]
    idx = int(sys.argv[2]) if len(sys.argv) > 2 else 1
    blob = torch.load(path, map_location="cpu")
    got = blob["npu"][idx]
    want = blob["cpu"][idx]
    g, w = got.float(), want.float()
    print(f"{path}: shape={tuple(g.shape)} dtype={got.dtype} "
          f"nan={int(torch.isnan(g).sum().item())}")
    diff = (g - w).abs()
    print(f"want nan={int(torch.isnan(w).sum().item())} "
          f"maxdiff={diff.nan_to_num(1e9).max().item():.3e}")
    rows = g.shape[-2]
    tol = 1e-2 + 2e-3 * w.abs()
    report("nan", torch.isnan(g), rows)
    report("over-tol", (diff > tol), rows)
    if len(sys.argv) > 3:
        other = torch.load(sys.argv[3], map_location="cpu")["npu"][idx].float()
        d2 = (g - other).abs()
        print(f"vs {sys.argv[3]}: nan={int(torch.isnan(other).sum().item())} "
              f"maxdiff={d2.nan_to_num(1e9).max().item():.3e}")
        report("diff-vs-other", (d2 > 1e-3), rows)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
