"""A5 探针：量化"把 AIC 的 C2/C4/C5/C7 从关键路径上摘下来"的天花板。

背景（2026-10-09 实测）：本算子的核间握手是逐回合 lockstep
（AIV ready → AIC 本回合 → free → AIV 下一回合），所以 E2 屏蔽给出的
C2 16.3% + C4/C5/C7 18.4% 是直接叠在总时长上的。若把回合作成"软流水"
（AIV 可以领先 AIC 一个 chunk-head），总时长的下界就是 **AIV 自己跑完的时间**。

本脚本只**屏蔽计算、保留全部握手**，用来量这个下界（不动 flag 语义）：
  a: AIC 侧 C2/C4/C5/C7 全空转（保留 ready/free） -> AIV-only 下界
  b: 两侧都空转（保留 ready/free）                -> 纯回合/握手开销

用法: python3 patch_probe5.py <cube.h> <vec.h> <a|b>
"""

from __future__ import annotations
import pathlib
import sys

C2_OFF = ("                            StageC2(chunk, localHead);\n", "")
C4_OFF = ("                            StageC4(chunk, localHead);\n", "")
C5_OFF = ("                        StageC5(chunk, valueHead, localHead);\n", "")
C7_OFF = (
    "                    StageC7(chunk, groupBegin, activeHeads, pair,\n"
    "                            kFreeFlagId[pair]);\n",
    "                    // C7 空转：只保留 workspace 归还（free 发布）\n"
    "                    AscendC::CrossCoreSetFlag<0x2, PIPE_MTE2>(\n"
    "                        kFreeFlagId[pair]);\n",
)
CUBE_REPL = {
    "a": (C2_OFF, C4_OFF, C5_OFF, C7_OFF),
    "b": (C2_OFF, C4_OFF, C5_OFF, C7_OFF),
    "c": (C2_OFF,),
    "d": (C4_OFF, C5_OFF, C7_OFF),
}

VEC_REPL = (
    ("                        StageV0(chunk, valueHead, localHead, pair);\n"
     "                        StageV1(chunk, localHead, pair);\n", ""),
    ("                        StageV3(chunk, valueHead, localHead, pair);\n", ""),
    ("                        StageV6(chunk, valueHead, localHead, pair);\n", ""),
)


def main() -> int:
    cube, vec, tag = sys.argv[1], sys.argv[2], sys.argv[3]
    ctext = pathlib.Path(cube).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    if "probe5" in ctext:
        raise SystemExit("[patch_probe5] already patched")
    for old, _ in CUBE_REPL[tag]:
        if ctext.count(old) != 1:
            raise SystemExit(
                f"[patch_probe5] cube anchor x{ctext.count(old)}: {old!r}")
    for old, new in CUBE_REPL[tag]:
        ctext = ctext.replace(old, new, 1)
    if tag == "b":
        for old, _ in VEC_REPL:
            if vtext.count(old) != 1:
                raise SystemExit(
                    f"[patch_probe5] vec anchor x{vtext.count(old)}: {old!r}")
        for old, new in VEC_REPL:
            vtext = vtext.replace(old, new, 1)
        pathlib.Path(vec).write_text(vtext, encoding="utf-8", newline="\n")
    pathlib.Path(cube).write_text(ctext, encoding="utf-8", newline="\n")
    print(f"[patch_probe5] applied variant={tag}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
