#!/bin/bash
# 构建 chunk_kda_fwd_prepare（A2/910B3）并把包装到 opp_vendors/<TAG>，最后把软链指过去。
# 用法: TAG=<名字> bash build_a2.sh
set +u
MY=${MY:-/home/admin123/kda_a2}
REPO=$MY/repo
PKG=$MY/python-a2c/fla_npu
V=$PKG/opp/vendors/fla_npu_transformer
TAG=${TAG:-manual}
LOG=${LOG:-$MY/build_$TAG.log}

source /usr/local/Ascend/ascend-toolkit/set_env.sh

echo "[build_a2] TAG=$TAG log=$LOG"
if ! bash $REPO/build.sh --pkg --soc=ascend910b --vendor_name=fla_npu \
        --ops=chunk_kda_fwd_prepare > "$LOG" 2>&1; then
  echo "[build_a2] BUILD FAIL"
  tail -20 "$LOG"
  exit 1
fi
run=$(ls -t $REPO/build_out/*.run | head -1)
exp=$PKG/opp_vendors/$TAG
rm -rf "$exp"; mkdir -p "$exp"
"$run" --quiet --install-path="$exp" > "$MY/install_$TAG.log" 2>&1 || {
  echo "[build_a2] INSTALL FAIL"; tail -20 "$MY/install_$TAG.log"; exit 1; }
mkdir -p "$exp/vendors"; echo "load_priority=fla_npu_transformer" > "$exp/vendors/config.ini"
rm -rf "$V"; ln -sT "$exp/vendors/fla_npu_transformer" "$V"
echo "[build_a2] OK -> $V -> $exp/vendors/fla_npu_transformer"
