"""A4′ 诊断前置：把 1024/512/2048 三个特征常数写进 aqk/akk/w，验证读回通道。

基：vec_aug2.h（不需要 tileoff）。插入体来自 mark_body.txt，插在 StageV3 末尾
（payload 写之后）。

用法: python patch_mark.py <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
BODY = (HERE / "mark_body.txt").read_text(encoding="utf-8")
ANCHOR = ("            AscendC::DataCopy(payload[Workspace::kB / sizeof(float)], b, 1024);\n"
          "        }\n")


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    path = sys.argv[1]
    text = pathlib.Path(path).read_text(encoding="utf-8")
    if "outAqk" in text:
        raise SystemExit("[patch_mark] already patched")
    if text.count(ANCHOR) != 1:
        raise SystemExit(f"[patch_mark] anchor count={text.count(ANCHOR)}")
    write_lf(path, text.replace(ANCHOR, ANCHOR + BODY, 1))
    print("[patch_mark] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
