"""A4′ 诊断第二轮：
  * cube 侧换成 cubeprobe_def2.txt（全程 ROW_MAJOR + 中间结果行主序回装 + tile 回声）；
  * AIV 侧把 dump 换成一口气 dump 三段（回声 / X² / X⁸）到 w[0:192]。

输入基：pristine cube.h + policy_aug.h + vec_cbdump.h

用法: python patch_round2.py <policy.h> <cube.h> <vec.h>
"""

from __future__ import annotations
import pathlib
import sys

HERE = pathlib.Path(__file__).resolve().parent
PROBE2 = (HERE / "cubeprobe_def2.txt").read_text(encoding="utf-8")
BODY2 = (HERE / "cbcheck_body2.txt").read_text(encoding="utf-8")
BODY1 = (HERE / "cbcheck_body.txt").read_text(encoding="utf-8")

POLICY_ANCHOR = "constexpr uint32_t kAugTile = 0x11800;\n"
POLICY_NEW = (
    "constexpr uint32_t kAugTile = 0x11800;\n"
    "\n"
    "// A4′ probe：增广 tile 在 relay 内的偏移，以及 X^8 输出偏移（relay 共 0x5000）。\n"
    "constexpr uint32_t kAugTileInRelay = 0x4000;\n"
    "constexpr uint32_t kAugProbeOut = 0x1000;\n"
)
ROW_ANCHOR = "constexpr AscendC::FixpipeConfig kFixpipeNz = {"
ROW_NEW = ("constexpr AscendC::FixpipeConfig kFixpipeRow = {\n"
           "    AscendC::CO2Layout::ROW_MAJOR, false};\n"
           "constexpr AscendC::FixpipeConfig kFixpipeNz = {")
TAGGED_END = ("        AscendC::SetFlag<AscendC::HardEvent::MTE2_MTE1>"
              "(tReady_[localHead]);\n")
PROBE_CALL = "        StageC4Probe(chunk, localHead);\n"
DEF_ANCHOR = "    __aicore__ inline void StageC4(const ChunkRange &chunk,"


def write_lf(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as handle:
        handle.write(text)


def main() -> int:
    policy, cube, vec = sys.argv[1], sys.argv[2], sys.argv[3]
    ptext = pathlib.Path(policy).read_text(encoding="utf-8")
    ctext = pathlib.Path(cube).read_text(encoding="utf-8")
    vtext = pathlib.Path(vec).read_text(encoding="utf-8")
    if BODY1 not in vtext:
        raise SystemExit("[patch_round2] vec 里没有上一版 dump 体")
    if "StageC4Probe" in ctext or "kAugTileInRelay" in ptext:
        raise SystemExit("[patch_round2] 需要 pristine cube/policy_aug 基")
    if ptext.count(POLICY_ANCHOR) != 1 or ctext.count(ROW_ANCHOR) != 1:
        raise SystemExit("[patch_round2] anchors missing")
    if ctext.count(TAGGED_END) != 1:
        raise SystemExit("[patch_round2] tReady anchor count "
                         f"{ctext.count(TAGGED_END)}")
    write_lf(policy, ptext.replace(POLICY_ANCHOR, POLICY_NEW, 1))
    ctext = ctext.replace(ROW_ANCHOR, ROW_NEW, 1)
    ctext = ctext.replace(TAGGED_END, TAGGED_END + PROBE_CALL, 1)
    idx = ctext.index(DEF_ANCHOR)
    ctext = ctext[:idx] + PROBE2 + ctext[idx:]
    write_lf(cube, ctext)
    write_lf(vec, vtext.replace(BODY1, BODY2, 1))
    print("[patch_round2] applied")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
