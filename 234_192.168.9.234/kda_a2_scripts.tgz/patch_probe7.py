"""probe7：去掉 V1Vf / V6Vf 里"同一条 V 流水内部"的冗余 `PipeBarrier<PIPE_V>`。

依据：这两个 stage 的每个 7 行小块都有 ~10 条 `PipeBarrier<PIPE_V>()`，而块内的
算子链（SubRowMinusTile → Maxs → Mins → Muls → Exp → Cast → Mul → Cast）全部落在
**同一条 V 流水**上、且读写同一批 UB 缓冲。AscendC 的 V 流水按序执行，
同一流水内的 RAW 由硬件保证；`PipeBarrier<PIPE_V>` 只影响 V 流水自身，
不承担跨流水（MTE2/V、V/MTE3…）的同步——后者在本函数里用的是
SetFlag/WaitFlag 成对事件（本补丁不动）。

风险与判据：如果这个 CANN 版本确实需要显式同流水屏障，精度会立刻掉
（`acc_batch.sh` 一眼看出）⇒ 立即 `--revert`。

用法: python3 patch_probe7.py <vec.h> [--revert]
"""

from __future__ import annotations
import pathlib
import sys

FUNCS = ("__aicore__ inline void V1Vf(", "__aicore__ inline void V6Vf(")
BARRIER = "AscendC::PipeBarrier<PIPE_V>();"


def spans(src: str) -> list[tuple[int, int]]:
    out = []
    for name in FUNCS:
        start = src.index(name)
        nxt = src.find("    __aicore__ inline void ", start + 1)
        end = nxt if nxt != -1 else len(src)
        out.append((start, end))
    return sorted(out)


def transform(src: str) -> tuple[str, int]:
    removed = 0
    for start, end in reversed(spans(src)):
        body = src[start:end]
        keep = []
        for line in body.splitlines(keepends=True):
            if line.strip() == BARRIER:
                removed += 1
                continue
            keep.append(line)
        src = src[:start] + "".join(keep) + src[end:]
    return src, removed


def main() -> int:
    path = sys.argv[1]
    revert = len(sys.argv) > 2 and sys.argv[2] == "--revert"
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8")
    bak = p.with_name(p.name + ".probe7bak")
    if revert:
        if not bak.exists():
            raise SystemExit("[patch_probe7] no .p0 backup")
        p.write_text(bak.read_text(encoding="utf-8"), encoding="utf-8",
                     newline="\n")
        print("[patch_probe7] reverted")
        return 0
    if bak.exists():
        raise SystemExit("[patch_probe7] already patched (.p0 exists)")
    new, removed = transform(src)
    if removed == 0:
        raise SystemExit("[patch_probe7] nothing removed")
    bak.write_text(src, encoding="utf-8", newline="\n")
    p.write_text(new, encoding="utf-8", newline="\n")
    print(f"[patch_probe7] removed {removed} V-pipe barriers in V1Vf/V6Vf")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
