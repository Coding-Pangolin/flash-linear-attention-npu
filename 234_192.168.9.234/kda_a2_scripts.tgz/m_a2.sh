#!/bin/bash
# 在容器 kda_a2 内测一次算子耗时（默认测 opp/vendors/fla_npu_transformer 软链当前指向的版本）。
# 用法: [TAG=<opp_vendors 下的名字>] [CID=63] [W=1] [R=3] bash m_a2.sh
set +u
MY=${MY:-/home/admin123/kda_a2}
PY=${PY:-/opt/anaconda3/envs/fzy/bin/python}
JSON=${JSON:-$MY/repo/tests/atk/chunk_kda_fwd_prepare/atk_chunk_kda_fwd_prepare_perf_a2.json}
CID=${CID:-63}; W=${W:-1}; R=${R:-3}
TAG=${TAG:-}
CACHE=${CACHE:-$MY/cache/case$CID.pt}
PKG=$MY/python-a2c/fla_npu
V=$PKG/opp/vendors/fla_npu_transformer
mkdir -p "$(dirname "$CACHE")"

source /usr/local/Ascend/ascend-toolkit/set_env.sh
export ASCEND_RT_VISIBLE_DEVICES=${DEV:-7}
export PYTHONPATH=$MY/python-a2c:${PYTHONPATH:-}
BASE_OPP=${ASCEND_CUSTOM_OPP_PATH:-}

if [ -n "$TAG" ]; then
  VDIR=$PKG/opp_vendors/$TAG/vendors/fla_npu_transformer
else
  VDIR=$(readlink -f "$V")
fi
if [ ! -d "$VDIR" ]; then echo "[m_a2] vendor dir not found: $VDIR" >&2; exit 1; fi

# ⚠ 仅设 ASCEND_CUSTOM_OPP_PATH 不够：op store 还会跟着
# opp/vendors/fla_npu_transformer 这个软链走，必须一起改，否则 A/B 会静默
# 跑成同一个 kernel。
rm -rf "$V"; ln -sT "$VDIR" "$V"

if [ -n "$BASE_OPP" ]; then
  export ASCEND_CUSTOM_OPP_PATH=$BASE_OPP:$VDIR:$VDIR/op_api/lib
else
  export ASCEND_CUSTOM_OPP_PATH=$VDIR:$VDIR/op_api/lib
fi

echo "[m_a2] vendor=$VDIR" >&2
"$PY" "$MY/kda_a2_bench.py" "$JSON" "$CID" "$W" "$R" "$CACHE"
